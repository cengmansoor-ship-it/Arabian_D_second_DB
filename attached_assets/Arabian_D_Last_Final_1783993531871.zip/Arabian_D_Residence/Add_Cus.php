<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Arabian D Residence | Add Customer</title>
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    }
    .header{
    width: 100%;
    height: 137px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 40%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    flex-direction: row-reverse;
    
    }
    .body_page div{
    height: auto;
    width: 100%;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 70%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:78%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    form .inputbox {
        width: 100%;
        padding: 5px;
        margin: 0px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        box-sizing:border-box;
        position: relative;
    }
    form .inputbox input,select {
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;
        
    }
    form .inputbox i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }
    form .button input {
        width: 170px;
        padding: 18px;
        margin-top: 13px;
        border: none;
        background-color: rgb(51 158 77);
        margin-bottom: 14px;
        border-radius: 20px;   
        font-size:15px;
        font-weight:900;
        }
    form .button input:hover {
        border-radius: 4px;
        box-shadow: rgba(128, 128, 128, 0.63)  1px 10px 10px 2px;
        transition: ease-in-out  0.9s;
        outline: none;
        border: none;
    }

    </style>
</head>
<body>
<?php
include ("Confirm.php");
include ("Config.php");
$Cus_ty = $Cus_Na = $Cus_Des =  $Cus_Loc = $Cus_Pnum = $type_txt ="" ;
if (isset($_GET["IE"])) {
    $IE = $_GET["IE"];
    $Cus_data = $Conn->query("SELECT * FROM `custumer_info` WHERE ID=$IE")->fetch_assoc();
    $Cus_ty = $Cus_data["Cus_type"];
    if ($Cus_ty === "Reciver") {
        $type_txt = "راورونکی";
    }elseif ($Cus_ty === "Sender") {
        $type_txt = "اخیستونکی";
    }elseif ($Cus_ty === "Loan") {
        $type_txt = "دبازار پورونه";
    }elseif ($Cus_ty === "Counter") {
        $type_txt = "صراف";
    }
    $Cus_Na = $Cus_data["Name"];
    $Cus_Des = $Cus_data["Description"];
    $Cus_Loc = $Cus_data["Provice"];
    $Cus_Pnum = $Cus_data["Contact_Num"];
    $href = "?IE=".$IE;
}else {
    $href = "";
}
if (isset($_POST["Btn_Save"])) {
    $Cus_ty = $_POST["Cus_type"];
    $Cus_Na = $_POST["CusName"];
    $Cus_Des = $_POST["Des"];
    $Cus_Loc = $_POST["CusLocatiob"];
    $Cus_Pnum = $_POST["CusPhoneN"];
    $Conn->query("INSERT INTO `custumer_info`(`Cus_type`, `Name`, `Description`, `Contact_Num`, `Provice`) VALUES ('$Cus_ty','$Cus_Na','$Cus_Des',
    '$Cus_Pnum','$Cus_Loc' )");
    echo "<script>window.location.href='Select_Type.php?Tof=مشتریانو';</script>"; 
}
if (isset($_POST["Btn_Edit"])) {
    $Cus_ty = $_POST["Cus_type"];
    $Cus_Na = $_POST["CusName"];
    $Cus_Des = $_POST["Des"];
    $Cus_Loc = $_POST["CusLocatiob"];
    $Cus_Pnum = $_POST["CusPhoneN"];
    $Conn->query("UPDATE `custumer_info` SET `Cus_type`='$Cus_ty',`Name`='$Cus_Na',`Description`='$Cus_Des',
    `Contact_Num`='$Cus_Pnum',`Provice`='$Cus_Loc' WHERE id='$IE'");
    echo "<script>window.location.href='Select_Type.php?Tof=مشتریانو';</script>"; 
}

?>
    <div class="header">
        <div></div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="110px" height="110px" alt="Logo"><p style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo "$Cur_Date"; ?> </p></div>
        <div class="logount">
        <a href="Select_Type.php?Tof=مشتریانو" style="position: absolute;right: 0px;top:0px;margin: 15px;width: 50px;font-size:25px;font-weight: 900;color: black;text-decoration: none;font-family: sans-serif;cursor: pointer;">X</a>
        </div>
    </div>
    <form action="<?php echo $href; ?>" method="post" class="body_page">
            <div class="inputbox">
                <i>مشتری نوع</i>
                <select name='Cus_type' required>
                    <option value='<?php echo $Cus_ty; ?>'><?php echo $type_txt; ?></option>
                    <option value='Reciver'>راوړونکی</option>
                    <option value='Loan'>دبازار پوړونه</option>
                    <option value='Counter'>صرافی</option>
                    </select>
            </div>

            <div class="inputbox">
                <i>مشتری نوم</i>
                <input type="text" name="CusName"  value='<?php echo $Cus_Na; ?>' required>
            </div>
            <div class='inputbox'>
                <i>تفصیل</i>
                <textarea name='Des' style='width:100%;max-width:100%;min-width:100%;height:90px;max-height:90px;min-height:90px;'><?php echo $Cus_Des; ?></textarea>
            </div>

            <div class="inputbox">
                <i>ولایت</i>
                <select name='CusLocatiob' id='' required>
                    <option value='<?php echo $Cus_Loc; ?>'><?php echo $Cus_Loc; ?></option>
                    <option value='قندهار'>قندهار</option>
                    <option value='لوگر'>لوگر</option>
                    <option value='كابل'>كابل</option>
                    <option value='هرات'>هرات</option>
                    <option value='غزنی'>غزنی</option>
                    <option value='زابل'>زابل</option>
                    <option value='نیمروز'>نیمروز</option>
                    <option value='قلات'>قلات</option>
                    <option value='فراه'>فراه</option>
                    <option value='هلمند'>هلمند</option>
                    <option value='بادغیس'>بادغیس</option>
                    <option value='اوروزگان'>اوروزگان</option>
                    <option value='وردگ'>وردگ</option>
                    <option value='جلال اباد'>جلال اباد</option>
                    <option value='کاپیسا'>کاپیسا</option>
                    <option value='پروان'>پروان</option>
                    <option value='پکتیا'>پکتیا</option>
                    <option value='بغلان'>بغلان</option>
                    <option value='غور'>غور</option>
                    <option value='سر پل'>سر پل</option>
                    <option value='پاکستان'>پاکستان</option>
                    <option value='ایران'>ایران</option>
                    <option value=''>.</option>
                </select>
            </div>

            <div class="inputbox">
                <i>موبایل نمبر</i>
                <input type="text" name="CusPhoneN" value='<?php echo $Cus_Pnum; ?>' required>
            </div>
            <div class="button">
            <?php
            if (isset($_GET["IE"])) {
                echo "<input type='submit' value='تغییر' name='Btn_Edit'>";
            }else {
                echo "<input type='submit' value='ثبتول' name='Btn_Save'>";
            }
            ?>
            </div>
    </form>
    
</body>
</html>