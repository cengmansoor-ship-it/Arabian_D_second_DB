<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Arabian D Residence | Add Customer</title>
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    }
    .header{
    width: 100%;
    height: 137px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 40%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    flex-direction: row-reverse;
    
    }
    .body_page div{
    height: auto;
    width: 100%;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 70%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:78%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    form .inputbox {
        width: 100%;
        padding: 5px;
        margin: 0px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        box-sizing:border-box;
        position: relative;
    }
    form .inputbox input,select {
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;
        
    }
    form .inputbox i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }
    form .button input {
        width: 170px;
        padding: 18px;
        margin-top: 13px;
        border: none;
        background-color: rgb(51 158 77);
        margin-bottom: 14px;
        border-radius: 20px;   
        font-size:15px;
        font-weight:900;
        }
    form .button input:hover {
        border-radius: 4px;
        box-shadow: rgba(128, 128, 128, 0.63)  1px 10px 10px 2px;
        transition: ease-in-out  0.9s;
        outline: none;
        border: none;
    }
    .inputboxtwo{
        display: flex;
        width: 100%;
        flex-direction: row;
        direction:rtl;
    }
    .inputboxtwo div{
        width: 49%;
        box-sizing: border-box;
        justify-content: space-between;    
    }
    .inputboxtwo div input,select{
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;

    }
    .inputboxtwo div i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }
    </style>
</head>
<body>
<?php
include ("Confirm.php");
include ("Config.php");
$Name = $F_Name = $Contact_Num =  $JOB = $Cur_type = $Salary =$Nic_Card ="" ;
if (isset($_GET["IE"])) {
    $IE = $_GET["IE"];
    $href = "?IE=".$IE;
    $Data = $Conn->query("SELECT * FROM `emp_tbl` WHERE ID='$IE'")->fetch_assoc();
    @$Name = $Data["Name"];
    @$F_Name = $Data["F_Name"];
    @$Contact_Num = $Data["Contact_Num"];
    @$JOB = $Data["JOB"];
    @$Cur_Date = $Data["Join_date"];
    @$Cur_type = $Data["Cur_type"];
    @$Salary = $Data["Salary"];
    @$Nic_Card = $Data["Nic_Card"];

}else {
    $href = "";
}
if (isset($_POST["Btn_Save"])) {
    $Name = $_POST["Name"];
    $F_Name = $_POST["F_Name"];
    $Contact_Num = $_POST["Contact_Num"];
    $JOB = $_POST["JOB"];
    $Cur_Date = $_POST["Cur_Date"];
    $Cur_type = $_POST["Cur_type"];
    $Salary = $_POST["Salary"];
        
    $Nic_Card = $_POST["Nic_Card"];
    $New_item = $_POST["New_item"];


    if ($JOB === "New_item") {
        $Conn->query("INSERT INTO `emp_tbl`(`Name`, `F_Name`, `Contact_Num`, `JOB`, `Join_date`, `Cur_type`, `Salary`, `End_Date`, `Nic_Card`) VALUES
        ('$Name','$F_Name','$Contact_Num','$New_item','$Cur_Date','$Cur_type','$Salary','فعال','$Nic_Card')");
    }else {
        $Conn->query("INSERT INTO `emp_tbl`(`Name`, `F_Name`, `Contact_Num`, `JOB`, `Join_date`, `Cur_type`, `Salary`, `End_Date`, `Nic_Card`) VALUES
        ('$Name','$F_Name','$Contact_Num','$JOB','$Cur_Date','$Cur_type','$Salary','فعال','$Nic_Card')");
    }

        echo "<script>window.location.href='Add_emp.php';</script>"; 
    

}
if (isset($_POST["Btn_Edit"])) {
    $IE = $_GET["IE"];

    $Name = $_POST["Name"];
    $F_Name = $_POST["F_Name"];
    $Contact_Num = $_POST["Contact_Num"];
    $JOB = $_POST["JOB"];
    $Cur_Date = $_POST["Cur_Date"];
    $Cur_type = $_POST["Cur_type"];
    $Salary = $_POST["Salary"];
        
    $Nic_Card = $_POST["Nic_Card"];
    $New_item = $_POST["New_item"];

    if ($JOB === "New_item") {
        $Conn->query("UPDATE `emp_tbl` SET `Name`='$Name',`F_Name`='$F_Name',`Contact_Num`='$Contact_Num',
        `JOB`='$New_item',`Join_date`='$Cur_Date',`Cur_type`='$Cur_type',`Salary`='$Salary',`Nic_Card`='$Nic_Card' WHERE ID='$IE'");
    }else {
        $Conn->query("UPDATE `emp_tbl` SET `Name`='$Name',`F_Name`='$F_Name',`Contact_Num`='$Contact_Num',
        `JOB`='$JOB',`Join_date`='$Cur_Date',`Cur_type`='$Cur_type',`Salary`='$Salary',`Nic_Card`='$Nic_Card' WHERE ID='$IE'");
    }

        echo "<script>window.location.href='Labor_Index.php';</script>"; 


}

?>
    <div class="header">
        <div></div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="110px" height="110px" alt="Logo"><p style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo "$Cur_Date"; ?> </p></div>
        <div class="logount">
        <a href="Labor_Index.php" style="position: absolute;right: 0px;top:0px;margin: 15px;width: 50px;font-size:25px;font-weight: 900;color: black;text-decoration: none;font-family: sans-serif;cursor: pointer;">X</a>
        </div>
    </div>
    <form action="<?php echo $href; ?>" method="post" autocomplete='off' class="body_page">
    <div class="inputboxtwo">
        <div>
        <i>نوم</i>
        <input type="text" name="Name"  value='<?php echo $Name; ?>' required>
        </div>

        <div>
        <i>پلار نوم</i>
        <input type="text" name="F_Name"  value='<?php echo $F_Name; ?>' required>
        </div>
    </div>
    <br>
    <div class="inputbox">
        <i>معاش</i>
    <div style='display: flex;justify-content: space-between;width: 100%;direction:rtl'>
        <input type='number' min='0' step='0.1' name='Salary' value='<?php echo $Salary; ?>' style='width:70%;'>
            <select name='Cur_type' id='' style='width:30%;'>
                <option value='<?php echo $Cur_type; ?>'><?php echo Find_cur($Cur_type); ?></option>
                <option value='AF'>افغانی</option>
                <option value='K'>کالدار</option>
                <option value='USD'>دالر</option>
            </select>
    </div>
    </div>

    <div class="inputboxtwo">
        <div>
        <i>موبایل نمبر</i>
        <input type="text" name="Contact_Num"  value='<?php echo $Contact_Num; ?>' required>
        </div>

        <div>
        <i>وظیفه</i>
        <select name='JOB'  onchange="OPT(this.value);" oninput="OPT(this.value);"  style='width:100%;'>
            <?php
            $Item = $Conn->query("SELECT DISTINCT `JOB` FROM `emp_tbl`");
            echo "<option value='$JOB'>$JOB</option>";

            while ($A = $Item->fetch_assoc()) {
                $JOb = $A["JOB"];
                echo "<option value='$JOb'>$JOb</option>";
            }
            ?>
        <option value='New_item'>نوي وظیفه</option>

        </select> 
        </div>
    </div>
    <div class="inputbox">
        <i id="New_I" style="Display:none;">نوی وظیفه </i>
        <input type="text" name="New_item" id="New_Input" style="Display:none;" value=''>
    </div>

    <br>
    <div class="inputboxtwo">
        <div>
        <i>تذکره نمبر</i>
        <input type="text" name="Nic_Card"  value='<?php echo $Nic_Card; ?>' required>
        </div>

        <div>
        <i>تاریخ</i>
        <input type="text" name="Cur_Date"  value='<?php echo $Cur_Date; ?>' required>
        </div>
    </div>


    <div class="button">
    <?php
    if (isset($_GET["IE"])) {
        echo "<input type='submit' value='تغییر' name='Btn_Edit'>";
    }else {
        echo "<input type='submit' value='ثبتول' name='Btn_Save'>";
    }
    ?>
    </div>
    </form>
    
</body>
</html>