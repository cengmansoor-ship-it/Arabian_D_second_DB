<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
body{
    width: 100%;
    padding: 0px;
    margin: 0px;
    display: flex;
    align-items: center;
    direction:rtl;
    flex-direction:column;
}
img{
    width: 100%;
}
table{
    width: 100%;
    border: 1px solid;
    border-collapse: collapse;
}
th,td{
    padding: 6px;
    border: 1px solid;
    font-weight: 900;
}
td input{
    width: 100%;
    background: transparent;
    border: none;
    padding: 0px;
    outline: none;
    text-align:center;
    font-weight: 900;
}
caption{
    font-size: 30px;
    font-weight: 900;
    text-align: inherit;
    padding: 5px;
}
    
</style>

</head>
<body>
<?php 
include ("Confirm.php");
include ("Config.php");
// echo "<title>Arabian D Residence | ", @$Pro_Name ," پروژه</title>";
$Sdate = "1403-01-01";
$EDate = $Cur_Date;
if (isset($_POST["SRCH"])) {
    @$Sdate = $_POST["Start"];
    @$EDate = $_POST["End"];
}
echo "<title>Arabian D Residence | Report From $Sdate to $EDate </title>";
?>

    <img src="Img/DD1.jpg" alt="" srcset="">
    <br>
    <table><form action="" method="POST">
        <tr>
            <td width='290px'>د شروع تاریخ</td>
<td  style='background-image:url(Img/blue2.png);'><input type="text" min='1' name="Start" value="<?php echo $Sdate;?>"><input type="submit" name='SRCH' value="جستجو"></td>
        </tr>
        <tr>
        <td width='290px'>د ختم تاریخ</td>
<td  style='background-image:url(Img/blue2.png);'><input type="text" min='1' name="End" value="<?php echo $EDate;?>"><input type="submit" name='SRCH' style='display:inline-block;' value="جستجو"> </td>
        </tr>
    </form></table>
    <br>
    <table>
    <caption>خریدات</caption>
    <tr>
        <td>شمیره</td>
        <td>جنس نوم</td>
        <td>مقدار</td>
        <td>ټوټل حساب</td>
    </tr>
    <?php
    $ShowItem = $Conn->query("SELECT DISTINCT `Item_Name`,`Cur_type`,`QTYtype` FROM `buy_info` WHERE Item_Name != '' AND Bill_Num>0 AND `Date` BETWEEN '$Sdate' AND '$EDate'");
    $x = 1;
    $MOneyhAF = 0;
    $MOneyhK = 0;
     $MOneyhUSD = 0;
     while ($A = $ShowItem->fetch_assoc()) {
         echo "<tr>";
         $Item_Name = $A["Item_Name"];
         $Cur_type = $A["Cur_type"];
         $QTYtype = $A["QTYtype"];
         echo "<td>". $x++ ."</td>";
         echo "<td>". $Item_Name ."</td>";
         $ShowData  = $Conn->query("SELECT SUM(`Item_qty`) as Q, SUM(`Total_price`) as T FROM `buy_info` WHERE `Item_Name`='$Item_Name' AND Bill_Num>0  and `Cur_type`='$Cur_type' AND QTYtype='$QTYtype' and `Date`BETWEEN '$Sdate' And '$EDate'")->fetch_assoc();
         echo "<td>". $ShowData["Q"]. " ". $QTYtype ."</td>";
         echo "<td>". $ShowData["T"],  " ",Find_cur($Cur_type) ."</td>";

         if ($Cur_type === "AF") {
             $MOneyhAF += $ShowData["T"];
             }elseif ($Cur_type === "K") {
             $MOneyhK += $ShowData["T"];
             }elseif ($Cur_type === "USD") {
             $MOneyhUSD += $ShowData["T"];
             }
         echo "</tr>";
     }
     echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "افغانی:" ."</td>";
    echo "<td>". "$MOneyhAF" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "کلدار:" ."</td>";
    echo "<td>". "$MOneyhK" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "دالر:" ."</td>";
    echo "<td>". "$MOneyhUSD" ."</td>";
    echo "</tr>";

    ?>
    </table>
    <br>
    <table>
    <caption>واپیسی اجناس</caption>
    <tr>
        <td>شمیره</td>
        <td>جنس نوم</td>
        <td>مقدار</td>
        <td>ټوټل حساب</td>
    </tr>
    <?php
    $ShowItem = $Conn->query("SELECT DISTINCT `Item_Name`,Cur_type,QTYtype FROM `buy_info` WHERE Item_Name != ''  AND Bill_Num<0 AND `Date` BETWEEN '$Sdate' AND '$EDate'");
    $x = 1;
    $MOneyhAF = 0;
    $MOneyhK = 0;
    $MOneyhUSD = 0;
    while ($A = $ShowItem->fetch_assoc()) {
        echo "<tr>";
        $Item_Name = $A["Item_Name"];
        $Cur_type = $A["Cur_type"];
        $QTYtype = $A["QTYtype"];
        echo "<td>". $x++ ."</td>";
        echo "<td>". $Item_Name ."</td>";
        $ShowData_get  = $Conn->query("SELECT SUM(`Item_qty`) as Q, SUM(`Total_price`) as T FROM `buy_info` WHERE `Item_Name`='$Item_Name'  AND Bill_Num<0 and `Cur_type`='$Cur_type' AND QTYtype='$QTYtype' and `Date`BETWEEN '$Sdate' And '$EDate'")->fetch_assoc();
        echo "<td>". $ShowData_get["Q"]. " ". $QTYtype ."</td>";

        echo "<td>". $ShowData_get["T"],  " ",Find_cur($Cur_type) ."</td>";

        if ($Cur_type === "AF") {
            $MOneyhAF += $ShowData_get["T"];
            }elseif ($Cur_type === "K") {
            $MOneyhK += $ShowData_get["T"];
            }elseif ($Cur_type === "USD") {
            $MOneyhUSD += $ShowData_get["T"];
            }
        echo "</tr>";
    }
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "افغانی:" ."</td>";
    echo "<td>". "$MOneyhAF" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "کلدار:" ."</td>";
    echo "<td>". "$MOneyhK" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "دالر:" ."</td>";
    echo "<td>". "$MOneyhUSD" ."</td>";
    echo "</tr>";

    ?>
    </table>
    <br>
    <table>
    <caption>استعمال سوی اجناس په پروژه ګی</caption>
    <tr>
    <td>شمیره</td>
    <td>جنس نوم</td>
    <td>مقدار</td>
    <td>ټوټل حساب</td>
    </tr>
    <?php
    $ShowItem = $Conn->query("SELECT DISTINCT `Item_Name`,`Cur_type`,`QTYtype` FROM `project_exp` WHERE `Date` BETWEEN '$Sdate' AND '$EDate'");
    $x = 1;
    $MOneyhAF = 0;
    $MOneyhK = 0;
    $MOneyhUSD = 0;
    while ($A = $ShowItem->fetch_assoc()) {
        echo "<tr>";
        $Item_Name = $A["Item_Name"];
        $Cur_type = $A["Cur_type"];
        $QTYtype = $A["QTYtype"];
        echo "<td>". $x++ ."</td>";
        echo "<td>". $Item_Name ."</td>";
        $ShowItemdATA = $Conn->query("SELECT SUM(`Qty`) as Q, SUM(`total`) as T FROM `project_exp` WHERE `Item_Name`='$Item_Name' and QTYtype='$QTYtype',`Cur_type`='$Cur_type' and `Date` BETWEEN '$Sdate' and '$EDate'")->fetch_assoc();
        echo "<td>". $ShowItemdATA["Q"]. " ". $QTYtype ."</td>";

        echo "<td>". $ShowItemdATA["T"],  " ",Find_cur($Cur_type) ."</td>";
        if ($Cur_type === "AF") {
            $MOneyhAF += $ShowItemdATA["T"];
            }elseif ($Cur_type === "K") {
            $MOneyhK += $ShowItemdATA["T"];
            }elseif ($Cur_type === "USD") {
            $MOneyhUSD += $ShowItemdATA["T"];
            }
        echo "</tr>";
    }
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "افغانی:" ."</td>";
    echo "<td>". "$MOneyhAF" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "کلدار:" ."</td>";
    echo "<td>". "$MOneyhK" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "دالر:" ."</td>";
    echo "<td>". "$MOneyhUSD" ."</td>";
    echo "</tr>";
    ?>
    </table>
    <br>
    <table>
    <caption>مصارفات</caption>
    <tr>
    <td>شمیره</td>
    <td>مصرف نوعیات</td>
    <td>پیسی</td>

    </tr>
    <?php
    $ShowItem = $Conn->query("SELECT DISTINCT `Type`,`Cur_type` FROM `expence` WHERE `Date_` BETWEEN '$Sdate' AND '$EDate'");
    $x = 1;
    $MOneyhAF = 0;
    $MOneyhK = 0;
    $MOneyhUSD = 0;

    while ($A = $ShowItem->fetch_assoc()) {
        echo "<tr>";
        $Type = $A["Type"];
        $Cur_type = $A["Cur_type"];
        echo "<td>". $x++ ."</td>"; 
        echo "<td>". $Type ."</td>"; 
        $ShowItemdATA = $Conn->query("SELECT SUM(`Money`) as T FROM `expence` WHERE `Type`= '$Type' AND `Cur_type`='$Cur_type' AND `Date_` BETWEEN '$Sdate' AND '$EDate'")->fetch_assoc();
        echo "<td>". $ShowItemdATA["T"], "&nbsp;";
        echo Find_cur($Cur_type)  ." </td>";
        if ($Cur_type === "AF") {
            $MOneyhAF += $ShowItemdATA["T"];
            }elseif ($Cur_type === "K") {
            $MOneyhK += $ShowItemdATA["T"];
            }elseif ($Cur_type === "USD") {
            $MOneyhUSD += $ShowItemdATA["T"];
            }

        echo "</tr>";
    }

    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "افغانی:" ."</td>";
    echo "<td>". "$MOneyhAF" ."</td>";
    echo "</tr>";

    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "کلدار:" ."</td>";
    echo "<td>". "$MOneyhK" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "دالر:" ."</td>";
    echo "<td>". "$MOneyhUSD" ."</td>";
    echo "</tr>";
    ?>
    </table>
<br>
<table>
<caption>راوړونکی مشتریان</caption>
<tr>
    <td>شمیره</td>
    <td>مشتری توم</td>
    <td>افغانی</td>
    <td>کلدار</td>
    <td>ډالر</td>
</tr>
<?php
    $CusID = $Conn->query("SELECT DISTINCT `Cus_Name` FROM `buy_info` WHERE `Date` BETWEEN '$Sdate' AND '$EDate'");
    $x = 1;
    $AFB = 0 ;
    $AFB_ = 0 ;
    $AFB_P = 0 ;

    $KB= 0 ;
    $KB_= 0 ;
    $KB_P = 0 ;

    $USDB= 0 ;
    $USDB_= 0 ;
    $USDB_P = 0 ;

    while ($A = $CusID->fetch_assoc()) {
        $IDCUs = $A["Cus_Name"];
    echo "<tr>";
    $Cus_data = $Conn->query("SELECT `Name` FROM `custumer_info` WHERE `ID`='$IDCUs'")->fetch_assoc();
    $AF_BQUery = $Conn->query("SELECT SUM(`Total_price`) as T FROM `buy_info` WHERE Cus_Name = '$IDCUs' AND `Bill_Num` > 0 AND `Cur_type`='AF' AND `Date` BETWEEN '$Sdate' AND '$EDate'")->fetch_assoc();
    $AF_WQUery = $Conn->query("SELECT SUM(`Total_price`) as T FROM `buy_info` WHERE Cus_Name = '$IDCUs' AND (`Bill_Num` = '0' OR `Bill_Num` < 0)  AND `Cur_type`='AF' AND `Date` BETWEEN '$Sdate' AND '$EDate'")->fetch_assoc();
    $AFB = $AF_BQUery["T"] - $AF_WQUery["T"];
    // ----------------------
    $K_BQUery = $Conn->query("SELECT SUM(`Total_price`) as T FROM `buy_info` WHERE Cus_Name = '$IDCUs' AND `Bill_Num` > 0 AND `Cur_type`='K' AND `Date` BETWEEN '$Sdate' AND '$EDate'")->fetch_assoc();
    $K_WQUery = $Conn->query("SELECT SUM(`Total_price`) as T FROM `buy_info` WHERE Cus_Name = '$IDCUs' AND (`Bill_Num` = '0' OR `Bill_Num` < 0)  AND `Cur_type`='K' AND `Date` BETWEEN '$Sdate' AND '$EDate'")->fetch_assoc();
    $KB = $K_BQUery["T"] - $K_WQUery["T"];
    // ------------------------
    $USD_BQUery = $Conn->query("SELECT SUM(`Total_price`) as T FROM `buy_info` WHERE Cus_Name = '$IDCUs' AND `Bill_Num` > 0 AND `Cur_type`='USD' AND `Date` BETWEEN '$Sdate' AND '$EDate'")->fetch_assoc();
    $USD_WQUery = $Conn->query("SELECT SUM(`Total_price`) as T FROM `buy_info` WHERE Cus_Name = '$IDCUs' AND (`Bill_Num` = '0' OR `Bill_Num` < 0)  AND `Cur_type`='USD' AND `Date` BETWEEN '$Sdate' AND '$EDate'")->fetch_assoc();
    $USDB = $USD_BQUery["T"] - $USD_WQUery["T"];

    echo "<td>". $x++ ."</td>"; 
    echo "<td>". $Cus_data["Name"] ."</td>"; 
    if ($AFB < 0) {
        echo "<td style='Color:red;'>". $AFB ."</td>";
        $AFB_ += $AFB ;

    }else {
        echo "<td>". $AFB ."</td>";
        $AFB_P += $AFB ;
    }
    if ($KB < 0) {
        echo "<td style='Color:red;'>". $KB ."</td>";
        $KB_ += $KB ;
    }else {
        echo "<td>". $KB ."</td>";
        $KB_P += $KB ;

    }
    if ($USDB < 0) {
        echo "<td style='Color:red;'>". $USDB ."</td>";
        $USDB_ += $USDB ;
    }else {
        echo "<td>". $USDB ."</td>";
        $USDB_P += $USDB ;

    }

    echo "</tr>";


}
echo "<tr style='background-image:url(Img/blue2.png);'>";
echo "<td>". "ټوټل حساب: " ."</td>";
echo "<td>". "" ."</td>";
echo "<td>". "
پور: $AFB_P <br>
طلب: $AFB_ 
" ."</td>";
echo "<td>". "
پور: $KB_P <br>
طلب: $KB_ 
" ."</td>";
echo "<td>". "
پور: $USDB_P <br>
طلب: $USDB_ 
" ."</td>";

echo "</tr>";



?>
</table>
<br>
<table>
<caption>بازار پوړونه و صرافی</caption>
<tr>
    <td>شمیره</td>
    <td>مشتری توم</td>
    <td>افغانی</td>
    <td>کلدار</td>
    <td>ډالر</td>
</tr>
<?php
    $CusID = $Conn->query("SELECT DISTINCT `Cus_ID` FROM `loan_tbl` WHERE `Date` BETWEEN '$Sdate' AND '$EDate'");
    $x = 1;
    $AFB = 0 ;
    $AFB_ = 0 ;
    $AFB_P = 0 ;

    $KB= 0 ;
    $KB_= 0 ;
    $KB_P = 0 ;

    $USDB= 0 ;
    $USDB_= 0 ;
    $USDB_P = 0 ;


    while ($A = $CusID->fetch_assoc()) {
        $IDCUs = $A["Cus_ID"];
    echo "<tr>";
    $Cus_data = $Conn->query("SELECT `Name` FROM `custumer_info` WHERE `ID`='$IDCUs'")->fetch_assoc();

    echo "<td>". $x++ ."</td>"; 
    echo "<td>". $Cus_data["Name"] ."</td>"; 
    $AF_BQUery = $Conn->query("SELECT SUM(`Plus`) as PL,SUM(`Mines`) as Mi FROM `loan_tbl` WHERE Cus_ID = '$IDCUs' AND `Cur_type`='AF' AND `Date` BETWEEN '$Sdate' AND '$EDate'")->fetch_assoc();
    $AFB = $AF_BQUery["PL"]-$AF_BQUery["Mi"] ;
    if ($AFB < 0) {
        echo "<td style='Color:red;'>". $AFB ."</td>";
        $AFB_ += $AFB ;

    }else {
        echo "<td>". $AFB ."</td>";
        $AFB_P += $AFB ;
    }

    $K_BQUery = $Conn->query("SELECT SUM(`Plus`) as PL,SUM(`Mines`) as Mi FROM `loan_tbl` WHERE Cus_ID = '$IDCUs' AND `Cur_type`='K' AND `Date` BETWEEN '$Sdate' AND '$EDate'")->fetch_assoc();
    $KB = $K_BQUery["PL"]-$K_BQUery["Mi"] ;
    if ($KB < 0) {
        echo "<td style='Color:red;'>". $KB ."</td>";
        $KB_ += $KB ;

    }else {
        echo "<td>". $KB ."</td>";
        $KB_P += $KB ;
    }

    $USD_BQUery = $Conn->query("SELECT SUM(`Plus`) as PL,SUM(`Mines`) as Mi FROM `loan_tbl` WHERE Cus_ID = '$IDCUs' AND `Cur_type`='USD' AND `Date` BETWEEN '$Sdate' AND '$EDate'")->fetch_assoc();
    $USDB = $USD_BQUery["PL"]-$USD_BQUery["Mi"] ;
    if ($USDB < 0) {
        echo "<td style='Color:red;'>". $USDB ."</td>";
        $USDB_ += $USDB ;

    }else {
        echo "<td>". $USDB ."</td>";
        $USDB_P += $USDB ;
    }

    echo "</tr>";
}
echo "<tr style='background-image:url(Img/blue2.png);'>";
echo "<td>". "ټوټل حساب: " ."</td>";
echo "<td>". "" ."</td>";
echo "<td>". "
پور: $AFB_P <br>
طلب: $AFB_ 
" ."</td>";
echo "<td>". "
پور: $KB_P <br>
طلب: $KB_ 
" ."</td>";
echo "<td>". "
پور: $USDB_P <br>
طلب: $USDB_ 
" ."</td>";

echo "</tr>";


?>
</table>
<br>
<table>
    <caption>فروشات</caption>
    <tr>
      <th>شمیره</th>
      <th>تاریخ</th>
        <th>بلاک نوم</th>
        <th>نوم / پلار نوم / نیکه نوم</th>
        <th>شمیره</th>
            <th>منزل / کور نمبر / خونی تعداد</th>
        <th>وصول</th> 
    </tr>
    <?php
    $ShowItem = $Conn->query("SELECT * FROM `sell_project` WHERE type='' AND `Date` BETWEEN '$Sdate' and '$EDate' ORDER BY `ID`");
    $x = 1;
    $MOneyhAF = 0;
    $MOneyhK = 0;
    $MOneyhUSD = 0;

    while ($A = $ShowItem->fetch_assoc()) {
        $idRec = $A["Project_Name"];
        $IDpay = $A["ID"];
        echo "<tr>";
        echo "<td>". $idRec ."</td>";$x++;
        echo "<td>". $A["Date"]."</td>";

        $Item = $Conn->query("SELECT `Location`,`Project_Name`,`Pro_Owner` FROM `project_info` WHERE Pro_ID='$idRec' ORDER by Pro_ID")->fetch_assoc();
        $CName = $Item["Project_Name"];
        $Location = $Item["Location"];
        $Pro_Owner = $Item["Pro_Owner"];
        echo "<td>".$CName ." / ". $Pro_Owner."</td>";
        echo "<td>". $A["CusName"]. " / ".$A["F_NAme"]." / ".$A["GandpaNAme"] ."</td>";
        echo "<td>". $A["ContactNO"]."</td>";
        echo "<td>". $A["Floor"]. " / ".$A["APTNum"]." / ".$A["RoomQty"] ."</td>";
        echo "</td>";
        $pay = $Conn->query("SELECT SUM(`Payment`) as Pay FROM `sell_project` WHERE `Project_Name`='$IDpay' AND `type`='Pay' AND `Date` BETWEEN '$Sdate' and '$EDate'")->fetch_assoc();
        echo "<td style='Color:blue;'>". $pay["Pay"]." ";
        echo Find_cur($A["Curtype"]) ."</td>";
        echo "</tr>";
        if ($A["Curtype"] === "AF") {
            $MOneyhAF += $pay["Pay"];
            }elseif ($A["Curtype"] === "K") {
            $MOneyhK += $pay["Pay"];
            }elseif ($A["Curtype"] === "USD") {
            $MOneyhUSD += $pay["Pay"];
            }

    }
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "افغانی:" ."</td>";
    echo "<td>". "$MOneyhAF" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "کلدار:" ."</td>";
    echo "<td>". "$MOneyhK" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "دالر:" ."</td>";
    echo "<td>". "$MOneyhUSD" ."</td>";
    echo "</tr>";

    ?>
    </table>


</body>
</html>