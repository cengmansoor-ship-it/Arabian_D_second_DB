<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>AFP | Attendance</title>
<style>
body{direction:rtl;}

.tit
{
    padding: 5px;
    display: flex;
    flex-wrap: wrap;
    flex-direction: row;
    justify-content: space-between;
    align-items: stretch;
    font-size:22px;
}
th,td{
    border: 2px solid black;
    text-align:center;
}
.tit div input
{
    border: none;
    outline: none;
    font-size:22px;
    padding:5px;
}
</style>
<?php

include ("Confirm.php");
include ("Config.php");
if (isset($_POST["Find"])) {
    $date = $_POST["DYY"]; 
    $Cur_Date = $date;       
}
if (isset($_GET["Pre"])) {
    $Cur_Date = $_GET["DYY"]; 
    $pre = $_GET["Pre"];
    $Y = substr("$Cur_Date",0,4);
    $M = substr("$Cur_Date",5,2);
    $D = jdate('l', strtotime($Cur_Date));
    // 1403-04-01
        // $D = jdate("l");
        $YM = $Y.'-'. $M;
        $Salary_Emp = $Conn->query("SELECT Salary FROM emp_tbl WHERE ID='$pre'")->fetch_assoc();
        $sal = $Salary_Emp["Salary"];
        $perDay = ($sal / 30) ;
        $Active_Emp = $Conn->query("SELECT * FROM emp_accountv2 WHERE Emp_ID='$pre' AND Date='$Cur_Date' AND Type='P'");
        if ($Active_Emp->num_rows > 0) {
        echo "<script>window.location.href='Attendance.php';</script>"; 
            
        }else {
        $Conn->query("INSERT INTO emp_accountv2(Emp_ID, Count_ID,Y_M, Year_, Month_, Date, Day_Count, Type,Description, Amount)
        VALUES ('$pre','-','$YM','$Y','$M','$Cur_Date','1','P','$D','$perDay')");
        }

        echo "<script>window.location.href='Attendance.php';</script>"; 

    } 
    if (isset($_GET["PreEdit"])) {
        $PreEdit = $_GET["PreEdit"];
        $Active_Emp = $Conn->query("SELECT * FROM emp_accountv2 WHERE ID='$PreEdit'")->fetch_assoc();
        if ($Active_Emp["Type"] === "P") {
            $Conn->query("UPDATE emp_accountv2 SET Type='A' WHERE ID='$PreEdit'");
        }elseif ($Active_Emp["Type"] === "A") {
            $Conn->query("UPDATE emp_accountv2 SET Type='P' WHERE ID='$PreEdit'");
        }
        echo "<script>window.location.href='Attendance.php';</script>"; 
    }
    if (isset($_GET["Overtime"])) {
        $Overtime = $_GET["Overtime"];
        $OverYHour = $_POST["OverYHour"];
        $Cur_Date = $_GET["DYY"]; 
        $Y = substr("$Cur_Date",0,4);
        $M = substr("$Cur_Date",5,2);
        $D = jdate('l', strtotime($Cur_Date));
        $YM = $Y.'-'. $M;
    
        $Salary_Emp = $Conn->query("SELECT Salary FROM emp_tbl WHERE ID=$Overtime")->fetch_assoc();
        $sal = $Salary_Emp["Salary"];
        $PerHour = ($sal / 30) / 12 ;
        echo $sal ,"|", $PerHour,"|", $PerHour * $OverYHour ;
        $Conn->query("INSERT INTO emp_accountv2(Emp_ID, Count_ID, Y_M , Year_, Month_, Date, Day_Count, Type, Description, Amount)
        VALUES ('$Overtime','-','$YM','$Y','$M','$Cur_Date','$OverYHour','Over','$D',$PerHour * $OverYHour)");
        echo "<script>window.location.href='Attendance.php';</script>"; 

    }
    
?>
</head>
<body style='display: flex;
    justify-content: center;'>
    <div>
    <!--Emp_Rep.php  -->
    <a href='Emp_Rep.php'><img width='100%' src="Img/B1.jpg" alt=""></a>
    <form  width='100%' class="tit" action="" method='POST'>
    <!-- <div><label for="">ورځ:</label><input type="text" value='<?php #echo jdate("l"); ?>' readonly></div> -->
    <div><label for="">تاریخ:</label><input type="text" value='<?php echo $Cur_Date; ?>' name='DYY'></div><input type="submit" name="Find" style='display:none'>
    </form>
    <table width='100%' style='border-collapse: collapse;'>
    <tr height='35px'>
    <th>شماره | ای دی</th>
    <th>نوم</th>
    <th>پلار نوم</th>
    <th>وظیفه</th>
    <th>شماره تیلیفون</th>
    <th width='60px'>حاضر</th>
    <th width='170px'>اضافه کاری</th>
    </tr>
    <?php
    $All_Emp = $Conn->query("SELECT * FROM emp_tbl WHERE End_Date='فعال' ORDER BY ID");
    $x = 1;
    $A = 0;
    $P = 0;
    while ($Emp = $All_Emp->fetch_assoc()) {
        echo "<tr>";
        $EMpId = $Emp["ID"];
        echo "<td>", "<b>$x</b> | <b>MOGW-$EMpId</b>" ,"</td>";
        echo "<td>", $Emp["Name"] ,"</td>";
        echo "<td>", $Emp["F_Name"] ,"</td>";
        echo "<td>", $Emp["JOB"] ,"</td>";
        echo "<td>", $Emp["Contact_Num"] ,"</td>";
        $DellRec = $Conn->query("SELECT * FROM emp_accountv2 WHERE Emp_ID='$EMpId' AND Date='$Cur_Date' AND Type='P'");
        if ($DellRec->num_rows > 1) {
            $Datadf = $DellRec->fetch_assoc();
            $dell = $Datadf["ID"];
            $Conn->query("DELETE FROM `emp_accountv2` WHERE `ID`='$dell'");
        }
        
        $Emp_Acco = $Conn->query("SELECT * FROM emp_accountv2 WHERE Emp_ID ='$EMpId' AND Date = '$Cur_Date' AND (Type='P' OR Type='A')");
        if ($Emp_Acco->num_rows === 0) {
            echo "<td style='font-size:20px;font-weight:800;'>", "<a href='?Pre=$EMpId&DYY=$Cur_Date'>O</a>" ,"</td>";
        }else {
            $Data = $Emp_Acco->fetch_assoc();
            $RowID = $Data["ID"];
            if ($Data["Type"] === "P") {
                echo "<td style='font-size:20px;font-weight:800;'>", "<a href='?PreEdit=$RowID&DYY=$Cur_Date'>";
                echo "&check;";
                echo "</a></td>";
                $P += 1;
            }else {
                echo "<td style='font-size:20px;font-weight:800;' class='sdf'>", "<a href='?PreEdit=$RowID&DYY=$Cur_Date'>";
                echo "X";
                echo "</a></td>";
                echo "<style>.sdf{background-color:red;}</style>";
                $A += 1;
            }
            // 
        }
        $Account_EmpM = $Conn->query("SELECT SUM(`Day_Count`) as TMoney FROM `emp_accountv2` WHERE type='Over' AND Emp_ID = '$EMpId' AND `Date`='$Cur_Date'")->fetch_assoc();
        $OverYHour = $Account_EmpM["TMoney"];
        echo "<td>
        <form action='?Overtime=$EMpId&DYY=$Cur_Date' Method='POST'>
            <input type='number' name='OverYHour' step='0.1' min='0' value='$OverYHour' style='text-align:center;border:none;outline:none;width:100%;height:100%'>
            <input type='submit' style='display:none'>
        </form>
    </td>";

        echo "</tr>";
        $x++;
    }
    echo "<tr>";
    echo "<td>", "تعداد حاضر" ,"</td>";
    echo "<td>", "$P" ,"</td>";
    echo "<td>", "تعدادغیرحاضر" ,"</td>";
    echo "<td>", "$A" ,"</td>";
    echo "</tr>";

    ?>
    </table>
    </div>
</body>
</html>