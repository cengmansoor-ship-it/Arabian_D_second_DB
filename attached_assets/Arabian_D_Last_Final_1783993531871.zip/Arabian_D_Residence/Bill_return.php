<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
body{
    width: 100%;
    padding: 0px;
    margin: 0px;
    box-sizing: border-box;
    display: flex;
    justify-content: center;
}
.Page{
    border: 1px solid gray;
    width: 470px;
    height:auto;
    display: flex;
    flex-direction: column;
    direction:rtl;    position: relative;
}
.Page .head{
    height: 130px;
    width: 100%;
}
.Page .head img{
    height: 100%;
    width: 100%;
}
.bilinfo{
    width: 100%;
    display: flex;
    height:25px;
    justify-content: center;
    align-items: center;
}
.bilinfo div{
    width: 32%;
    box-sizing: border-box;
    flex-direction: row;

}
.bilinfo div input{
    width: 59%;
    border:none;
    outline:none;font-size: 11px;
    text-align:center;
}
.bilinfo div label{
    width:10px;
    font-weight:900;
}
table{
width: 100%;
/* border-collapse: collapse; */

}
table td,th{
border: 1px solid;
padding: 2px;
border-radius: 5px;
text-align: center;
box-sizing: border-box;
}

</style>
</head>
<body>
    <?php
        include ("Confirm.php");
        include ("Config.php");
        if (isset($_POST["Srchbtn"])) {
            @$Bill = $_POST["Bill_Num"];
        }else {
            @$DIsSelect = $Conn->query("SELECT DISTINCT Bill_Num FROM `buy_info` WHERE Bill_Num<0 ORDER BY Bill_Num desc")->fetch_assoc();
            @$Bill = $DIsSelect["Bill_Num"];
            
            @$Data = $Conn->query("SELECT * FROM `buy_info` WHERE `Bill_Num`='$Bill'")->fetch_assoc();
        @$Cus_Name = $Data["Cus_Name"];
        @$Cus_Cus_data = $Conn->query("SELECT Name FROM `custumer_info` WHERE ID='$Cus_Name'")->fetch_assoc();
        @$Cus_Name_txt = $Cus_Cus_data["Name"];
        @$Date = $Data["Date"];
        echo "<title>Arabian D Residence | $Cus_Name_txt بیل نمبر $Bill</title>";
        }
    ?>
    <form action="" Class='Page' method="post" autocomplete='off'>
    <div class="head"><img src="Img/Bill_Header.png" alt="Header"></div>
    <div style='width: 100%;'><img src="Img/Bill_footer.png" alt="Header" style="position: absolute;height:190px;
    z-index: -1;
    width: 100%;
    bottom: 0px;"></div>

    <div class="bilinfo">
    <div><label for="">نوم: </label><input type="text" name="CusName" value="<?php echo $Cus_Name_txt ?>" readonly></div>
    <div><label for="">بیل نمبر: </label><input type="number" max='-1' name="Bill_Num" value="<?php echo $Bill ?>"></div>
    <div><label for="">تاریخ: </label><input type="text" name="Date" value="<?php echo $Date ?>" readonly></div><input type="submit" name='Srchbtn' style="display:none">
    </div>
    <table>
        <tr>
            <th rowspan='2'>شمیره</th>
            <th rowspan='2'>جنس نوم</th>
            <th rowspan='2'>مقدار</th>
            <th colspan='3' rowspan='1'>قیمت</th>
            <th rowspan='2'>توتل</th>
        </tr>
        <tr>
        <th>افغانی</th>
        <th>کلدار</th>
        <th>دالر</th>
        </tr>
        <?php
        $All_Data = $Conn->query("SELECT * FROM `buy_info` WHERE `Bill_Num`='$Bill'");
        $x = 1;
        $AF = 0 ;
        $K = 0 ;
        $USD = 0 ;
        while ($A = $All_Data->fetch_assoc()) {
            echo "<tr class='Row'>";
            echo "<td>", $x ,"</td>";
            $x++;
            echo "<td>", $A["Item_Name"] ,"</td>";
            echo "<td>", $A["Item_qty"] ,"</td>";
            if ($A["Cur_type"] === "AF") {
                echo "<td>", $A["Item_price"] ,"</td>";
                echo "<td>", "" ,"</td>";
                echo "<td>", "" ,"</td>";
                $AF +=  $A["Total_price"] ;
                
            }elseif ($A["Cur_type"] === "K") {
                echo "<td>", "" ,"</td>";
                echo "<td>", $A["Item_price"] ,"</td>";
                echo "<td>", "" ,"</td>";
                $K +=  $A["Total_price"] ;
            }elseif ($A["Cur_type"] === "USD") {
                echo "<td>", "" ,"</td>";
                echo "<td>", "" ,"</td>";
                echo "<td>", $A["Item_price"] ,"</td>";
                $USD +=  $A["Total_price"] ;
            }
            echo "<td>", $A["Total_price"] ,"</td>";

            echo "</tr>";
        }
        while ($x <= 14) {
            $x++;

            echo "<tr>";
            echo "<td>", "$x" ,"</td>";
            echo "<td>", "" ,"</td>";
            echo "<td>", "" ,"</td>";
            echo "<td>", "","</td>";
            echo "<td>", "" ,"</td>";
            echo "<td>", "" ,"</td>";
            echo "<td>", "" ,"</td>";
            echo "</tr>";
        }
        echo "<tr style='font-weight:900;'>";
        echo "<td>", "افغانی" ,"</td>";
        echo "<td>", "$AF" ,"</td>";
        echo "</tr>";
        echo "<tr style='font-weight:900;'>";
        echo "<td>", "کلدار" ,"</td>";
        echo "<td>", "$K" ,"</td>";
        echo "</tr>";
        echo "<tr style='font-weight:900;'>";
        echo "<td>", "دالر" ,"</td>";
        echo "<td>", "$USD" ,"</td>";
        echo "</tr>";
        ?>
    </table>
    </form>
</body>
</html>