<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Arabian D Residence | Buy Form</title>
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    }
    .header{
    width: 100%;
    height: 137px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 40%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    flex-direction: row-reverse;
    
    }
    .body_page div{
    height: auto;
    width: 100%;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 70%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:78%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    form .inputbox {
        width: 100%;
        padding: 5px;
        margin: 0px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        box-sizing:border-box;
        position: relative;
    }
    form .inputbox input,select {
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;
        
    }
    form .inputbox i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }
    form .button input {
        width: 170px;
        padding: 18px;
        margin-top: 13px;
        border: none;
        background-color: rgb(51 158 77);
        margin-bottom: 14px;
        border-radius: 20px;   
        font-size:15px;
        font-weight:900;
        }
    form .button input:hover {
        border-radius: 4px;
        box-shadow: rgba(128, 128, 128, 0.63)  1px 10px 10px 2px;
        transition: ease-in-out  0.9s;
        outline: none;
        border: none;
    }
    .inputboxtwo{
        display: flex;
        width: 100%;
        flex-direction: row;
        direction:rtl;
    }
    .inputboxtwo div{
        width: 49%;
        box-sizing: border-box;
        justify-content: space-between;    
    }
    .inputboxtwo div input,select{
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;

    }
    .inputboxtwo div i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }

    </style>
</head>
<body>
<?php
include ("Confirm.php");
include ("Config.php");
$Item_type = $Cus_Na = $New_item =  $Bill = $Qty = $Priceper = $total = $Curtype = $date = $Href = $CUsFullName ="" ;
$date = $Cur_Date;

if (isset($_GET["IE"])) {
    $IE = $_GET["IE"];
    $Href = "?IE=$IE";
    $Buy_Edit = $Conn->query("SELECT * FROM `buy_info` WHERE ID='$IE'")->fetch_assoc();
    $Item_type = $Buy_Edit["Item_Name"];
    $Cus_Na = $Buy_Edit["Cus_Name"];
    $Cus_Cus_data = $Conn->query("SELECT Name FROM `custumer_info` WHERE ID='$Cus_Na'")->fetch_assoc();
    $CUsFullName = $Cus_Cus_data["Name"];

    $Bill = $Buy_Edit["Bill_Num"];
    $Qty = $Buy_Edit["Item_qty"];
    $Priceper = $Buy_Edit["Item_price"];
    $total = $Buy_Edit["Total_price"];
    $Curtype = $Buy_Edit["Cur_type"];
    $date = $Buy_Edit["Date"];

}
if (isset($_POST["Btn_Save"])) {
    $Item_type = $_POST["Item_Name"];
    $Cus_Na = $_POST["Cus_Name"];
    $New_item =  $_POST["New_item"];
    $Bill = $_POST["Bill_Num"];
    $Qty = $_POST["QTY"];
    $Priceper = $_POST["PricePer"];
    $total = $_POST["Total"];
    $Curtype = $_POST["Cur_type"];
    $date = $_POST["Date"];
    if ($Item_type === "New_item") {
    $Conn->query("INSERT INTO `buy_info`(`Item_Name`, `Cus_Name`, `Bill_Num`, `Item_qty`, `Item_price`, `Cur_type`, `Total_price`, `Date`) VALUES 
    ('$New_item','$Cus_Na','$Bill','$Qty','$Priceper','$Curtype','$total','$date')");
    echo "<script>window.location.href='Buy_frm.php';</script>"; 
    }else {
        $Conn->query("INSERT INTO `buy_info`(`Item_Name`, `Cus_Name`, `Bill_Num`, `Item_qty`, `Item_price`, `Cur_type`, `Total_price`, `Date`) VALUES 
        ('$Item_type','$Cus_Na','$Bill','$Qty','$Priceper','$Curtype','$total','$date')");
    echo "<script>window.location.href='Buy_frm.php';</script>"; 
    }
}elseif (isset($_POST["Btn_Edit"])) {
    $IE = $_GET["IE"];
    $Item_type = $_POST["Item_Name"];
    $Cus_Na = $_POST["Cus_Name"];
    $New_item =  $_POST["New_item"];
    $Bill = $_POST["Bill_Num"];
    $Qty = $_POST["QTY"];
    $Priceper = $_POST["PricePer"];
    $total = $_POST["Total"];
    $Curtype = $_POST["Cur_type"];
    $date = $_POST["Date"];
    if ($Item_type === "New_item") {
        $Conn->query("UPDATE `buy_info` SET `Item_Name`='$New_item',`Cus_Name`='$Cus_Na',`Bill_Num`='$Bill',
        `Item_qty`='$Qty',`Item_price`='$Priceper',`Cur_type`='$Curtype',`Total_price`='$total',`Date`='$date' WHERE ID='$IE'"); 
    echo "<script>window.location.href='Buy_Show.php?Item=$New_item';</script>"; 
    }else {
        $Conn->query("UPDATE `buy_info` SET `Item_Name`='$Item_type',`Cus_Name`='$Cus_Na',`Bill_Num`='$Bill',
        `Item_qty`='$Qty',`Item_price`='$Priceper',`Cur_type`='$Curtype',`Total_price`='$total',`Date`='$date' WHERE ID='$IE'"); 
        echo "<script>window.location.href='Buy_Show.php?Item=$Item_type';</script>"; 
}

}
    
?>
    <div class="header">
        <div></div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="90px" height="90px" alt="Logo"><p style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo "$Cur_Date"; ?> </p></div>
        <div class="logount">
        <a href="Dashboard.php" style="position: absolute;right: 0px;top:0px;margin: 15px;width: 50px;font-size:25px;font-weight: 900;color: black;text-decoration: none;font-family: sans-serif;cursor: pointer;">X</a>
        </div>
    </div>
    <form action="<?php echo $Href; ?>" method="post" class="body_page" autocomplete='off'>

            <div class="inputbox">
                <i>جنس نوم</i>
                <select name='Item_Name' onchange="OPT(this.value);" oninput="OPT(this.value);" required>
                    <?php
                    $Item = $Conn->query("SELECT DISTINCT `Item_Name` FROM `buy_info` WHERE Item_Name != '' ");
                    echo "<option value='$Item_type'>$Item_type</option>";

                    while ($A = $Item->fetch_assoc()) {
                        $name = $A["Item_Name"];
                        echo "<option value='$name'>$name</option>";
                    }
                    ?>
                    <!-- <option value='New_item'>نوي جنس</option> -->
                </select>
            </div>

            <div class="inputbox">
                <i id="New_I" style="Display:none;">نوی جنس نوم</i>
                <input type="text" name="New_item" id="New_Input" style="Display:none;" value=''>
            </div>

            <div class="inputbox">
                <i>مشتری نوم</i>
                <select name='Cus_Name' required>
                    <?php
                    $Item = $Conn->query("SELECT `ID`,`Name` FROM `custumer_info` WHERE `Cus_type`='Reciver'");
                    echo "<option value='$Cus_Na'>$CUsFullName</option>";

                    while ($B = $Item->fetch_assoc()) {
                        $idC = $B["ID"];
                        $CName = $B["Name"];
                        echo "<option value='$idC'>$CName</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="inputboxtwo">
                <div>
                <i>بیل نمیر</i>
                <input type="number" name="Bill_Num" max='-1' value='<?php echo $Bill; ?>' required>
                </div>

                <div>
                <i>مقدار</i>
                <input type="text" name="QTY" step='0.00001' id='Qty_I'  value='<?php echo $Qty; ?>' required>
                </div>
            </div>

            <div class="inputbox">
                <i>قیمت</i>
            <div style='display: flex;justify-content: space-between;width: 100%;direction:rtl'>
                <input type='number' min='0' step='0.00001' name='PricePer' onchange='total(this.value)' oninput='total(this.value)' id='PricePP' value='<?php echo $Priceper; ?>' style='width:70%;'>
                    <select name='Cur_type' id='' style='width:30%;'>
                        <option value='<?php echo $Curtype; ?>'><?php echo Find_cur($Curtype); ?></option>
                        <option value='AF'>افغانی</option>
                        <option value='K'>کالدار</option>
                        <option value='USD'>دالر</option>
                    </select>
            </div>
            </div>
            
            <div class="inputboxtwo">
                <div>
                    <i>ټوټل حساب</i>
                    <input type="text" name="Total" Id='TotalP' value='<?php echo $total ; ?>' required>
                </div>

                <div>
                    <i>تاریخ</i>
                    <input type="text" name="Date"  value='<?php echo $date; ?>' required>
                </div>
            <div>
            <div class="button">
            <?php
            if (isset($_GET["IE"])) {
                echo "<input type='submit' value='تغییر' name='Btn_Edit'>";
            }else {
                echo "<input type='submit' value='ثبتول' name='Btn_Save'>";
            }
            ?>
            </div>
    </form>
    
</body>
</html>