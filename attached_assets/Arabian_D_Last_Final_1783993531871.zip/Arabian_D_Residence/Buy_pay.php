<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Arabian D Residence | Buy Form</title>
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    }
    .header{
    width: 100%;
    height: 137px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 40%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    flex-direction: row-reverse;
    
    }
    .body_page div{
    height: auto;
    width: 100%;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 70%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:78%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    form .inputbox {
        width: 100%;
        padding: 5px;
        margin: 0px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        box-sizing:border-box;
        position: relative;
        direction:rtl;
    }
    form .inputbox input,select {
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;
        
    }
    form .inputbox i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }
    form .button input {
        width: 170px;
        padding: 18px;
        margin-top: 13px;
        border: none;
        background-color: rgb(51 158 77);
        margin-bottom: 14px;
        border-radius: 20px;   
        font-size:15px;
        font-weight:900;
        }
    form .button input:hover {
        border-radius: 4px;
        box-shadow: rgba(128, 128, 128, 0.63)  1px 10px 10px 2px;
        transition: ease-in-out  0.9s;
        outline: none;
        border: none;
    }
    .inputboxtwo{
        display: flex;
        width: 100%;
        flex-direction: row;
        direction:rtl;
    }
    .inputboxtwo div{
        width: 49%;
        box-sizing: border-box;
        justify-content: space-between;    
    }
    .inputboxtwo div input,select{
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;

    }
    .inputboxtwo div i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }

    </style>
</head>
<body>
<?php
include ("Confirm.php");
include ("Config.php");
$Cus_Na = $total = $Curtype =  $Des = $CUsFullName = "" ;
$Href = "";
if (isset($_GET["IDRec"])) {
    $IE = $_GET["IDRec"];
    $Cus_Tran_data = $Conn->query("SELECT * FROM `buy_info` WHERE ID=$IE")->fetch_assoc();
    $Cus_Na = $Cus_Tran_data["Cus_Name"];
    $Cus_Cus_data = $Conn->query("SELECT Name FROM `custumer_info` WHERE ID='$Cus_Na'")->fetch_assoc();
    $CUsFullName = $Cus_Cus_data["Name"];
    $total = $Cus_Tran_data["Total_price"];
    $Curtype = $Cus_Tran_data["Cur_type"];
    $Cur_Date = $Cus_Tran_data["Date"];
    $Des = $Cus_Tran_data["Description"];
    $Href = "?IDRec=$IE";

}

if (isset($_POST["Btn_Save"])) {
    $Cus_Na = $_POST["Cus_Name"];
    $date = $_POST["Date"];
    $Des = $_POST["Des"];
    $total = $_POST["Money"];
    $Curtype = $_POST["Cur_type"];
    $Slect = $_POST["Slect"];
    // if ($Slect === "Plus") {
    // $Conn->query("INSERT INTO `buy_info`(`Cus_Name`, `Bill_Num`, `Description`,`Cur_type`, `Total_price`, `Date`) VALUES (
    //     '$Cus_Na','0','$Des','$Curtype','$total','$Cur_Date')");
    // }else {
        $Conn->query("INSERT INTO `buy_info`(`Cus_Name`, `Bill_Num`, `Description`,`Cur_type`, `Total_price`, `Date`) VALUES (
            '$Cus_Na','0','$Des','$Curtype','$total','$Cur_Date')");
        // }
    
    echo "<script>window.location.href='Buy_pay.php';</script>"; 
}elseif (isset($_POST["Btn_Edit"])) {
    $IED = $_GET["IDRec"];
    $Cus_Na = $_POST["Cus_Name"];
    $date = $_POST["Date"];
    $Des = $_POST["Des"];
    $total = $_POST["Money"];
    $Curtype = $_POST["Cur_type"];
    $Conn->query("UPDATE `buy_info` SET `Cus_Name`='$Cus_Na',`Description`='$Des',`Cur_type`='$Curtype',
    `Total_price`='$total',`Date`='$date' WHERE ID='$IED'");
    echo "<script>window.location.href='View_Cus.php?Cur=$Curtype&ID=$Cus_Na';</script>"; 

}
?>
    <div class="header">
        <div></div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="90px" height="90px" alt="Logo"><p style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo "$Cur_Date"; ?> </p></div>
        <div class="logount">
        <a href="Buy_.php" style="position: absolute;right: 0px;top:0px;margin: 15px;width: 50px;font-size:25px;font-weight: 900;color: black;text-decoration: none;font-family: sans-serif;cursor: pointer;">X</a>
        </div>
    </div>
    <form action="" method="post" class="body_page">

            <div class="inputbox">
                <i>مشتری نوم</i>
                <select name='Cus_Name' required>
                    <?php
                    $Item = $Conn->query("SELECT `ID`,`Name` FROM `custumer_info` WHERE `Cus_type`='Reciver'");
                    echo "<option value='$Cus_Na'>$CUsFullName </option>";

                    while ($B = $Item->fetch_assoc()) {
                        $idC = $B["ID"];
                        $CName = $B["Name"];
                        echo "<option value='$idC'>$CName</option>";
                    }
                    ?>
                </select>
            </div>
            <div class='inputbox'>
                <i>عمل</i>
                <select name='Slect'>
                    <option value="Nothing"></option>
                    <option value="Plus">جمع کول</option>
                </select>

            </div>

            <div class='inputbox'>
                <i>تفصیل</i>
                <textarea name='Des' style='width:100%;max-width:100%;min-width:100%;height:90px;max-height:90px;min-height:90px;'><?php echo $Des; ?></textarea>
            </div>

            <div class="inputbox">
                <i>تاریخ</i>
                <input type="text" name="Date"  value='<?php echo $Cur_Date; ?>' required>
            </div>
            <div class="inputbox">
                <i>پیسی</i>
            <div style='display: flex;justify-content: space-between;width: 100%;direction:rtl'>
                <input type='number' min='0' step='0.1' name='Money' id='PricePP' value='<?php echo $total; ?>' style='width:70%;'>
                    <select name='Cur_type' id='' style='width:30%;'>
                        <option value='<?php echo $Curtype; ?>'><?php echo Find_cur($Curtype); ?></option>
                        <option value='AF'>افغانی</option>
                        <option value='K'>کالدار</option>
                        <option value='USD'>دالر</option>
                    </select>
            </div>
            </div>

            <div class="button">
            <?php
            if (isset($_GET["IDRec"])) {
                echo "<input type='submit' value='تغییر' name='Btn_Edit'>";
            }else {
                echo "<input type='submit' value='ثبتول' name='Btn_Save'>";
            }
            ?>
            </div>
    </form>
    
</body>
</html>