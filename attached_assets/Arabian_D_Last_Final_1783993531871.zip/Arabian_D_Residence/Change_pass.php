<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Arabian D Residence | Login Form</title>
<style>
body {
    background: url('Bkimg.PNG');
    height: 100vh;
    margin:0px;
    box-sizing: border-box;
    padding:50px;    
    font-family: sans-serif;
    width: 100%;
    background-position: center center;
    background-size: cover;
    display: flex;
    background-repeat: no-repeat;
    justify-content: center;
    flex-direction: column;
    direction:rtl;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    }
    form{

        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(4px);
        padding: 30px;
        border-radius: 10px;
        width: 300px;
        color: white;
        text-align: center;
    }
    form h2{
        margin-bottom: 0px;
    }
    form img{
        height: 200px;
    }
    .inputbox input[type="text"],
    .inputbox input[type="password"]{
        width: 100%;
        padding: 10px;
        margin: 8px 0px;
        background: transparent;
    direction:ltr;
        border: none;
        border-bottom: 1px solid white;
        color: white;
        outline: none;
    }
    .inputbox input::placeholder{
        color: white;
        font-size: 12px;
    }
    .button input {
        width: 100%;
        padding: 10px;
        margin-top: 10px;
        background-color: white;
        color: black;
        border: none;
        outline: none;
        border-radius: 5ox;
        cursor: pointer;
        font-weight: 900;
    }
    .Forgot{
        margin: 10px;
        font-size: 0.9em;
        text-align: right;
        width: 100%;
    }
    form .button input:hover {
        border-radius: 4px;
        box-shadow: rgba(128, 128, 128, 0.63)  1px 10px 10px 2px;
        transition: all 0.9s;
        outline: none;
        border: none;
    }
    .err {
        position: absolute;
    background: rgb(247 0 0 / 34%);
    border: rgb(247 0 0 / 34%);
    backdrop-filter: blur(2px);
    color: white;
    font-weight: 700;
    padding: 14px;
    width: 334px;
    font-size: 20px;
    text-align: center;
    margin-top: -52px;    }
    
</style>
<?php
include ("Config.php");
if (isset($_POST["Btn_change"])) {
    $Prevpass = Save_Input($_POST["CPass"]);
    $newpass = Save_Input($_POST["Npass"]);
    $confpass = Save_Input($_POST["ConfPass"]);
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $Sign_Info = $Conn->query("SELECT * FROM `user_info` WHERE ID ='1'")->fetch_assoc();
        if ($Prevpass === $Sign_Info["Password"]){
            if ($newpass === $confpass) {
                $Changepass = $Conn->query("UPDATE `user_info` SET `Password`='$newpass' WHERE Id='1'");
                echo "<script>window.location.href='Login_Page.php?change=PCSUCESS';</script>";

            }else {
                echo "<script>window.location.href='Change_pass.php?change=Inc';</script>";
            }
        }else {
            echo "<script>window.location.href='Change_pass.php?change=PNM';</script>";
        }
        }
    }

?>
</head>
<body>
<div class="login">
    <?php
    if (@$_GET["change"] === "PNM") {
        echo "<div class='err'>Current Password Error</div>";
        echo "<style>.CP {border: 1px solid red;}</style>"; 
       }elseif (@$_GET["change"] === "Inc") {
        echo "<div class='err'>Password Does Not Match</div>";
        echo "<style>.MP {border: 1px solid red;}</style>"; 
        
    }
    ?>

        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
        <img src="bbb.png" alt="Logo">
        <h2>ARABIAN D RESIDENCE</h2>

            <div class="inputbox">
                <i></i>
                <input type="Password" name="CPass" class='CP' placeholder="Enter Current Password:">
            </div>
            <div class="inputbox">
                <i></i>
                <input type="password" name="Npass" placeholder="Enter New Paswword:">
            </div>

            <div class="inputbox">
                <i></i>
                <input type="Password" name="ConfPass" class='MP' placeholder="Re Enter New Password:">
                <a href="Login_Page.php" class="Forgot">If You Want to go Login Page <u>Click Here</u></a>
            </div>
            <div class="button">
                <input type="submit" value="Save Changes" name="Btn_change">
            </div>
        </form>
    </div>
</body>
</html>
