<?php
// Report all errors so nothing is silently swallowed
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ---------------------------------------------------------------------------
// DATABASE CONNECTION
// ---------------------------------------------------------------------------
if (!extension_loaded('mysqli')) {
    die('<strong style="color:red;">[Config Error line 2]</strong> PHP extension <code>mysqli</code> is not installed or loaded. Please enable it in php.ini and restart your web server.');
}

$db_host = getenv('DB_HOST') ?: "localhost";
$db_user = getenv('DB_USER') ?: "root";
$db_pass = getenv('DB_PASS') ?: "root123";
$db_name = getenv('DB_NAME') ?: "arabian_d";
$Conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($Conn->connect_error) {
    die('<strong style="color:red;">[Config Error line 3]</strong> Database connection failed: ' . htmlspecialchars($Conn->connect_error) . '<br>'
        . 'Check that MySQL is running, the database <code>arabian_d</code> exists, and the username/password are correct.');
}

if (!mysqli_set_charset($Conn, "utf8mb4")) {
    die('<strong style="color:red;">[Config Error line 4]</strong> Could not set UTF-8 charset: ' . htmlspecialchars($Conn->error));
}

// ---------------------------------------------------------------------------
// JDF (Jalali / Islamic Date Functions)
// ---------------------------------------------------------------------------
$jdf_path = __DIR__ . DIRECTORY_SEPARATOR . 'jdf.php';
if (!file_exists($jdf_path)) {
    die('<strong style="color:red;">[Config Error line 6]</strong> Required file <code>jdf.php</code> not found at: ' . htmlspecialchars($jdf_path));
}

$jdf_result = include $jdf_path;
if ($jdf_result === false) {
    die('<strong style="color:red;">[Config Error line 7]</strong> <code>jdf.php</code> could not be included. Check its syntax or file permissions.');
}

// JDF defines jdate() — call it only after a successful include
$Cur_Date    = jdate("Y-m-d");
$Cur_Month   = jdate("Y-m");
$Cur_DateTime = jdate("h:i:s A");

// ---------------------------------------------------------------------------
// HELPER FUNCTIONS
// ---------------------------------------------------------------------------

function Save_Input($Xy) {
    $Xy = trim($Xy);
    $Xy = stripslashes($Xy);
    $Xy = htmlspecialchars($Xy);
    return $Xy;
}
function Find_cur($X){
    if ($X === "AF") {
        echo "افغانی";
    }elseif ($X === "K") {
        echo "کلدار";
    }elseif ($X === "USD") {
        echo "دالر";
    }else {
        echo "";
    }
}

?>
<script>
function OPT(X) {
    if (X === "New_item") {
        document.getElementById("New_I").style.display="Block";
        document.getElementById("New_Input").style.display="Block";
    }else{
        document.getElementById("New_I").style.display="none";
        document.getElementById("New_Input").style.display="none";
    }
}

function total(Valnum) {
    x = document.getElementById("Qty_I").value;
    
    document.getElementById("TotalP").value = x * Valnum;
}
</script>
<style>
form .button input{
    font-size:20px;
    text-align:center;
}
td {
    text-align:center;
}
.inputboxtwo{
        display: flex;
        width: 100%;
        flex-direction: row;
        margin-top:10px;
        direction:rtl;
    }
    .inputboxtwo div{
        width: 49%;
        box-sizing: border-box;
        justify-content: space-between;    
    }
    .inputboxtwo div input,select{
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;

    }
    .inputboxtwo div i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }
    .infotxt{
        position: fixed;
    bottom: -10px;
    color: #bbb3b3;
    left: 2px;
    font-family: emoji;
    font-size: 15px;
    }
</style>
<p class="infotxt">ARABIAN D RESIDENCE | Delivering Contraction services & Making life easier for everyone. </p>
