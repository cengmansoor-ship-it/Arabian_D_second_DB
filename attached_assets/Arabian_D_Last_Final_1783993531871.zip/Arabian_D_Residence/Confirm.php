<?php
if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}
if (!isset($_SESSION["Sign_in_User"])) {
    echo "<script>window.location.href='Login_Page.php?Aut=No';</script>";
}
?>