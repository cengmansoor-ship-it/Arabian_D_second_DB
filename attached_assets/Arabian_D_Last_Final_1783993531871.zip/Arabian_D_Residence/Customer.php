<?php
include ("Confirm.php");
include ("Config.php");
    
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Arabian D Residence | Customer List</title>
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    direction: rtl;
    }
    .header{
    width: 100%;
    height: 257px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 95%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    }
    .body_page table{
    width: 100%;
    /* border-collapse: collapse; */

    }
    .body_page table td,th{
        border: 1px solid;
    padding: 4px;
    border-radius: 5px;
    text-align: center;
    font-weight:600;
    }
    .Slect:hover{
    background-color: #00ffffc4;
    transition: all 0.1s;
        
    }
    a{
        text-decoration: none;
    color: black;
    font-weight: bolder;
    }
    </style>
</head>
<body>
<?php

if (isset($_GET["CusT"])) {
    $Cus_type = $_GET["CusT"];
}else {
    $Cus_type = "Reciver";
}



?>
    <div class="header">
        <div>
        <a href="Select_Type.php?Tof=مشتریانو" style="position: absolute;left: 0px;top:0px;"><img src="Img/Back.png" alt="Back" width='30px'></a>
        </div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="210px" height="210px" alt="Logo"><p style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo "$Cur_Date"; ?> </p></div>
        <div class="logount">
        </div>
    </div>
    <div class="body_page">
        <table>
            <tr>
                <th width='50px'>ای دی</th>
                <th>نوم</th>
                <th width='130px'>موبایل شمیره</th>
                <th>افغانی</th>
                <th>کلدار</th>
                <th>دالر</th>
                <th width='160px'>...</th>
            </tr>
            <?php
            $Cus_data = $Conn->query("SELECT * FROM `custumer_info` WHERE `Cus_type`='$Cus_type'");

            $AFB = 0 ;
            $AFB_ = 0 ;
            $AFB_P = 0 ;

            $KB= 0 ;
            $KB_= 0 ;
            $KB_P = 0 ;

            $USDB= 0 ;
            $USDB_= 0 ;
            $USDB_P = 0 ;


            while ($A = $Cus_data->fetch_assoc()) {
                echo "<tr class='Slect'>";
                $id = $A["ID"];
                echo "<td>". $id ."</td>";
                echo "<td>". $A["Name"] ."</td>";
                echo "<td>". $A["Contact_Num"] ."</td>";

                $AF_BQUery = $Conn->query("SELECT SUM(`Total_price`) as T FROM `buy_info` WHERE Cus_Name = '$id' AND `Bill_Num` > 0 AND `Cur_type`='AF'")->fetch_assoc();
                $AF_WQUery = $Conn->query("SELECT SUM(`Total_price`) as T FROM `buy_info` WHERE Cus_Name = '$id' AND (`Bill_Num` = '0' OR `Bill_Num` < 0)  AND `Cur_type`='AF'")->fetch_assoc();
                $AFB = $AF_BQUery["T"] - $AF_WQUery["T"];
                // ----------------------
                $K_BQUery = $Conn->query("SELECT SUM(`Total_price`) as T FROM `buy_info` WHERE Cus_Name = '$id' AND `Bill_Num` > 0 AND `Cur_type`='K'")->fetch_assoc();
                $K_WQUery = $Conn->query("SELECT SUM(`Total_price`) as T FROM `buy_info` WHERE Cus_Name = '$id' AND (`Bill_Num` = '0' OR `Bill_Num` < 0)  AND `Cur_type`='K'")->fetch_assoc();
                $KB = $K_BQUery["T"] - $K_WQUery["T"];
                // ------------------------
                $USD_BQUery = $Conn->query("SELECT SUM(`Total_price`) as T FROM `buy_info` WHERE Cus_Name = '$id' AND `Bill_Num` > 0 AND `Cur_type`='USD'")->fetch_assoc();
                $USD_WQUery = $Conn->query("SELECT SUM(`Total_price`) as T FROM `buy_info` WHERE Cus_Name = '$id' AND (`Bill_Num` = '0' OR `Bill_Num` < 0)  AND `Cur_type`='USD'")->fetch_assoc();
                $USDB = $USD_BQUery["T"] - $USD_WQUery["T"];
                // --------------------------
                if ($AFB < 0) {
                    echo "<td style='background:red;'>". $AFB ."</td>";
                    $AFB_ += $AFB ;

                }else {
                    echo "<td>". $AFB ."</td>";
                    $AFB_P += $AFB ;
                }
                if ($KB < 0) {
                    echo "<td style='background:red;'>". $KB ."</td>";
                    $KB_ += $KB ;
                }else {
                    echo "<td>". $KB ."</td>";
                    $KB_P += $KB ;

                }
                if ($USDB < 0) {
                    echo "<td style='background:red;'>". $USDB ."</td>";
                    $USDB_ += $USDB ;
                }else {
                    echo "<td>". $USDB ."</td>";
                    $USDB_P += $USDB ;

                }


                echo "<td>". "<a target='_blank' href='Select_Cur.php?COF=مشتری&ID=$id'>کهاته</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='Add_Cus.php?IE=$id'>تغییرول</a>" ."</td>";
                echo "</tr>";


            }
            echo "<tr style='background-image:url(Img/blue2.png);'>";
            echo "<td>". "ټوټل حساب: " ."</td>";
            echo "<td>". "" ."</td>";
            echo "<td>". "" ."</td>";
            echo "<td>". "
            پور: $AFB_P <br>
            طلب: $AFB_ 
            " ."</td>";
            echo "<td>". "
            پور: $KB_P <br>
            طلب: $KB_ 
            " ."</td>";
            echo "<td>". "
            پور: $USDB_P <br>
            طلب: $USDB_ 
            " ."</td>";
            echo "<td>". "" ."</td>";
    
            echo "</tr>";
    
            ?>
        </table>
    </div>
    <div class="fotter">

    </div>
</body>
</html>