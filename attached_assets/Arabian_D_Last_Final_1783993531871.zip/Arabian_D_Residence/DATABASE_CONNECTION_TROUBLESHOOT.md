# Database Connection Troubleshooting Guide

## ❌ Current Error
```
mysqli_sql_exception: No connection could be made because the target machine 
actively refused it in Config.php:13
```

**Current connection settings:**
- Host: `localhost`
- User: `root`
- Password: (empty)
- Database: `arabian_d`
- **Port: `3307`** ← LIKELY THE PROBLEM

---

## 🔍 Step 1: Start MySQL in XAMPP

### Option A: Using XAMPP Control Panel
1. Open XAMPP Control Panel
2. Look for "MySQL" service
3. Click **"Start"** button next to MySQL
4. Wait for it to show "Running" status

### Option B: Using Command Line
```powershell
# Start MySQL service (Windows)
net start MySQL80

# Or if using XAMPP directly:
cd C:\xampp
mysql_start.bat
```

---

## 🔍 Step 2: Determine the Correct MySQL Port

### Option A: Check XAMPP Configuration
1. Open XAMPP Control Panel
2. Click "Config" button next to MySQL
3. Look for the default configuration file
4. Search for `port=` line
5. **Note the port number** (usually 3306 or 3307)

### Option B: Check via Command Line
```powershell
# Connect to MySQL to test (if it's running)
mysql -u root -h localhost -P 3306 -e "SELECT VERSION();"

# If that fails, try port 3307:
mysql -u root -h localhost -P 3307 -e "SELECT VERSION();"

# If either works, you found the correct port!
```

### Option C: Check MySQL Error Log
- **XAMPP MySQL Log:** `C:\xampp\mysql\data\mysql_error.log`
- Look for lines with `port` information
- Example: `InnoDB: Starting ... port 3306`

---

## 🔍 Step 3: Verify XAMPP MySQL Configuration

### Find MySQL Configuration File:
- **Path:** `C:\xampp\mysql\bin\my.ini`
- **OR:** `C:\xampp\mysql\bin\my.cnf`

### Look for port setting:
```ini
[mysqld]
port=3306          # ← This is the actual port
```

**Common Ports:**
- `3306` = Default MySQL port (most common)
- `3307` = Alternative port (less common)
- `3308` = If multiple MySQL instances running

---

## ✅ Solution Options

### Option 1: Update Config.php to Use Correct Port (RECOMMENDED)

If MySQL is running on port **3306** (most XAMPP installations):

```php
// CHANGE THIS LINE:
$Conn = new mysqli("localhost", "root", "", "arabian_d", 3307);

// TO THIS:
$Conn = new mysqli("localhost", "root", "", "arabian_d", 3306);
```

### Option 2: Verify Database Exists

Before making changes, verify the database exists:

```bash
# Connect to MySQL (port 3306)
mysql -u root -h localhost -P 3306

# Inside MySQL prompt:
SHOW DATABASES;
```

You should see `arabian_d` in the list.

### Option 3: If Database Doesn't Exist, Create It

```sql
CREATE DATABASE arabian_d CHARACTER SET utf8 COLLATE utf8_general_ci;
```

---

## 🚀 Quick Fix Steps

### Step 1: Start MySQL
1. Open XAMPP Control Panel
2. Click **Start** next to MySQL
3. Wait 5-10 seconds for it to start

### Step 2: Determine Port
```powershell
# Test port 3306 (most common)
mysql -u root -h localhost -P 3306 -e "SELECT 1;"
```

### Step 3: Update Config.php
- If port 3306 works → Change `3307` to `3306` in Config.php line 13
- If port 3307 works → Leave it as is, check MySQL is running

### Step 4: Test Connection
- Refresh your browser
- You should see the login page now

---

## 🔧 Alternative Connection Strings

### If using localhost (default):
```php
$Conn = new mysqli("localhost", "root", "", "arabian_d", 3306);
```

### If using 127.0.0.1:
```php
$Conn = new mysqli("127.0.0.1", "root", "", "arabian_d", 3306);
```

### If password required:
```php
$Conn = new mysqli("localhost", "root", "your_password", "arabian_d", 3306);
```

### Omit port (uses default 3306):
```php
$Conn = new mysqli("localhost", "root", "", "arabian_d");
```

---

## 📋 Checklist

- [ ] MySQL service is running (check XAMPP Control Panel)
- [ ] Correct port identified (usually 3306, not 3307)
- [ ] Database `arabian_d` exists
- [ ] Config.php has correct port number
- [ ] Refresh browser and test login

---

## 🆘 Still Not Working?

### Check XAMPP MySQL Logs:
```
C:\xampp\mysql\data\mysql_error.log
```

### Common Issues & Solutions:

| Issue | Solution |
|-------|----------|
| MySQL not starting | Restart XAMPP, check if port is already in use |
| Port already in use | Change MySQL port or stop other services |
| Permission denied | Run XAMPP Control Panel as Administrator |
| Database doesn't exist | Create `arabian_d` database via phpMyAdmin |
| Wrong password | Verify MySQL root password (usually empty in XAMPP) |

---

## 📞 Get Help

### phpMyAdmin (Built-in XAMPP)
1. Go to `http://localhost/phpmyadmin`
2. Login as `root` (empty password)
3. Check if `arabian_d` database exists
4. Create it if needed

### MySQL Command Line (Direct)
```powershell
cd C:\xampp\mysql\bin
mysql -u root -h localhost -P 3306
```

---

**This guide will get your database connection working within 5 minutes!**
