# Development Notes - Loan_Cus.php v2.0
## Technical Documentation

---

## 📦 System Architecture

### File Structure
```
Arabian_D_Residence/
├── Loan_Cus.php (Main file - Improved v2.0)
├── Loan_Cus_backup.php (Original backup)
├── Loan_Cus_improved.php (Development version)
├── Config.php (Database connection & global functions)
├── Confirm.php (Authentication/confirmation)
├── jdf.php (Persian date library)
└── Img/ (Images directory)
```

### Database Tables
- `custumer_info` - Customer information
  - ID (Primary Key)
  - Name (Customer name)
  - Provice (Province)
  - Cus_type ('Loan' or 'Counter')
  
- `loan_tbl` - Transaction records
  - ID (Primary Key)
  - Cus_ID (Foreign Key)
  - Date (Transaction date, YYYY-MM-DD)
  - Item (Description)
  - Qty (Quantity)
  - Price (Unit price)
  - Cur_type (Currency: AF, K, USD)
  - Plus (Income/Exit amount)
  - Mines (Payment/Entrance amount)

---

## 🔧 Key Functions & Methods

### Security Functions

#### `sanitizeInput($input)`
```php
function sanitizeInput($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    return $input;
}
```
**Purpose:** Prevents XSS attacks by escaping HTML special characters
**Usage:** All user inputs from GET/POST

---

#### `isValidDate($date)`
```php
function isValidDate($date) {
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d && $d->format('Y-m-d') === $date;
}
```
**Purpose:** Validates date is in correct format
**Usage:** Before database insertion or filtering

---

### Data Functions

#### `getCurrentDateGregorian()`
```php
function getCurrentDateGregorian() {
    return date('Y-m-d');
}
```
**Purpose:** Returns today's date in database format
**Usage:** Auto-fill form date field

---

#### `formatCurrency($value)`
```php
function formatCurrency($value) {
    return number_format($value, 2, '.', ',');
}
```
**Purpose:** Formats numbers with thousands separator
**Usage:** Display all monetary values

---

## 🔒 Security Implementation

### SQL Injection Prevention

**Prepared Statements Pattern:**
```php
$stmt = $Conn->prepare("SELECT * FROM `loan_tbl` WHERE `Cus_ID`=? AND `Date` BETWEEN ? AND ?");
$stmt->bind_param("iss", $cus_id, $from_date, $to_date);
$stmt->execute();
$result = $stmt->get_result();
```

**Parameter Types:**
- `i` - Integer
- `s` - String
- `d` - Double/Float

---

### XSS Prevention

**All output escaped:**
```php
echo htmlspecialchars($user_input, ENT_QUOTES, 'UTF-8');
```

**Form values:**
```php
<input value="<?php echo htmlspecialchars($value); ?>">
```

---

## 📅 Date Handling System

### Gregorian vs Jalali
- **Database Storage:** Gregorian (YYYY-MM-DD)
- **Display:** Currently Gregorian (can extend for Jalali display)
- **Form Input:** HTML5 date picker (requires Gregorian)
- **Config.php:** Uses Jalali for display in other modules

### Date Filtering Logic
```php
// Build WHERE conditions dynamically
$where_conditions = ["`Cus_ID`=?", "`Cur_type`=?"];
$param_types = 'is';
$param_values = [$IE, $Cur_type];

if ($fromDate && $toDate) {
    $where_conditions[] = "`Date` BETWEEN ? AND ?";
    $param_types .= 'ss';
    $param_values[] = $fromDate;
    $param_values[] = $toDate;
}

$where_clause = implode(" AND ", $where_conditions);
```

---

## 💰 Balance Calculation System

### Loan Type Calculation
```
Running Balance = Previous Balance + Plus (Income) - Mines (Payment)
```

**Example:**
```
Date        Item    Plus    Mines   Balance
2026-05-10  Loan    1000    0       1000
2026-05-12  Pay     0       500     500
2026-05-14  Add     500     0       1000
```

### Counter Type Calculation
```
Running Balance = Previous Balance + Plus (Exit) - Mines (Entrance)
```

**Color Coding:**
- Income/Exit (Plus): Green
- Payment/Entrance (Mines): Red
- Balance: Blue (if negative) or Red (if positive)

---

## 📊 Query Optimization

### Before (Inefficient)
```php
// Query 1: Get records
$view_Data = $Conn->query("SELECT * FROM loan_tbl WHERE ...");
while ($A = $view_Data->fetch_assoc()) { ... }

// Query 2: Calculate totals again
$totalRow = $Conn->query("SELECT SUM(...) FROM loan_tbl WHERE ...");
```

### After (Optimized)
```php
// Query 1: Get prepared statement
$stmt = $Conn->prepare("SELECT * FROM loan_tbl WHERE ...");
$stmt->bind_param(...);
$stmt->execute();
$view_Data = $stmt->get_result();

// Query 2: Single aggregate query
$stmt = $Conn->prepare("SELECT SUM(Plus), SUM(Mines) FROM loan_tbl WHERE ...");
$stmt->bind_param(...);
$stmt->execute();
$totalRow = $stmt->get_result()->fetch_assoc();
```

---

## 🎯 Form Submission Handling

### Validation Flow
```
User Submits Form
    ↓
Check $_SERVER['REQUEST_METHOD'] === 'POST'
    ↓
Validate Input (sanitize, check required fields)
    ↓
Validate Date Format
    ↓
Prepare INSERT Query
    ↓
Execute Query with Error Handling
    ↓
Redirect (HTTP 303) or Show Error
```

### Header Redirects
```php
// Proper redirect after POST (HTTP 303 - See Other)
header("Location: ?Cur=" . urlencode($Cur_type) . "&ID=" . urlencode($IE), true, 303);
exit;
```
**Why HTTP 303:** Prevents form resubmission on page refresh

---

## 🎨 Frontend Implementation

### Dynamic Column Display
- **Loan Type:** Shows Item, Qty, Price, Plus, Mines
- **Counter Type:** Shows Item, Plus (Exit), Mines (Entrance)

### Real-time Calculations
```javascript
function calculateTotal() {
    var qty = document.getElementById("Qty_I").value || 0;
    var price = document.getElementById("Price_I").value || 0;
    document.getElementById("Plus_I").value = (qty * price).toFixed(2);
}
```

### Form Validation
```javascript
function validateLoanForm() {
    var date = document.querySelector('input[name="Date"]').value;
    var desc = document.querySelector('input[name="Des"]').value;
    
    if (!date || !desc.trim()) {
        alert('Please fill required fields');
        return false;
    }
    return true;
}
```

---

## 🔄 Request/Response Flow

### GET Request (View Data)
```
GET /Loan_Cus.php?ID=5&Cur=AF&from_date=2026-05-01&to_date=2026-05-15

↓ (Validate parameters)

Query database with:
- Cus_ID = 5
- Cur_type = 'AF'
- Date BETWEEN 2026-05-01 AND 2026-05-15

↓ (Fetch and format data)

Display table with running balances and totals
```

### POST Request (Add Entry)
```
POST /Loan_Cus.php?ID=5&Cur=AF
Data: Date=2026-05-16, Des=Test, Plus=1000, Mines=0

↓ (Validate all inputs)

INSERT INTO loan_tbl VALUES (...)

↓ (Success)

HTTP 303 Redirect back to view
```

### DELETE Request (via GET)
```
GET /Loan_Cus.php?ID=5&Cur=AF&Delid=123

↓ (Validate deletion is for same customer/currency)

DELETE FROM loan_tbl WHERE ID=123 AND Cus_ID=5 AND Cur_type='AF'

↓ (Success)

HTTP 303 Redirect back to view
```

---

## 🧠 Error Handling Strategy

### Database Errors
```php
$stmt = $Conn->prepare($query);
if (!$stmt) {
    echo "Query Error: " . $Conn->error;
    exit;
}
```

### Execution Errors
```php
if (!$stmt->execute()) {
    $message = "Database Error: " . $stmt->error;
    $messageType = "error";
}
```

### User Feedback
- ✅ Success: Redirect on successful operation
- ⚠️ Warning: Display message but allow retry
- ❌ Error: Show clear message with guidance

---

## 📈 Future Enhancements

### Recommended Improvements
1. **Jalali Calendar Support**
   - Display dates in Jalali format for reports
   - Store both Gregorian and Jalali in DB

2. **PDF Export**
   - Generate monthly statements
   - Export filtered data as PDF

3. **User Permissions**
   - Admin vs User roles
   - Audit trail for deletions

4. **Mobile Optimization**
   - Responsive design improvements
   - Touch-friendly buttons

5. **Advanced Reporting**
   - Monthly/yearly summaries
   - Trend analysis
   - Balance projections

6. **Batch Operations**
   - Import entries from CSV
   - Bulk edit/delete
   - Data validation on import

7. **API Integration**
   - RESTful API endpoints
   - Mobile app support
   - Third-party integrations

---

## 🧪 Testing Strategy

### Unit Tests Needed
- `isValidDate()` with various formats
- `sanitizeInput()` with XSS payloads
- `formatCurrency()` with edge values

### Integration Tests Needed
- Full POST submission flow
- Date range filtering accuracy
- Balance calculation accuracy
- Multiple currency handling

### Security Tests Needed
- SQL injection attempts
- XSS payload testing
- CSRF token validation (if added)
- Unauthorized access attempts

---

## 📝 Code Standards

### Naming Conventions
- Functions: `camelCase` with verb prefix (e.g., `validateInput`)
- Variables: `camelCase` or `$IE` for legacy
- Constants: `UPPERCASE_WITH_UNDERSCORES`

### Indentation
- Use 4 spaces per level
- HTML within PHP: Consistent indentation

### Comments
- Function: Describe purpose and parameters
- Complex logic: Explain why, not what
- TODO: Mark future improvements clearly

---

## 🚀 Deployment Checklist

- [ ] Database backup taken
- [ ] Original file backed up
- [ ] New file copied to production
- [ ] Permissions verified (readable, writable)
- [ ] Test with production data
- [ ] Monitor error logs for 24 hours
- [ ] User training provided if needed
- [ ] Documentation updated

---

## 📞 Support Information

### Common Issues & Solutions

| Issue | Cause | Solution |
|-------|-------|----------|
| Entries not showing | Customer ID mismatch | Verify ID in URL |
| Wrong balance | NULL in database | Run data cleanup script |
| Date filter not working | Invalid date format | Use YYYY-MM-DD |
| Form won't submit | Missing required field | Check validation alert |
| Slow performance | Large dataset | Add database indexes |

---

**Document Version:** 1.0
**Created:** May 16, 2026
**For Developers:** Core team members and future maintainers
**Confidentiality:** Internal Use Only
