<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
body{
    width: 100%;
    padding: 0px;
    margin: 0px;
    display: flex;
    align-items: center;
    direction:rtl;
    flex-direction:column;
}
img{
    width: 100%;
}
table{
    width: 100%;
    border: 1px solid;
    border-collapse: collapse;
}
td
{
    padding: 6px;
    border: 1px solid;
    font-weight: 900;
    text-align:center;
}
th{
    padding: 6px;
    border: 1px solid;
    font-weight: 900;
}
th,td input{
    width: 100%;
    background: transparent;
    border: none;
    padding: 0px;
    outline: none;
    font-weight: 900;
}
caption{
    font-size: 30px;
    font-weight: 900;
    text-align: inherit;
    padding: 5px;
}
    
</style>

</head>
<body>
<?php 
include ("Confirm.php");
include ("Config.php");

if (isset($_POST["SRCH"])) {
    $Cur_Date = $_POST["Datinput"];
}

echo "<title>Arabian D Residence | ", @$Cur_Date ," راپور</title>";
?>

    <img src="Img/D1.jpg" alt="" srcset="">
    <table>
    <tr>
        <td width='100px'> تاریخ </td>
        <td  style='background-image:url(Img/blue2.png);'>
            <form method="POST">
                <input type="text" min='1' name="Datinput" value="<?php echo $Cur_Date;?>">
                <input type="submit" name='SRCH' style='display:none;'>
            </form>
        </td>
    </tr>
    </table>
    <br>
    <table>
    <caption>خریدات</caption>
    <tr>
        <td>شمیره</td>
        <td>مشتری نوم</td>
        <td>جنس نوم</td>
        <td>بیل نمبر</td>
        <td>مقدار</td>
        <td>قیمت</td>
        <td>ټوټل حساب</td>
    </tr>
    <?php
    $ShowItem = $Conn->query("SELECT * FROM `buy_info` WHERE Bill_Num>0 AND Date='$Cur_Date' ORDER BY Date DESC");
    $x = 1;
    $MOneyhAF = 0;
    $MOneyhK = 0;
    $MOneyhUSD = 0;
    while ($A = $ShowItem->fetch_assoc()) {
        echo "<tr>";
        $idRec = $A["ID"];
        echo "<td>". $x++ ."</td>";
        $idCus = $A["Cus_Name"];
        $Cus_Cus_data = $Conn->query("SELECT Name FROM `custumer_info` WHERE ID='$idCus'")->fetch_assoc();
        echo "<td>". $Cus_Cus_data["Name"] ."</td>";
        echo "<td>". $A["Item_Name"] ."</td>";
        echo "<td>". $A["Bill_Num"] ."</td>";
        echo "<td>". $A["Item_qty"] ."</td>";
        echo "<td>". $A["Item_price"] ."</td>";
        echo "<td>". $A["Total_price"]." ", Find_cur($A["Cur_type"]);
        if ($A["Cur_type"] === "AF") {
            $MOneyhAF += $A["Total_price"];
            }elseif ($A["Cur_type"] === "K") {
            $MOneyhK += $A["Total_price"];
            }elseif ($A["Cur_type"] === "USD") {
            $MOneyhUSD += $A["Total_price"];
            }
        echo "</tr>";
    }
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "افغانی:" ."</td>";
    echo "<td>". "$MOneyhAF" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "کلدار:" ."</td>";
    echo "<td>". "$MOneyhK" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "دالر:" ."</td>";
    echo "<td>". "$MOneyhUSD" ."</td>";
    echo "</tr>";

    ?>
    </table>
    <br>
    <table>
    <caption>واپیسی اجناس</caption>
    <tr>
        <td>شمیره</td>
        <td>مشتری نوم</td>
        <td>جنس نوم</td>
        <td>بیل نمبر</td>
        <td>مقدار</td>
        <td>قیمت</td>
        <td>ټوټل حساب</td>
    </tr>
    <?php
    $ShowItem = $Conn->query("SELECT * FROM `buy_info` WHERE Bill_Num<0 AND Date='$Cur_Date' ORDER BY Date DESC");
    $x = 1;
    $MOneyhAF = 0;
    $MOneyhK = 0;
    $MOneyhUSD = 0;
    while ($A = $ShowItem->fetch_assoc()) {
        echo "<tr>";
        $idRec = $A["ID"];
        echo "<td>". $x++ ."</td>";
        $idCus = $A["Cus_Name"];
        $Cus_Cus_data = $Conn->query("SELECT Name FROM `custumer_info` WHERE ID='$idCus'")->fetch_assoc();
        echo "<td>". $Cus_Cus_data["Name"] ."</td>";
        echo "<td>". $A["Item_Name"] ."</td>";
        echo "<td>". $A["Bill_Num"] ."</td>";
        echo "<td>". $A["Item_qty"] ."</td>";
        echo "<td>". $A["Item_price"] ."</td>";
        echo "<td>". $A["Total_price"]." ", Find_cur($A["Cur_type"]);

        if ($A["Cur_type"] === "AF") {
            $MOneyhAF += $A["Total_price"];
            }elseif ($A["Cur_type"] === "K") {
            $MOneyhK += $A["Total_price"];
            }elseif ($A["Cur_type"] === "USD") {
            $MOneyhUSD += $A["Total_price"];
            }
        echo "</tr>";
    }
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "افغانی:" ."</td>";
    echo "<td>". "$MOneyhAF" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "کلدار:" ."</td>";
    echo "<td>". "$MOneyhK" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "دالر:" ."</td>";
    echo "<td>". "$MOneyhUSD" ."</td>";
    echo "</tr>";

    ?>
    </table>
    <br>
    <table>
    <caption>استعمال سوی اجناس په پروژه ګی</caption>
    <tr>
    <td>شمیره</td>
    <td>جنس نوم</td>
    <td>پروزه</td>
    <td>مقدار</td>
    <td>قیمت</td>
    <td>ټوټل حساب</td>
    <td>منزل</td>
    </tr>
    <?php
    $ShowItem = $Conn->query("SELECT * FROM `project_exp` WHERE Date='$Cur_Date'");
    $x = 1;
    $MOneyhAF = 0;
    $MOneyhK = 0;
    $MOneyhUSD = 0;
    while ($A = $ShowItem->fetch_assoc()) {
        echo "<tr>";
        $idRec = $A["ID"];
        echo "<td>". $x++ ."</td>";
        echo "<td>". $A["Item_Name"] ."</td>";
        $IDProject = $A["Project_ID"];
        $ShowItem1 = $Conn->query("SELECT * FROM `project_info` WHERE Pro_ID='$IDProject'")->fetch_assoc();
        $Pro_Name = $ShowItem1["Project_Name"];
        $Pro_Owner_Name = $ShowItem1["Pro_Owner"];
        echo "<td>". "$Pro_Name / $Pro_Owner_Name"."</td>";
        
        echo "<td>". $A["Qty"] ."</td>";
        echo "<td>". $A["Price"] ."</td>";
        $Cur = $A["Cur_type"];
        echo "<td>". $A["total"]."&nbsp;&nbsp;&nbsp;" ;
        echo Find_cur($Cur);
        echo "</td>";
        echo "<td>". $A["Floor"] ."</td>";

        if ($A["Cur_type"] === "AF") {
            $MOneyhAF += $A["total"];
            }elseif ($A["Cur_type"] === "K") {
            $MOneyhK += $A["total"];
            }elseif ($A["Cur_type"] === "USD") {
            $MOneyhUSD += $A["total"];
            }
        echo "</tr>";
    }
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "افغانی:" ."</td>";
    echo "<td>". "$MOneyhAF" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "کلدار:" ."</td>";
    echo "<td>". "$MOneyhK" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "دالر:" ."</td>";
    echo "<td>". "$MOneyhUSD" ."</td>";
    echo "</tr>";
    ?>
    </table>
    <br>
    <table>
    <caption>ګاریګرانو ته رسیده ګی</caption>
    <tr>
    <td>شمیره</td>
    <td>گاریگر نوم</td>
    <td>پلار نوم</td>
    <td>وظیفه</td>
    <td>تفصیل</td>
    <td>پیسی</td>

    </tr>
    <?php
    $ShowItem = $Conn->query("SELECT * FROM `emp_accountv2` WHERE `Date`='$Cur_Date' AND `Type`='Pay'");
    $x = 1;
    $MOneyhAF = 0;
    $MOneyhK = 0;
    $MOneyhUSD = 0;
    while ($A = $ShowItem->fetch_assoc()) {
        echo "<tr>";
        $idRec = $A["ID"];
        echo "<td>". $x++ ."</td>";
        $emp_id = $A["Emp_ID"];
        $Counter_data = $Conn->query("SELECT * FROM emp_tbl WHERE ID='$emp_id'")->fetch_assoc();
        $name = $Counter_data["Name"];
        $Job = $Counter_data["JOB"];
        $F_Name = $Counter_data["F_Name"];
        echo "<td>". "$name - $F_Name / $Job" ."</td>";
        echo "<td>". "$F_Name" ."</td>";
        echo "<td>". "$Job" ."</td>";
        $Cur = $Counter_data["Cur_type"];

        echo "<td>". $A["Description"] ."</td>";
        echo "<td>". $A["Amount"]." ";
        echo Find_cur($Cur) ."</td>";
        if ($Counter_data["Cur_type"] === "AF") {
            $MOneyhAF += $A["Amount"];
            }elseif ($Counter_data["Cur_type"] === "K") {
            $MOneyhK += $A["Amount"];
            }elseif ($Counter_data["Cur_type"] === "USD") {
            $MOneyhUSD += $A["Amount"];
            }

        echo "</tr>";
    }

    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "افغانی:" ."</td>";
    echo "<td>". "$MOneyhAF" ."</td>";
    echo "</tr>";

    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "کلدار:" ."</td>";
    echo "<td>". "$MOneyhK" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "دالر:" ."</td>";
    echo "<td>". "$MOneyhUSD" ."</td>";
    echo "</tr>";
    ?>
    </table>
    <br>
    <table>
    <caption>مصارفات</caption>
    <tr>
    <td>شمیره</td>
    <td>مصرف نوعیات</td>
    <td>تفصیل</td>
    <td>پیسی</td>

    </tr>
    <?php
    $ShowItem = $Conn->query("SELECT * FROM `expence` WHERE `Date_`='$Cur_Date'");
    $x = 1;
    $MOneyhAF = 0;
    $MOneyhK = 0;
    $MOneyhUSD = 0;

    while ($A = $ShowItem->fetch_assoc()) {
        echo "<tr>";
        echo "<td>". $x++ ."</td>"; 
        echo "<td>". $A["Type"] ."</td>";
        echo "<td>". $A["Des"] ."</td>";
        echo "<td>". $A["Money"]." ";
        $Cur = $A["Cur_type"];
        echo Find_cur($Cur) ."</td>";

        if ($Cur === "AF") {
            $MOneyhAF += $A["Money"];
            }elseif ($Cur === "K") {
            $MOneyhK += $A["Money"];
            }elseif ($Cur === "USD") {
            $MOneyhUSD += $A["Money"];
            }



        echo "</tr>";
    }

    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "افغانی:" ."</td>";
    echo "<td>". "$MOneyhAF" ."</td>";
    echo "</tr>";

    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "کلدار:" ."</td>";
    echo "<td>". "$MOneyhK" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "دالر:" ."</td>";
    echo "<td>". "$MOneyhUSD" ."</td>";
    echo "</tr>";
    ?>
    </table>
    <br>
    <table>
    <caption>راوړونکی مشتری ته رسید</caption>
    <tr>
    <td>شمیره</td>
    <td>مشتری نوم</td>
    <td>تفصیل</td>
    <td>پیسی</td>

    </tr>
    <?php
    $ShowItem = $Conn->query("SELECT * FROM `buy_info` WHERE `Date`='$Cur_Date' AND `Bill_Num`='0'");
    $x = 1;
    $MOneyhAF = 0;
    $MOneyhK = 0;
    $MOneyhUSD = 0;
    while ($A = $ShowItem->fetch_assoc()) {
        echo "<tr>";
        $idRec = $A["ID"];
        echo "<td>". $x++ ."</td>";
        echo "<td>". $A["Cus_Name"] ."</td>";
        echo "<td>". $A["Description"] ."</td>";
        echo "<td>". $A["Total_price"]. " ";
        $Cur = $A["Cur_type"];
        echo   Find_cur($Cur) ."</td>";

        if ($Cur === "AF") {
            $MOneyhAF += $A["Total_price"];
            }elseif ($Cur === "K") {
            $MOneyhK += $A["Total_price"];
            }elseif ($Cur === "USD") {
            $MOneyhUSD += $A["Total_price"];
            }


        echo "</tr>";
    }

    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "افغانی:" ."</td>";
    echo "<td>". "$MOneyhAF" ."</td>";
    echo "</tr>";

    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "کلدار:" ."</td>";
    echo "<td>". "$MOneyhK" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "دالر:" ."</td>";
    echo "<td>". "$MOneyhUSD" ."</td>";
    echo "</tr>";
    ?>
    </table>
    <br>
    <table>
    <caption>بازار مشتریانو و صرافی ته رسید</caption>
    <tr>
    <td>شمیره</td>
    <td>مشتری نوم</td>
    <td>تفصیل</td>
    <td>مقدار</td>
    <td>قیمت</td>
    <td>پیسی</td>
    <td>رسیدات</td>

    </tr>
    <?php
    $ShowItem = $Conn->query("SELECT * FROM `loan_tbl` WHERE `Date`='$Cur_Date' ORDER BY Date ");
    $x = 1;
    $MOneyhAF = 0;
    $MOneyhK = 0;
    $MOneyhUSD = 0;
    $MOneyhAFM = 0;
    $MOneyhKM = 0;
    $MOneyhUSDM = 0;

    while ($A = $ShowItem->fetch_assoc()) {
        echo "<tr>";
        $idRec = $A["Cus_ID"];
        echo "<td>". $x++ ."</td>";
        $Cus_Cus_data = $Conn->query("SELECT Name FROM `custumer_info` WHERE ID='$idRec'")->fetch_assoc();
        echo "<td>". $Cus_Cus_data["Name"] ."</td>";

        echo "<td>". $A["Item"]. "</td>";
        echo "<td>". $A["Qty"]. "</td>";
        echo "<td>". $A["Price"]. "</td>";
        $CurP = $A["Cur_type"];

        echo "<td>". $A["Plus"]. " ";
        echo   Find_cur($CurP) ."</td>";

        echo "<td>". $A["Mines"]. " ";
        echo   Find_cur($CurP) ."</td>";
    
        if ($CurP === "AF") {
            $MOneyhAF += $A["Plus"];
            $MOneyhAFM += $A["Mines"];
            }elseif ($CurP === "K") {
            $MOneyhK += $A["Plus"];
            $MOneyhKM += $A["Mines"];
            }elseif ($CurP === "USD") {
            $MOneyhUSD += $A["Plus"];
            $MOneyhUSDM += $A["Mines"];
            }


        echo "</tr>";
    }

    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "افغانی:" ."</td>";
    echo "<td>". "$MOneyhAF" ."</td>";
    echo "<td>". "$MOneyhAFM" ."</td>";
    echo "</tr>";

    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "کلدار:" ."</td>";
    echo "<td>". "$MOneyhK" ."</td>";
    echo "<td>". "$MOneyhKM" ."</td>";
    echo "</tr>";
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td>". "دالر:" ."</td>";
    echo "<td>". "$MOneyhUSD" ."</td>";
    echo "<td>". "$MOneyhUSDM" ."</td>";
    echo "</tr>";
    ?>
    </table>
</body>
</html>