<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<!-- <link rel="stylesheet" href="StyleofRep.css"> -->
<?php
include ("Confirm.php");
include ("Config.php");
if (isset($_GET["Cur"])) {
$Cur = $_GET["Cur"];
}else {
$Cur = "AF";
}
$Date = $des = $debit = $crdit = "";
if (isset($_POST["Sumbit_N"])) {
$Date = $_POST["Date"];
$Cur = $_GET["Cur"];
$des = $_POST["Description"];
$opt = $_POST["opt"];
$money = $_POST["money"];
if ($opt === "+") {
$Conn->query("INSERT INTO daily_activity(Date, Description,T_type, Plus, Cur_type) VALUES (
'$Date','$des','$opt','$money','$Cur')");
}else {
$Conn->query("INSERT INTO daily_activity(Date, Description,T_type, Mines, Cur_type) VALUES (
'$Date','$des','$opt','$money','$Cur')");
}
echo "<script>window.location.href='Daily_Tran.php?Cur=$Cur';</script>"; 
}
if (isset($_GET["IDDel"])) {
$Cur = $_GET["Cur"];
$IDDel = $_GET["IDDel"];
$Cur_Date = $_GET["Date"];
$Conn->query("DELETE FROM daily_activity WHERE ID='$IDDel'");
echo "<script>window.location.href='Daily_Tran.php?Cur=$Cur&Date=$Cur_Date';</script>"; 
}
if (isset($_POST["Find-D"])) {
$Cur_Date = $_POST["Din"];
}elseif (isset($_GET["Date"])) {
$Cur_Date = $_GET["Date"];
}

// $Day = $Conn->query("")




?>
<title>Arabian D Residence | <?php echo "" , Find_cur($Cur) ," روز نامچه"; ?></title>
<style>
body{display:flex;direction:rtl;justify-content: center;}
.buton {
width: 100%;
display: flex;
justify-content: space-between;
font-weight: 900;position: relative;
box-sizing: border-box;
flex-direction: row;
}
.buton a{
color: red;
text-decoration: none;
font-family: cursive;
position:absolute;
margin-top: 10px;
margin-right: 90%;
font-weight: 900;
font-family: initial;
}
.buton p, .buton a{
line-height: 0;
height: 0px;
}
table {
    width:100%;
    border-collapse: collapse;
}

td
{
    padding: 3px;
    margin: 0px;direction:rtl;
    border: 1px black solid;
    font-size:15px;
    text-align:center;
    border: 0.5px solid gray;
    font-weight:900;
    border-radius:5px;
}
td input, td select 
{
    width:100%;
    height:100%;
    font-size: 10px;
    font-weight: 900;
    outline:none;
    border:none;
    background-color: transparent;
    text-align:center;
}
.page
{
    width: 100%;
    padding: 5px;
    box-sizing: border-box;
}
.tit
{
    display: flex;
    justify-content: space-between;
    font-size: 20px;
}
.tit div
{
    width: 500px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: row;
}
.tit div input
{
    padding:5px;
    font-size:20px;
    outline:none;
    border:none;
    text-align: right;
}
</style>
</head>
<body>
<div class="page">
<div class="header">
<a href="Select_Cur.php?COF=روزنامچه" style="position: absolute;left: 0px;top:0px;"><img src="Img/Back.png" alt="Back" width='30px'></a>

</div>

<?php echo "<h1 style='text-align: center;'>" , Find_cur($Cur) ," روز نامچه</h1>" ; ?>
<form class="tit" action="" method='POST'>
<!-- <div><label for="">ورځ:</label><input type="text" value='<?php echo jdate("l"); ?>'></div> -->
<div><label for="">تاریخ:</label><input type="text" name='Din' value='<?php echo $Cur_Date; ?>'><input type="submit" Name="Find-D" style='display:none'></div>
</form>
<br>
<table>
<tr style='border:none'>
<?php
$Balanceof = $Conn->query("SELECT SUM(Plus) AS Plus,SUM(Mines) AS Mines FROM daily_activity WHERE Cur_type='$Cur' AND Date<'$Cur_Date' ORDER BY ID")->fetch_assoc();
// Echo "<td width='170px'>سابقه حساب</td>";
// $prevMoney = $Balanceof["Plus"]-$Balanceof["Mines"];
// echo "<td>", $prevMoney ,"</td>";
?>

</tr>
<tr>
<td>تاریخ</td>
<td WIDTH='500px'>تفصیلات</td>
<td>راغلی پیسی</td>
<td>کاریگر</td>
<td>آشپزخانه</td>
<td>ماشینری</td>
<td>شرکت</td>
<td>مشتریان</td>
<td>نور مصارفات</td>
<!-- <td width='100px'>تجری</td> -->
</tr>
<?php
$activaty = $Conn->query("SELECT * FROM daily_activity WHERE Cur_type='$Cur' AND date='$Cur_Date' ORDER BY ID");
// $Balance = $prevMoney;
$pl = 0;
$Emp = 0;
$Kit = 0;
$nach = 0;
$COr = 0;
$Cus = 0;
$etc = 0;

while ($BB = $activaty->fetch_assoc()) {
$id = $BB["ID"];
echo "<tr>";
echo "<td>", $BB["Date"] ," <a style='text-decoration:none;' href='?IDDel=$id&Cur=$Cur&Date=$Cur_Date'>-</a></td>";
echo "<td>", $BB["Description"] ,"</td>";

if ($BB["T_type"] === "+") {
    // =======================================================================================
echo "<td style='Color:blue;'>", $BB["Plus"] ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
$pl += $BB["Plus"];
}elseif ($BB["T_type"] === "A-") {
    // =======================================================================================
$Kit += $BB["Mines"];
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td style='Color:red;'>", $BB["Mines"] ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
}elseif ($BB["T_type"] === "E-") {
    // =======================================================================================
echo "<td>", "" ,"</td>";

echo "<td style='Color:red;'>", $BB["Mines"] ,"</td>";
echo "<td>", "" ,"</td>";
$Emp += $BB["Mines"];
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
}elseif ($BB["T_type"] === "M-") {
    // =======================================================================================
$nach += $BB["Mines"];
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td style='Color:red;'>", $BB["Mines"] ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
}elseif ($BB["T_type"] === "Q-") {
    // =======================================================================================
$COr += $BB["Mines"];

echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td style='Color:red;'>", $BB["Mines"] ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";

}elseif ($BB["T_type"] === "C-") {
    // =======================================================================================
echo "<td>", "" ,"</td>";
$Cus += $BB["Mines"];

echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td style='Color:red;'>", $BB["Mines"] ,"</td>";
echo "<td>", "" ,"</td>";

}elseif ($BB["T_type"] === "Etc") {
    // =======================================================================================
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";    
$etc += $BB["Mines"];

echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td style='Color:red;'>", $BB["Mines"] ,"</td>";
}elseif ($BB["T_type"] === "-") {
    // =======================================================================================
echo "<td style='Color:red;'>", $BB["Mines"] ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
echo "<td>", "" ,"</td>";
}

// echo "<td>", $BB["Plus"] ,"</td>";
// echo "<td>", $BB["Mines"] ,"</td>";
// if ($BB["Plus"]>0) {
//     $Balance += $BB["Plus"];
// }elseif ($BB["Mines"]>0) {
//     $Balance -= $BB["Mines"];
// }
// $TGet += $BB["Plus"];
// $Pay += $BB["Mines"];


echo "</tr>";
}

?>
<tr style='border:none;'>
<form action="<?php echo "?Cur=$Cur"; ?>" Method='POST' autocomplete="off">
<td colspan='1'><input type="text" name="Date" value="<?php echo $Cur_Date; ?>" readonly></td>
<td colspan='5'><input type="text" name="Description" id="" required></td>
<td colspan='2'>
<select name="opt">
<option value=""></option>
<option value="+">رسید پیسی</option>
<option value="E-">کاریگر</option>
<option value="A-">آشپزخانه</option>
<option value="M-">ماشینری</option>
<option value="Q-">شرکت</option>
<option value="C-">مشتریان</option>
<option value="Etc">نور نوع مصارف</option>
<!-- <option value="-">برده گی</option> -->

</select>
</td>
<td colspan='1'><input type="number" name="money" id="" ></td>
<input type="submit" name='Sumbit_N' style="display:none;">
</tr>
<?php

echo "<tr style='background: #1ee765;color: black;font-size:15px'>";
echo "<td>", "جمله حساب:" ,"</td>";
echo "<td style='Color:black;font-weight:900;'>", "" ,"</td>";
echo "<td>", "$pl" ,"</td>";
echo "<td>", "$Emp" ,"</td>";
echo "<td>", "$Kit" ,"</td>";
echo "<td>", "$nach" ,"</td>";
echo "<td>", "$COr" ,"</td>";
echo "<td>", "$Cus" ,"</td>";
echo "<td>", "$etc" ,"</td>";
// echo "<td>", "" ,"</td>";
echo "</tr>";

echo "<tr>";
echo "<td>", "جمله ", Find_cur($Cur) ," مصارف:" ,"</td>";
echo "<td style='Color:red;font-weight:800;'>", $Emp+$Kit+$nach+$COr+$Cus+$etc ,"</td>";
echo "</tr>";

// echo "<tr>";
// echo "<td>", "جمله پیسی په تجری کی" ,"</td>";
// echo "<td style='Color:Blue;font-weight:900;'>", $Balance ,"</td>";

// echo "</tr>";


?>

</form>
</table>
</div>
</body>
</html>
