<?php
include ("Confirm.php");
include ("Config.php");
if(isset($_GET["logout"])){
    session_destroy();
    echo "<script>window.location.href='Login_Page.php?Aut=No';</script>"; 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Arabian D Residence | Dashboard</title>
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    }
    .header{
    width: 100%;
    height: 257px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 95%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    }
    .body_page .btn{
    height: 80px;
    border: 0.5px solid darkgray;
    width: 290px;
    margin: 5px;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 40%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:50%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    </style>
</head>
<body>
    <div class="header">
        <div></div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="210px" height="210px" alt="Logo"><p style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo "$Cur_Date"; ?> </p></div>
        <div class="logount">
        <a href="?logout=ok" style="position: absolute;right: 0px;top:0px;padding: 15px;background-color: red;margin: 15px;width: 50px;font-weight: 900;color: black;text-decoration: none;">خروج</a>
        </div>
    </div>
    <div class="body_page">
        <div class="btn">
            <a href="Select_Cur.php?COF=روزنامچه" class="img"><img src="Img/NoteBook.png" width="70px;"></a>
            <p class="contente">روزنامچه</p>
        </div>

        <div class="btn">
            <a href="Daily_Activity.php" class="img"><img src="Img/NoteBook.png" width="70px;"></a>
            <p class="contente">د کار ورځنی راپور</p>
        </div>

        <div class="btn">
            <a href="Expence.php" class="img"><img src="Img/NoteBook.png" width="70px;"></a>
            <p class="contente">مصارفات</p>
        </div>

        <div class="btn">
            <a href="Select_Type.php?Tof=مشتریانو" class="img"><img src="Img/Customer.png" width="70px;"></a>
            <p class="contente">مشتریان</p>
        </div>

        <div class="btn">
            <a href="Bill_return.php" class="img"><img src="Img/Sell.png" width="70px;"></a>
            <p class="contente"> واپیسی بیل </p>
        </div>

        <div class="btn">
            <a href="Buy_.php" class="img"><img src="Img/Sell.png" style="transform: rotateY(160deg);" width="70px;"></a>
            <p class="contente">خریدات</p>
        </div>

        <div class="btn">
            <a href="Sell_index.php" class="img"><img src="Img/Sell.png" width="70px;"></a>
            <p class="contente">فروشات</p>
        </div>

        <div class="btn">
            <a href="Labor_Index.php" class="img"><img src="Img/Emp.png" width="70px;"></a>
            <p class="contente">ګاریګرانو حساب</p>
        </div>


        <div class="btn">
            <a href="attendance.php" target='_blank' class="img"><img src="Img/attendance.png" width="70px;"></a>
            <p class="contente">ګاریګرانو حاضری</p>
        </div>

        <div class="btn">
            <a href="Project_index.php" class="img"><img src="Img/NoteBook.png" width="70px;"></a>
            <p class="contente">پروژی لیست</p>
        </div>

        <div class="btn">
            <a href="Project_Report.php" class="img"><img src="Img/NoteBook.png" width="70px;"></a>
            <p class="contente">د پروژی راپور</p>
        </div>

        <div class="btn">
            <a href="All_report.php" class="img"><img src="Img/NoteBook.png" width="70px;"></a>
            <p class="contente">د شرکت عمومی راپور</p>
        </div>


    </div>
    <div class="fotter">

    </div>
</body>
</html>