<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Arabian D Residence | Attendance</title>
<style>
body{direction:rtl;}
.tit
{
    padding: 5px;
    display: flex;
    flex-wrap: wrap;width: 100%;
    flex-direction: row;
    justify-content: space-between;
    align-items: stretch;
    font-size:22px;
}
th,td{
    border: 2px solid black;
    text-align:center;
}
.tit div input
{
    border: none;
    outline: none;
    font-size:22px;
    padding:5px;
}
</style>
<?php
include ("Confirm.php");
include ("Config.php");

?>
</head>
<body style='display: flex;
    justify-content: center;'>
    <div style='display: flex;justify-content: center;flex-direction: column;align-items: center;'>
    <a href='Attendance.php'><img width='100%' src="Img/C1.jpg" alt=""></a>
    <form class="tit" action="" method='POST'>
    <!-- <div><label for="">ورځ:</label><input type="text" value='<?php echo jdate("l"); ?>' readonly></div> -->
    <div><label for="">تاریخ:</label><input type="date" value='<?php echo $Cur_Date; ?>'></div><input type="submit" value="" style='display:none'>
    </form>
    <p style='    font-size: 30px;
    font-family: system-ui;
    font-weight: 600;'>دکارمندانو دمعاشاتو لیست </p>
    <table width='100%' style='border-collapse: collapse;'>
    <tr height='35px'>
    <th>نوم</th>
    <th>پلار نوم</th>
    <th>وظیفه</th>
    <th width='50px;'>تعداد روز</th>
    <th width='80px;'>طلب معاش</th>
    <th width='90px;'>اضافه کاری </th>
    <th>جمله</th>
    <th>برده ګی</th>
    <th>الباقی</th>
    <th width='100px'>پنجشنبه</th>
    </tr>
    <?php
    $All_Emp = $Conn->query("SELECT * FROM emp_tbl WHERE End_Date='فعال' ORDER BY ID");
    $x = 1;
    $TotalAF = 0;
    $TotalK = 0;

    while ($Emp = $All_Emp->fetch_assoc()) {
        $Emp_Id = $Emp["ID"];
        $Stat_Aco = $Emp["Start_Date_Acc"];
        $Cur_ = $Emp["Cur_type"];
    
        $Account_Emp = $Conn->query("SELECT SUM(`Day_Count`) as TDay FROM `emp_accountv2` WHERE type='P' AND Emp_ID = '$Emp_Id' and Date>='$Stat_Aco'")->fetch_assoc();
        $Account_EmpM = $Conn->query("SELECT SUM(`Amount`) as TMoney FROM `emp_accountv2` WHERE (type='P') AND Emp_ID = '$Emp_Id'")->fetch_assoc();
        $Account_EmpMOver = $Conn->query("SELECT SUM(`Amount`) as TMoney,SUM(`Day_Count`) as OverMoney  FROM `emp_accountv2` WHERE (type='Over') AND Emp_ID = '$Emp_Id'")->fetch_assoc();
        $Account_EmpPay = $Conn->query("SELECT SUM(`Amount`) as TMoney FROM `emp_accountv2` WHERE type='Pay' AND Emp_ID = '$Emp_Id'")->fetch_assoc();
    
    if ($Account_Emp["TDay"] >= 30 && (($Account_EmpMOver["TMoney"]+$Account_EmpM["TMoney"])-$Account_EmpPay["TMoney"]) >= $Emp["Salary"]) {
        echo "<tr style='background-color:lightgreen;Color:Blue;font-weight:900;'>";
    }else {
        echo "<tr>";
    }
    // echo "<td>", "<b>$x</b> | <b>MOGW-$Emp_Id</b> " ,"</td>";
    echo "<td>", $Emp["Name"] ,"</td>";
    echo "<td>", $Emp["F_Name"] ,"</td>";
    echo "<td>", $Emp["JOB"] ,"</td>";

    echo "<td>", $Account_Emp["TDay"],"</td>";
    echo "<td>", $Account_EmpM["TMoney"] ,"</td>";
    echo "<td>", $Account_EmpMOver["OverMoney"], ' -/- ', $Account_EmpMOver["TMoney"] ,"</td>";
    echo "<td>", $Account_EmpMOver["TMoney"]+$Account_EmpM["TMoney"] ,"</td>";
    echo "<td>", $Account_EmpPay["TMoney"] ,"</td>";
    if (($Account_EmpMOver["TMoney"]+$Account_EmpM["TMoney"])-$Account_EmpPay["TMoney"] < 0) {
        echo "<td style='Color:red;font-weight:800;'>", ($Account_EmpMOver["TMoney"]+$Account_EmpM["TMoney"])-$Account_EmpPay["TMoney"] ,"</td>";
    }else {
        echo "<td style='Color:green;font-weight:800;'>", ($Account_EmpMOver["TMoney"]+$Account_EmpM["TMoney"])-$Account_EmpPay["TMoney"] ,"</td>";
        if ($Cur_ === "AF") {
        $TotalAF += ($Account_EmpMOver["TMoney"]+$Account_EmpM["TMoney"])-$Account_EmpPay["TMoney"];
        }elseif ($Cur_ === "K") {
        $TotalK += ($Account_EmpMOver["TMoney"]+$Account_EmpM["TMoney"])-$Account_EmpPay["TMoney"];
        }
    }
    echo "<td>", "" ,"</td>";

    echo "</tr>";
    $x++;

    }


    ?>
    
<tr>
<td height='50px' rowspan='2'>جمله</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><b><?php echo 
"
افغانی: $TotalAF <br>

";
; ?></b></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><b><?php echo "کلدار: $TotalK"; ?></b></td>
<td></td>
</tr>
    </table>
    </div>
</body>
</html>