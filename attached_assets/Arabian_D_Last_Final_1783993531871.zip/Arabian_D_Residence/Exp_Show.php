<?php
include ("Confirm.php");
include ("Config.php");
    
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    }
    .body_page{
    background: white;
    /* box-shadow: 2px 4px 11px -2px; */
    width: 98%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-direction:column;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    }
    .body_page .btn{
    height: 80px;
    border: 0.5px solid darkgray;
    width: 290px;
    margin: 5px;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 40%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:50%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    form input,Select{
        width: 230px;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;
    }
    label{
        font-weight: 900;

    }
    .body_page table{
    width: 100%;
    /* border-collapse: collapse; */

    }
    .body_page table td,th{
        border: 1px solid;
    padding: 4px;
    border-radius: 5px;
    text-align: center;
    font-weight:600;
    }
    </style>
</head>
<body>
<?php
$SDate = $Cur_Date;
$EDate = $Cur_Date;
@$Item_NameGet = $_GET["Item"];
if (isset($_POST["SrchDate"])) {
    $SDate = $_POST["SDate"];
    $EDate = $_POST["EDate"];

}
if (isset($_GET["Item"])) {
    $href = "?Item=$Item_NameGet";
}else {
    $href = "";
}
if (isset($_GET["Delid"])) {
    @$Item_NameGet = $_GET["Item"];
    @$DelID = $_GET["Delid"];
    $Conn->query("DELETE FROM `expence` WHERE ID='$DelID'");
    echo "<script>window.location.href='?Item=$Item_NameGet';</script>"; 

}
echo "<title>Arabian D Residence | ",$Item_NameGet," لیست</title>";
?>

<div class="body_page" style='direction:rtl'>
    <form action="<?php echo $href; ?>" method="post">
        <label for="">شروع تاریخ:</label><input type="text" name="SDate" value='<?php echo $SDate; ?>'>
        <label for="">ختم تاریخ:</label><input type="text" name="EDate" value='<?php echo $EDate; ?>'>
        <input type="submit" name='SrchDate' style="display:none">
    </form>
    <br><br>
    <table>
        <tr style="background-image:url(Img/Green.png);">
            <th width='90px'>شماره</th>
            <th>تاریخ</th>
            <th>تفصیل</th>
            <th>پیسی</th>
            <th>...</th>
        </tr>
        <?php
        if (@$_GET["Item"] === "All") {
            $ShowItem = $Conn->query("SELECT * FROM `expence` WHERE `Date_` BETWEEN '$SDate' and '$EDate' ORDER BY Date_,Cur_type ASC");
        }else {
            $ShowItem = $Conn->query("SELECT * FROM `expence` WHERE `Type` = '$Item_NameGet' AND `Date_` BETWEEN '$SDate' and '$EDate' ORDER BY Date_,Cur_type ASC");
        }

        $x = 1;
        $MOneyhAF = 0;
        $MOneyhK = 0;
        $MOneyhUSD = 0;
        while ($A = $ShowItem->fetch_assoc()) {
            echo "<tr>";
            $idRec = $A["ID"];
            echo "<td>". $x++ ."</td>";
            echo "<td>". $A["Date_"] ."</td>";
            echo "<td>". $A["Des"] ."</td>";
            $Cur = $A["Cur_type"];
            echo "<td>". $A["Money"], " ", Find_cur($Cur) ."</td>";
            echo "<td>". "<a href='?Item=$Item_NameGet&Delid=$idRec'>X</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='Exp_add.php?IE=$idRec' target='_blank'>تغییرول</a>" ."</td>";

            if ($Cur === "AF") {
                $MOneyhAF += $A["Money"];
            }elseif ($Cur === "K") {
                $MOneyhK += $A["Money"];
            }elseif ($Cur === "USD") {
                $MOneyhUSD += $A["Money"];
            }


            echo "</tr>";
        }
        echo "<tr style='background-image:url(Img/blue2.png);'>";
        echo "<td>". "افغانی:" ."</td>";
        echo "<td>". "$MOneyhAF" ."</td>";
        echo "</tr>";
        echo "<tr style='background-image:url(Img/blue2.png);'>";
        echo "<td>". "کلدار:" ."</td>";
        echo "<td>". "$MOneyhK" ."</td>";
        echo "</tr>";
        echo "<tr style='background-image:url(Img/blue2.png);'>";
        echo "<td>". "دالر:" ."</td>";
        echo "<td>". "$MOneyhUSD" ."</td>";
        echo "</tr>";

        ?>
    </table>


</div>
</body>
</html>