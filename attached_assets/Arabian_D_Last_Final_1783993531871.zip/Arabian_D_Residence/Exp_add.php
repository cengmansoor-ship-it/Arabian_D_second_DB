<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Arabian D Residence | Buy Form</title>
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    direction:rtl;
    }
    .header{
    width: 100%;
    height: 137px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 40%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    flex-direction: row-reverse;
    
    }
    .body_page div{
    height: auto;
    width: 100%;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 70%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:78%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    form .inputbox {
        width: 100%;
        padding: 5px;
        margin: 0px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        box-sizing:border-box;
        position: relative;
    }
    form .inputbox input,select {
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;
        
    }
    form .inputbox i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }
    form .button input {
        width: 170px;
        padding: 18px;
        margin-top: 13px;
        border: none;
        background-color: rgb(51 158 77);
        margin-bottom: 14px;
        border-radius: 20px;   
        font-size:15px;
        font-weight:900;
        }
    form .button input:hover {
        border-radius: 4px;
        box-shadow: rgba(128, 128, 128, 0.63)  1px 10px 10px 2px;
        transition: ease-in-out  0.9s;
        outline: none;
        border: none;
    }
    .inputboxtwo{
        display: flex;
        width: 100%;
        flex-direction: row;
        direction:rtl;
    }
    .inputboxtwo div{
        width: 49%;
        box-sizing: border-box;
        justify-content: space-between;    
    }
    .inputboxtwo div input,select{
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;

    }
    .inputboxtwo div i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }

    </style>
</head>
<body>
<?php
include ("Confirm.php");
include ("Config.php");
$Item_Name = $New_item = $Des =  $Money = $Cur_type = $Href = "" ;
$Date_ = $Cur_Date;

if (isset($_GET["IE"])) {
    $IE = $_GET["IE"];
    $Href = "?IE=$IE";
    $data = $Conn->query("SELECT * FROM `expence` WHERE ID='$IE'")->fetch_assoc();
    $Item_Name = $data["Type"];
    $Des =  $data["Des"];
    $Money = $data["Money"];
    $Cur_type = $data["Cur_type"];

}
if (isset($_POST["Btn_Save"])) {
    $Item_Name = $_POST["Item_Name"];
    $New_item = $_POST["New_item"];
    $Des = $_POST["Des"];
    $Money = $_POST["Money"];
    $Cur_type = $_POST["Cur_type"];
    $Date_ = $_POST["Date_"];

    if ($Item_Name === "New_item") {
        $Conn->query("INSERT INTO `expence`(`Type`, `Des`, `Date_`, `Cur_type`, `Money`) VALUES ('$New_item','$Des','$Date_','$Cur_type','$Money')");
    }else {
        $Conn->query("INSERT INTO `expence`(`Type`, `Des`, `Date_`, `Cur_type`, `Money`) VALUES ('$Item_Name','$Des','$Date_','$Cur_type','$Money')");
    }
    echo "<script>window.location.href='Exp_add.php';</script>"; 


}elseif (isset($_POST["Btn_Edit"])) {
    $IE = $_GET["IE"];

    $Item_Name = $_POST["Item_Name"];
    $New_item = $_POST["New_item"];
    $Des = $_POST["Des"];
    $Money = $_POST["Money"];
    $Cur_type = $_POST["Cur_type"];
    $Date_ = $_POST["Date_"];
    if ($Item_Name === "New_item") {
        $Conn->query("UPDATE `expence` SET `Type`='$New_item',`Des`='$Des',`Date_`='$Date_',`Cur_type`='$Cur_type',`Money`='$Money' WHERE ID='$IE'");
        echo "<script>window.location.href='Exp_Show.php?Item=$New_item';</script>"; 
    }else {
        $Conn->query("UPDATE `expence` SET `Type`='$Item_Name',`Des`='$Des',`Date_`='$Date_',`Cur_type`='$Cur_type',`Money`='$Money' WHERE ID='$IE'");
        echo "<script>window.location.href='Exp_Show.php?Item=$Item_Name';</script>"; 
    
    }


}
    
?>
    <div class="header">
        <div></div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="90px" height="90px" alt="Logo"><p style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo "$Cur_Date"; ?> </p></div>
        <div class="logount">
        <a href="Expence.php" style="position: absolute;right: 0px;top:0px;margin: 15px;width: 50px;font-size:25px;font-weight: 900;color: black;text-decoration: none;font-family: sans-serif;cursor: pointer;">X</a>
        </div>
    </div>
    <form action="<?php echo $Href; ?>" method="post" class="body_page">

            <div class="inputbox">
                <i>نوع مصرف</i>
                <select name='Item_Name' onchange="OPT(this.value);" oninput="OPT(this.value);" required>
                    <?php
                    $Item = $Conn->query("SELECT DISTINCT `Type` FROM `expence`");
                    echo "<option value='$Item_Name'>$Item_Name</option>";

                    while ($A = $Item->fetch_assoc()) {
                        $name = $A["Type"];
                        echo "<option value='$name'>$name</option>";
                    }
                    ?>
                    <option value='New_item'>نوي مصرف</option>
                </select>
            </div>

            <div class="inputbox">
                <i id="New_I" style="Display:none;">نوی مصرف نوم</i>
                <input type="text" name="New_item" id="New_Input" style="Display:none;" value=''>
            </div>

            <div class="inputbox">
                <i>تفصیل:</i>
                <textarea name='Des' style='width:100%;max-width:100%;min-width:100%;height:90px;max-height:90px;min-height:90px;'><?php echo $Des; ?></textarea>
            </div>

            <div class="inputbox">
                <i>پیسی</i>
            <div style='display: flex;justify-content: space-between;width: 100%;direction:rtl'>
                <input type='number' min='0' step='0.1' name='Money' onchange='total(this.value)' oninput='total(this.value)' id='PricePP' value='<?php echo $Money; ?>' style='width:70%;'>
                    <select name='Cur_type' id='' style='width:30%;'>
                        <option value='<?php echo $Cur_type; ?>'><?php echo Find_cur($Cur_type); ?></option>
                        <option value='AF'>افغانی</option>
                        <option value='K'>کالدار</option>
                        <option value='USD'>دالر</option>
                    </select>
            </div>
            </div>
            <div class="inputbox">
                    <i>تاریخ</i>
                    <input type="text" name="Date_"  value='<?php echo $Date_; ?>' required>
            <div>

            <div class="button">
            <?php
            if (isset($_GET["IE"])) {
                echo "<input type='submit' value='تغییر' name='Btn_Edit'>";
            }else {
                echo "<input type='submit' value='ثبتول' name='Btn_Save'>";
            }
            ?>
            </div>
    </form>
    
</body>
</html>