<?php
include ("Confirm.php");
include ("Config.php");
    
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Arabian D Residence | Employee List </title>
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    direction:rtl;
    }
    .header{
    width: 100%;
    height: 170px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    /* box-shadow: 2px 4px 11px -2px; */
    width: 99%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    }
    table{
    width: 100%;
    /* border-collapse: collapse; */

    }
    table td,th{
        border: 1px solid;
    padding: 4px;
    border-radius: 5px;
    text-align: center;
    font-weight:600;
    }
    </style>
</head>
<body>
    <div class="header">
        
        <div>
            <a href="Dashboard.php" style="position: absolute;left: 0px;top:0px;"><img src="Img/Back.png" alt="Back" width='30px'></a>
        </div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="120px" height="120px" alt="Logo"><p style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo "$Cur_Date"; ?> </p></div>
        <div class="logount">
        <?php
            echo "<a href='Add_emp.php' style='position: absolute;right: 0px;top:0px;padding: 15px;background-color: #969696;margin: 15px;width: 110px;font-weight: 900;color: black;text-decoration: none;'>د ګاریګر اضافه کول</a>";
            
            if (isset($_GET["Filter"])) {
                echo "<a href='Labor_Index.php' style='position: absolute;left: 90px;top:0px;padding: 15px;background-color: #969696;margin: 15px; width: 70px;font-weight: 900;color: black;text-decoration: none;'>فعال</a>";
                $Emp = $Conn->query("SELECT * FROM `emp_tbl` WHERE `End_Date` != 'فعال'");        
            }else {
                echo "<a href='?Filter=Inactive' style='position: absolute;left: 90px;top:0px;padding: 15px;background-color: #969696;margin: 15px; width: 70px;font-weight: 900;color: black;text-decoration: none;'>غیر فعال</a>";
                $Emp = $Conn->query("SELECT * FROM `emp_tbl` WHERE `End_Date` = 'فعال'");
            }
            echo "<a href='AttendM.php' style='position: absolute;right: 280px;top:0px;padding: 15px;background-color: #969696;margin: 15px;width: auto;font-weight: 900;color: black;text-decoration: none;'>حاضری</a>";

            if (isset($_GET["Inactive"])) {
                $id = $_GET["Inactive"];
                $chk = $Conn->query("SELECT End_Date FROM `emp_tbl` WHERE ID='$id'")->fetch_assoc();
                $ED = $chk["End_Date"];
                if ($ED === "فعال") {
                    $Conn->query("UPDATE `emp_tbl` SET `End_Date`='$Cur_Date' WHERE ID='$id'");
                }else {
                    $Conn->query("UPDATE `emp_tbl` SET `End_Date`='فعال' WHERE ID='$id'");
                }
                echo "<script>window.location.href='Labor_Index.php';</script>"; 
            }

            echo "<a href='Pay_Emp.php' style='position: absolute;right: 155px;top:0px;padding: 15px;background-color: #969696;margin: 15px; width: 70px;font-weight: 900;color: black;text-decoration: none;'>رسید پیسی</a>";
            // echo "<a href='Trans_Item.php' style='position: absolute;right: 310px;top:0px;padding: 15px;background-color: #969696;margin: 15px; width: 70px;font-weight: 900;color: black;text-decoration: none;'>فروش</a>";
        ?>
        

        </div>
    </div>
    <div class="body_page">
        <table>
            <tr>
                <th>ای دی</th>
                <th>نوم</th>
                <th>پلار نوم</th>
                <th>موبایل شمیره</th>
                <th>وظیفه</th>
                <th>معاش</th>
                <th>تذکره نمیر</th>
                <th>د کار شروع تاریخ</th>
                <th>د کار ختم تاریخ</th>
                <th>...</th>
            </tr>

        <?php

        while ($A = $Emp->fetch_assoc()) {
            echo "<tr>";
            $ID = $A["ID"];
            echo "<td>ADR-", "$ID" ,"</td>";
            echo "<td>", $A["Name"] ,"</td>";
            echo "<td>", $A["F_Name"] ,"</td>";
            echo "<td>", $A["Contact_Num"] ,"</td>";
            echo "<td>", $A["JOB"] ,"</td>";
            echo "<td>", $A["Salary"], " ", Find_cur($A["Cur_type"]) ,"</td>";
            echo "<td>", $A["Nic_Card"] ,"</td>";
            echo "<td>", $A["Join_date"] ,"</td>";
            echo "<td><a href='?Inactive=$ID'>", $A["End_Date"] ,"</a></td>";
            echo "<td><a href='Add_emp.php?IE=$ID' target='_blank'>", "تغییرول</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href='View_Emp.php?ID=$ID' target='_blank'>لیدل</a></td>";
            
            echo "</tr>";
        }

        ?>
    </table>
    </div>
    <div class="fotter">

    </div>
</body>
</html>