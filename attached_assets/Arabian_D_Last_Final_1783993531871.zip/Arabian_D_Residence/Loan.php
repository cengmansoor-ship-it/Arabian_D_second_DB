<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include ("Confirm.php");
include ("Config.php");
    @$Type = $_GET["CusT"];
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Arabian D Residence | Market Loan</title>
    <!-- Hijri Datepicker CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/balbarak/bootstrap-hijri-datepicker@master/dist/css/bootstrap-hijri-datepicker.min.css">
    
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    direction: rtl;
    }
    .header{
    width: 100%;
    height: 257px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 95%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    }
    .body_page table{
    width: 100%;
    /* border-collapse: collapse; */

    }
    .body_page table td,th{
        border: 1px solid;
    padding: 4px;
    border-radius: 5px;
    text-align: center;
    font-weight:600;
    }
    .Slect:hover{
    background-color: #00ffffc4;
    transition: all 0.1s;
        
    }
    a{
        text-decoration: none;
    color: black;
    font-weight: bolder;
    }
    .date-filter-box {
        width: 100%;
        background-color: #f0f0f0;
        padding: 15px;
        margin-bottom: 15px;
        border-radius: 5px;
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        align-items: center;
        justify-content: center;
        direction: rtl;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    .date-filter-box input {
        padding: 8px 10px;
        border: 1px solid #999;
        border-radius: 4px;
        font-size: 14px;
    }
    .date-filter-box button {
        padding: 8px 15px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-weight: bold;
        font-size: 14px;
        transition: background-color 0.3s;
    }
    .date-filter-box button:hover {
        background-color: #45a049;
    }
    .date-filter-box .reset-btn {
        background-color: #f44336;
    }
    .date-filter-box .reset-btn:hover {
        background-color: #da190b;
    }
</style>
</head>
<body>
<?php
@$Type = $_GET["CusT"];

// =====================================================
// HELPER FUNCTIONS FOR SECURITY AND DATE HANDLING
// =====================================================

/**
 * Sanitize user input to prevent XSS
 */
function sanitizeInput($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    return $input;
}

/**
 * Validate date format (YYYY-MM-DD)
 */
function isValidDate($date) {
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d && $d->format('Y-m-d') === $date;
}

/**
 * Get current date in Gregorian format for database
 */
function getCurrentDateGregorian() {
    return date('Y-m-d'); // Current date in YYYY-MM-DD format
}

/**
 * Convert Gregorian date to Islamic (Hijri) calendar using pure PHP
 */
function gregorianToIslamic($date) {
    if (!function_exists('gregoriantojd') || !function_exists('cal_from_jd') || !defined('CAL_ISLAMIC')) {
        return date('Y-m-d');
    }
    $date = DateTime::createFromFormat('Y-m-d', $date);
    if (!$date) return '';
    
    $year = (int)$date->format('Y');
    $month = (int)$date->format('m');
    $day = (int)$date->format('d');
    
    $jd = gregoriantojd($month, $day, $year);
    $islamic = cal_from_jd($jd, CAL_ISLAMIC);

    $hijri_month = (int)$islamic['month'];
    $hijri_day = (int)$islamic['day'];
    $hijri_year = (int)$islamic['year'];
    
    $hijri_months = ['', 'محرم', 'صفر', 'ربیع الاول', 'ربیع الثانی', 'جمادی الاول', 'جمادی الثانی', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذی القعدہ', 'ذی الحجہ'];
    
    return "$hijri_day " . $hijri_months[$hijri_month] . " $hijri_year ہـ";
}

/**
 * Convert Islamic (Hijri) date (iYYYY-iMM-iDD or YYYY-MM-DD) to Gregorian YYYY-MM-DD
 */
function islamicToGregorian($hdate) {
    if (!function_exists('cal_to_jd') || !function_exists('jdtogregorian') || !defined('CAL_ISLAMIC')) {
        return '';
    }
    if (!preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})$/', $hdate, $m)) return '';
    $y = (int)$m[1];
    $mo = (int)$m[2];
    $d = (int)$m[3];

    // Convert Islamic to Julian Day
    $jd = cal_to_jd(CAL_ISLAMIC, $mo, $d, $y);
    if (!$jd) return '';

    // Convert Julian Day to Gregorian string (m/d/Y)
    $greg = jdtogregorian($jd);
    if (!$greg) return '';
    list($gm, $gd, $gy) = explode('/', $greg);
    return sprintf('%04d-%02d-%02d', (int)$gy, (int)$gm, (int)$gd);
}

function isHijriLike($date) {
    if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m)) return false;
    $y = (int)$m[1];
    // Hijri years are roughly in range 1300-1600 for modern dates
    return $y >= 1300 && $y <= 1600;
}

/**
 * Format number with thousands separator
 */
function formatCurrency($value) {
    return number_format($value, 2, '.', ',');
}

// Handle date filtering with proper date conversion
// keep original display values (so the form keeps Hijri text) and convert to Gregorian for SQL
// Defaults: start at 1403-01-01 and end at current Hijri date (from Config.php)
$displayFromDate = isset($_GET["from_date"]) ? sanitizeInput($_GET["from_date"]) : '1403-01-01';
$displayToDate = isset($_GET["to_date"]) ? sanitizeInput($_GET["to_date"]) : $Cur_Date;

// internal Gregorian dates used in SQL
$fromDate = '';
$toDate = '';

// Convert display (possibly Hijri) to Gregorian
if ($displayFromDate) {
    if (isHijriLike($displayFromDate)) {
        $conv = islamicToGregorian($displayFromDate);
        if ($conv && isValidDate($conv)) {
            $fromDate = $conv;
        }
    } elseif (isValidDate($displayFromDate)) {
        $fromDate = $displayFromDate;
    }
}
if ($displayToDate) {
    if (isHijriLike($displayToDate)) {
        $conv = islamicToGregorian($displayToDate);
        if ($conv && isValidDate($conv)) {
            $toDate = $conv;
        }
    } elseif (isValidDate($displayToDate)) {
        $toDate = $displayToDate;
    }
}

// Validate dates if provided (now in Gregorian format)
if ($fromDate && !isValidDate($fromDate)) $fromDate = '';
if ($toDate && !isValidDate($toDate)) $toDate = '';

// If conversion failed, try to use display dates directly if they're already Gregorian
if (!$fromDate && isValidDate($displayFromDate)) $fromDate = $displayFromDate;
if (!$toDate && isValidDate($displayToDate)) $toDate = $displayToDate;

// Fallback: if still empty, use defaults (convert defaults if needed)
if (!$fromDate) {
    $defaultFromConv = islamicToGregorian('1403-01-01');
    $fromDate = ($defaultFromConv && isValidDate($defaultFromConv)) ? $defaultFromConv : '2022-01-01';
}
if (!$toDate) {
    $defaultToConv = isHijriLike($Cur_Date) ? islamicToGregorian($Cur_Date) : $Cur_Date;
    $toDate = ($defaultToConv && isValidDate($defaultToConv)) ? $defaultToConv : date('Y-m-d');
}

// Ensure from_date <= to_date
if ($fromDate && $toDate && $fromDate > $toDate) {
    $temp = $fromDate;
    $fromDate = $toDate;
    $toDate = $temp;
    // also swap display values so UI matches
    $tmpd = $displayFromDate;
    $displayFromDate = $displayToDate;
    $displayToDate = $tmpd;
}

?>
    <div class="header">
        <div>
        <a href="Select_Type.php?Tof=مشتریانو" style="position: absolute;left: 0px;top:0px;"><img src="Img/Back.png" alt="Back" width='30px'></a>
        </div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="210px" height="210px" alt="Logo"><p id="hijriDate" style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo htmlspecialchars($Cur_Date); ?> </p></div>
        <div class="logount">
        </div>
    </div>

    <!-- Date Filter Section -->
    <div class="date-filter-box">
        <form action="" method="GET" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
            <input type="hidden" name="CusT" value="<?php echo htmlspecialchars($Type); ?>">
            
            <label style="font-weight: bold;">پیل تاریخ:</label>
            <input type="text" class="hijri-datepicker" name="from_date" value="<?php echo htmlspecialchars($displayFromDate ?? ''); ?>" autocomplete="off">

            <label style="font-weight: bold;">پای تاریخ:</label>
            <input type="text" class="hijri-datepicker" name="to_date" value="<?php echo htmlspecialchars($displayToDate ?? ''); ?>" autocomplete="off">
            
            <button type="submit">لټون</button>
        </form>
    </div>

    <div class="body_page">
        <table>
            <tr>
                <th width='50px'>شمیره</th>
                <th>نام</th>
                <th width='130px'>فون شمیره</th>
                <th>افغانی</th>
                <th>کلدار</th>
                <th>دالر</th>
                <th width='160px'>کړنه</th>
            </tr>
            <?php
            // Build date filter WHERE clause
            // IMPORTANT: All system dates (loan_tbl.Date) are stored as Hijri strings.
            // So we must filter using the original (display) Hijri inputs,
            // not the Gregorian-converted $fromDate/$toDate.
            $dateFilter = '';
            if ($displayFromDate || $displayToDate) {
                if ($displayFromDate && $displayToDate) {
                    $dateFilter = " AND `Date` BETWEEN '$displayFromDate' AND '$displayToDate'";
                } elseif ($displayFromDate) {
                    $dateFilter = " AND `Date` >= '$displayFromDate'";
                } elseif ($displayToDate) {
                    $dateFilter = " AND `Date` <= '$displayToDate'";
                }
            }
            
            $Cus_data = $Conn->query("SELECT * FROM `custumer_info` WHERE `Cus_type`='$Type'");
            if (!$Cus_data) {
                die('<strong style="color:red;">[Database Error]</strong> Query failed: ' . htmlspecialchars($Conn->error));
            }

            $AFB = 0 ;
            $AFB_ = 0 ;
            $AFB_P = 0 ;

            $KB= 0 ;
            $KB_= 0 ;
            $KB_P = 0 ;

            $USDB= 0 ;
            $USDB_= 0 ;
            $USDB_P = 0 ;


            while ($A = $Cus_data->fetch_assoc()) {
                echo "<tr class='Slect'>";
                $id = $A["ID"];
                echo "<td>". $id ."</td>";
                echo "<td>". $A["Name"] ."</td>";
                echo "<td>". $A["Contact_Num"] ."</td>";

                $AF_BQUery = $Conn->query("SELECT SUM(`Plus`) as PL,SUM(`Mines`) as Mi FROM `loan_tbl` WHERE Cus_ID = '$id' AND `Cur_type`='AF'" . $dateFilter);
                if ($AF_BQUery && $AF_Row = $AF_BQUery->fetch_assoc()) {
                    $AFB = $AF_Row["PL"]-$AF_Row["Mi"] ;
                } else {
                    $AFB = 0;
                }
                if ($AFB < 0) {
                    echo "<td style='background:red;'>". $AFB ."</td>";
                    $AFB_ += $AFB ;

                }else {
                    echo "<td>". $AFB ."</td>";
                    $AFB_P += $AFB ;
                }

                $K_BQUery = $Conn->query("SELECT SUM(`Plus`) as PL,SUM(`Mines`) as Mi FROM `loan_tbl` WHERE Cus_ID = '$id' AND `Cur_type`='K'" . $dateFilter);
                if ($K_BQUery && $K_Row = $K_BQUery->fetch_assoc()) {
                    $KB = $K_Row["PL"]-$K_Row["Mi"] ;
                } else {
                    $KB = 0;
                }
                if ($KB < 0) {
                    echo "<td style='background:red;'>". $KB ."</td>";
                    $KB_ += $KB ;

                }else {
                    echo "<td>". $KB ."</td>";
                    $KB_P += $KB ;
                }

                $USD_BQUery = $Conn->query("SELECT SUM(`Plus`) as PL,SUM(`Mines`) as Mi FROM `loan_tbl` WHERE Cus_ID = '$id' AND `Cur_type`='USD'" . $dateFilter);
                if ($USD_BQUery && $USD_Row = $USD_BQUery->fetch_assoc()) {
                    $USDB = $USD_Row["PL"]-$USD_Row["Mi"] ;
                } else {
                    $USDB = 0;
                }
                if ($USDB < 0) {
                    echo "<td style='background:red;'>". $USDB ."</td>";
                    $USDB_ += $USDB ;

                }else {
                    echo "<td>". $USDB ."</td>";
                    $USDB_P += $USDB ;
                }

                echo "<td>". "<a target='_blank' href='Select_Cur.php?COF=بازار&ID=$id'>کهاته</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='Add_Cus.php?IE=$id'>تغییرول</a>" ."</td>";
                echo "</tr>";


            }
            echo "<tr style='background-image:url(Img/blue2.png);'>";
            echo "<td>" . "ټوټل حساب: " ."</td>";
            echo "<td>". "" ."</td>";
            echo "<td>". "" ."</td>";
            echo "<td>". "
            پور: $AFB_P <br>
            طلب: $AFB_ 
            " ."</td>";
            echo "<td>". "
            پور: $KB_P <br>
            طلب: $KB_ 
            " ."</td>";
            echo "<td>". "
            پور: $USDB_P <br>
            طلب: $USDB_ 
            " ."</td>";
            echo "<td>". "" ."</td>";

    
            echo "</tr>";
    
            ?>
        </table>
    </div>
    <div class="fotter">

    </div>
    <!-- Dependencies -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment-hijri/2.1.2/moment-hijri.min.js"></script>
    
    <!-- Hijri Datepicker JS -->
    <script src="https://cdn.jsdelivr.net/gh/balbarak/bootstrap-hijri-datepicker@master/dist/js/bootstrap-hijri-datepicker.min.js"></script>

    <script>
    $(function () {
        $(".hijri-datepicker").hijriDatePicker({
            hijri: true,
            showSwitcher: false,
            format: "YYYY-MM-DD",
            hijriFormat: "YYYY-MM-DD",
            showTodayButton: true,
            showClear: true
        });
    });

    // Dynamic date: auto-reload page at local midnight so the displayed
    // Hijri/Gregorian date is always current without a manual refresh.
    (function() {
        var now = new Date();
        var midnight = new Date(now);
        midnight.setHours(24, 0, 0, 0);
        var msUntilMidnight = midnight.getTime() - now.getTime();

        function reloadAtMidnight() {
            setTimeout(function() { location.reload(); }, msUntilMidnight);
        }

        reloadAtMidnight();
    })();
    </script>
</body>
</html>