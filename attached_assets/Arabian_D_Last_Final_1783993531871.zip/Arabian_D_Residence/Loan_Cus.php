<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arabian D Residence | Loan & Customer Management</title>
    <!-- Hijri Datepicker CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/balbarak/bootstrap-hijri-datepicker@master/dist/css/bootstrap-hijri-datepicker.min.css">
    
    <style>
        body{
            width: 100%;
            height: 100vh;
            padding: 5px;
            margin: 0px;
            box-sizing: border-box;
            direction: rtl;
        }
        .header{
            width: 100%;
            background-image: url('Img/Green.png');
            height: 100px;
            display: flex;
            justify-content: center;
            font-size: 51px;
            align-items: center;
        }
        .page table{
            width: 100%;
            border-collapse: collapse;
        }
        .page table td, th{
            border: 1px solid #ccc;
            padding: 8px;
            text-align: center;
            box-sizing: border-box;
        }
        .page table th {
            background-color: #f5f5f5;
            font-weight: bold;
        }
        .Slect:hover{
            background-color: #00ffffc4;
            transition: all 0.1s;
        }
        a{
            text-decoration: none;
            color: black;
            font-weight: bolder;
        }
        a.delete-btn {
            color: red;
            font-weight: bold;
            cursor: pointer;
        }
        td input{
            border: 1px solid #ccc;
            padding: 5px;
            border-radius: 3px;
            font-size: 13px;
            width: 90%;
        }
        .message {
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .info {
            padding: 15px;
            background-color: #e7f3ff;
            border-left: 4px solid #2196F3;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        .total-summary {
            background-color: #fff3cd !important;
            font-weight: bold;
            color: #856404;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
<div class="header">
    <?php
    include ("Confirm.php");
    include ("Config.php");
    
    // =====================================================
    // HELPER FUNCTIONS FOR SECURITY AND DATE HANDLING
    // =====================================================
    
    /**
     * Sanitize user input to prevent XSS
     */
    function sanitizeInput($input) {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        return $input;
    }
    
    /**
     * Validate date format (YYYY-MM-DD)
     */
    function isValidDate($date) {
        $d = DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }
    
    /**
     * Get current date in Gregorian format for database
     */
    function getCurrentDateGregorian() {
        return date('Y-m-d'); // Current date in YYYY-MM-DD format
    }
    
    /**
     * Convert Gregorian date to Islamic (Hijri) calendar
     */
    function gregorianToIslamic($date) {
        if (!function_exists('gregoriantojd') || !function_exists('cal_from_jd') || !defined('CAL_ISLAMIC')) {
            return date('Y-m-d');
        }
        $date = DateTime::createFromFormat('Y-m-d', $date);
        if (!$date) return '';
        
        $year = $date->format('Y');
        $month = $date->format('m');
        $day = $date->format('d');
        
    $jd = gregoriantojd($month, $day, $year);
    $islamic = cal_from_jd($jd, CAL_ISLAMIC);

    $hijri_month = (int)$islamic['month'];
    $hijri_day   = (int)$islamic['day'];
    $hijri_year  = (int)$islamic['year'];
        
        $hijri_months = ['', 'محرم', 'صفر', 'ربیع الاول', 'ربیع الثانی', 'جمادی الاول', 'جمادی الثانی', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذی القعدہ', 'ذی الحجہ'];
        
        return "$hijri_day " . $hijri_months[$hijri_month] . " $hijri_year ہـ";
    }
    
    /**
     * Format number with thousands separator
     */
    function formatCurrency($value) {
        return number_format($value, 2, '.', ',');
    }
    
    // Initialize variables
    $message = '';
    $messageType = '';
    $IE = $_GET["ID"] ?? "";
    $Cur_type = $_GET["Cur"] ?? "";
    
    // Handle date filtering with proper date conversion
    $fromDate = isset($_GET["from_date"]) ? sanitizeInput($_GET["from_date"]) : '';
    $toDate = isset($_GET["to_date"]) ? sanitizeInput($_GET["to_date"]) : '';
    ?>

    <div style="flex-direction: column; display: flex; align-items: center;">
        <!-- <img src="iwjmjalglke.jpg" width="210px" height="210px" alt="Logo"> -->
        <!-- <p style="margin: 5px; font-weight: 900; font-family: sans-serif;"> <?php echo htmlspecialchars($Cur_Date); ?> </p> -->
    </div>


    <!-- Date Filter Section -->
    <div style="background-color: #f0f0f0; padding: 15px; margin-bottom: 15px; border-radius: 5px; display: flex; gap: 10px; flex-wrap: wrap; align-items: center; justify-content: center;">
        <form action="" method="GET" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
            <input type="hidden" name="ID" value="<?php echo htmlspecialchars($IE); ?>">
            <input type="hidden" name="Cur" value="<?php echo htmlspecialchars($Cur_type); ?>">
            
            <label style="font-weight: bold;]">پیل تاریخ:</label>
            <input type="text" class="hijri-datepicker" name="from_date" value="<?php echo htmlspecialchars($fromDate); ?>" autocomplete="off" style="padding: 0px; border: 1px solid #ccc; border-radius: 4px;">
            
            <label style="font-weight: bold;">پای تاریخ:</label>
            <input type="text" class="hijri-datepicker" name="to_date" value="<?php echo htmlspecialchars($toDate); ?>" autocomplete="off" style="padding: 0px; border: 1px solid #ccc; border-radius: 4px;">
            
            <button type="submit" style="padding: 8px 15px; background-color: #534caf; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;">لټون</button>
        </form>
    </div>

    <br>

    <?php
    // Validate dates if provided
    if ($fromDate && !isValidDate($fromDate)) $fromDate = '';
    if ($toDate && !isValidDate($toDate)) $toDate = '';
    
    // Ensure from_date <= to_date
    if ($fromDate && $toDate && $fromDate > $toDate) {
        $temp = $fromDate;
        $fromDate = $toDate;
        $toDate = $temp;
    }
    
    // Get customer information
    if (isset($_GET["ID"]) && is_numeric($_GET["ID"])) {
        $IE = intval($_GET["ID"]);
        $stmt = $Conn->prepare("SELECT * FROM `custumer_info` WHERE ID=?");
        if (!$stmt) {
            echo "Database Error: " . $Conn->error;
            exit;
        }
        $stmt->bind_param("i", $IE);
        $stmt->execute();
        $Cus_data = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$Cus_data) {
            echo "تلاشی ناموفق";
            exit;
        }
        
        $Cus_ty = htmlspecialchars($Cus_data["Cus_type"]);
        $Cus_Na = htmlspecialchars($Cus_data["Name"]);
        $Cus_Loc = htmlspecialchars($Cus_data["Provice"]);
        $Cur_type = isset($_GET["Cur"]) ? sanitizeInput($_GET["Cur"]) : "AF";
    }else {
        $IE = 1;
        $Cur_type = "AF";
        $Cus_ty = "Loan";
        $Cus_Na = "Default";
        $Cus_Loc = "Location";
    }
    
    // Get currency display text
    $currencyMap = [
        "AF" => "افغانی",
        "K" => "کلدار",
        "USD" => "دالر"
    ];
    
    $Cur_type_txt = $currencyMap[$Cur_type] ?? "نامعلوم";
    if (!isset($currencyMap[$Cur_type])) {
        $Cur_type = "AF";
        $Cur_type_txt = "افغانی";
    }
    
    // Display customer info
    echo "<h6 style='text-align: center;'>" . $Cus_Na . " - " . $Cus_Loc . " - " . $Cur_type_txt . "</h2>";
    ?>
</div>

<?php if ($message): ?>
<div class="message <?php echo $messageType; ?>">
    <?php echo $message; ?>
</div>
<?php endif; ?>

<div class="page">
<table>
<div class="page">
<table>
<?php
if ($Cus_ty === "Loan") {
    echo "<title>Arabian D Residence | ",$Cus_Na," ",$Cur_type_txt," کهاته</title>";
    echo "
    <tr style='background-image: url(Img/Green1.png);'>
        <th width='100px'>تاریخ</th>
        <th>تفصیل</th>
        <th>تعداد</th>
        <th>قیمت</th>
        <th>پیسی</th>
        <th>رسید</th>
        <th>الباقی</th>
    </tr>";
    echo "";
    $view_Data = $Conn->query("SELECT * FROM `loan_tbl` WHERE `Cus_ID`='$IE' AND `Cur_type`='$Cur_type' ORDER BY Date ");
    $Balance = 0 ;
    $total = 0 ;
    $Pay = 0 ;
    while ($A = $view_Data->fetch_assoc()) {
            $Idrec =  $A["ID"];
            echo "<tr>";
            echo "<td>". $A["Date"] ."</td>";
            echo "<td>". $A["Item"] ."</td>";
            echo "<td>". $A["Qty"] ."</td>";
            echo "<td>". $A["Price"] ."</td>";
            echo "<td>". $A["Plus"] ."</td>";
            $Balance += $A["Plus"] ;
            $total += $A["Plus"] ;

            echo "<td>". $A["Mines"] ."</td>";
            $Balance -= $A["Mines"] ;
            $Pay += $A["Mines"] ;

            echo "<td>". $Balance ." &nbsp;&nbsp;&nbsp;<a href='?Cur=$Cur_type&ID=$IE&Delid=$Idrec'>x</a></td>";
            echo "</tr>";
        }
        if (isset($_GET["Delid"])) {
            $IE = $_GET["ID"];
            $Cur_type = $_GET["Cur"];
            $Delid = $_GET["Delid"];
            $Conn->query("DELETE FROM `loan_tbl` WHERE `ID`='$Delid'");
            echo "<script>window.location.href='?Cur=$Cur_type&ID=$IE';</script>"; 
        }
        if (isset($_POST["Data_intry"])) {
            $IE = $_GET["ID"];
            $Cur_type = $_GET["Cur"];
            $date = $_POST["Date"];
            $Des = $_POST["Des"];
            $Qty = $_POST["Qty"];
            $Price = $_POST["Price"];
            $Plus = $_POST["Plus"];
            $Mines = $_POST["Mines"];
            $Conn->query("INSERT INTO `loan_tbl`(`Cus_ID`, `Date`, `Item`, `Qty`, `Price`, `Cur_type`, `Plus`, `Mines`) VALUES 
            ('$IE','$date','$Des','$Qty','$Price','$Cur_type','$Plus','$Mines')");
        echo "<script>window.location.href='Loan_Cus.php?Cur=$Cur_type&ID=$IE';</script>"; 

        }
        echo "<form action='?Cur=$Cur_type&ID=$IE' method='post'>";
        echo "<tr>";
            echo "<td>". "<input type='text' name='Date' value='$'>" ."</td>";
            echo "<td>". "<input type='text' name='Des' required>" ."</td>";
            echo "<td>". "<input type='number' min='0' name='Qty' id='Qty_I'>" ."</td>";
            echo "<td>". "<input type='number' min='0' name='Price' onchange='total(this.value)' oninput='total(this.value)'>" ."</td>";
            echo "<td>". "<input type='number' min='0' name='Plus' id='TotalP'>" ."</td>";
            echo "<td>". "<input type='number' min='0' name='Mines' >" ."</td>";
            echo "<td>". "" ."</td>";
        echo "<input type='submit' name='Data_intry' style='display:none;'>";
        echo "</tr>";
        echo "</form>";
    



    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td style = 'Color:black;Font-weight:900;'>". "ټوټل حساب:" ."</td>";
    echo "<td>". " " ."</td>";
    echo "<td>". " " ."</td>";
    echo "<td>". " " ."</td>";
    echo "<td style = 'Color:Red;Font-weight:900;'>". $total ."</td>";
    echo "<td style = 'Color:blue;Font-weight:900;'>". $Pay ."</td>";
    echo "<td style = 'Color:Red;Font-weight:900;'>0</td>";

    echo "</tr>";

}elseif ($Cus_ty === "Counter") {
    echo "
    <tr class='toprow'>
    <th width='80px'>تاریخ</th>
    <th>تفصیل</th>
    <th>-</th>
    <th>+</th>
    <th>الباقی</th>
</tr>";
$view_Data = $Conn->query("SELECT * FROM `loan_tbl` WHERE `Cus_ID`='$IE' AND `Cur_type`='$Cur_type' ORDER BY Date ");
$Balance = 0 ;
$total = 0 ;
$Pay = 0 ;
while ($A = $view_Data->fetch_assoc()) {
        $Idrec =  $A["ID"];
        echo "<tr>";
        echo "<td>". $A["Date"] ."</td>";
        echo "<td>". $A["Item"] ."</td>";
        echo "<td  style = 'Color:red;Font-weight:900;'>". $A["Plus"] ."</td>";
        $Balance += $A["Plus"] ;

        echo "<td style = 'Color:blue;Font-weight:900;'>". $A["Mines"] ."</td>";

        $Balance -= $A["Mines"] ;

        echo "<td>". $Balance ." &nbsp;&nbsp;&nbsp;<a href='?Cur=$Cur_type&ID=$IE&Delid=$Idrec'>x</a></td>";
        echo "</tr>";
        $total +=  $A["Plus"];
        $Pay +=  $A["Mines"];

    }
    if (isset($_GET["Delid"])) {
        $IE = $_GET["ID"];
        $Cur_type = $_GET["Cur"];
        $Delid = $_GET["Delid"];
        $Conn->query("DELETE FROM `loan_tbl` WHERE `ID`='$Delid'");
        echo "<script>window.location.href='?Cur=$Cur_type&ID=$IE';</script>"; 
    }
    if (isset($_POST["Data_intry"])) {
        $IE = $_GET["ID"];
        $Cur_type = $_GET["Cur"];
        $date = $_POST["Date"];
        $Des = $_POST["Des"];
        $Qty = $_POST["Qty"];
        $Price = $_POST["Price"];
        $Plus = $_POST["Plus"];
        $Mines = $_POST["Mines"];
        $Conn->query("INSERT INTO `loan_tbl`(`Cus_ID`, `Date`, `Item`, `Qty`, `Price`, `Cur_type`, `Plus`, `Mines`) VALUES 
        ('$IE','$date','$Des','$Qty','$Price','$Cur_type','$Plus','$Mines')");
    echo "<script>window.location.href='Loan_Cus.php?Cur=$Cur_type&ID=$IE';</script>"; 

    }
    echo "<form action='?Cur=$Cur_type&ID=$IE' method='post'>";
    echo "<tr>";
        echo "<td>". "<input type='text' name='Date' value='$'>" ."</td>";
        echo "<td>". "<input type='text' name='Des' required>" ."</td>";
        // echo "<td>". "<input type='number' min='0' name='Qty' id='Qty_I'>" ."</td>";
        // echo "<td>". "<input type='number' min='0' name='Price' onchange='total(this.value)' oninput='total(this.value)'>" ."</td>";
        echo "<td>". "<input type='number' min='0' name='Plus' id='TotalP'>" ."</td>";
        echo "<td>". "<input type='number' min='0' name='Mines' >" ."</td>";
        echo "<td>". "" ."</td>";
    echo "<input type='submit' name='Data_intry' style='display:none;'>";
    echo "</tr>";
    echo "</form>";




echo "<tr style='background-image:url(Img/blue2.png);'>";
echo "<td style = 'Color:black;Font-weight:900;'>". "ټوټل حساب:" ."</td>";
echo "<td>". " " ."</td>";
echo "<td style = 'Color:Red;Font-weight:900;'>". $total ."</td>";
echo "<td style = 'Color:blue;Font-weight:900;'>". $Pay ."</td>";
echo "<td style = 'Color:Red;Font-weight:900;'>0</td>";

echo "</tr>";

}

?>
</table>
</div>
</body>
</html>