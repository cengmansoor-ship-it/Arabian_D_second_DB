<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arabian D Residence | Loan & Customer Management</title>
    
    <style>
        body{
            width: 100%;
            height: 100vh;
            padding: 5px;
            margin: 0px;
            box-sizing: border-box;
            /* display: flex; */
            justify-content: center;
            /* flex-direction:column; */
            direction: rtl;
            
        }
        .header{
            width: 100%;
            background-image: url('Img/Green.png');
            height: 100px;
            display: flex;
            justify-content: center;
            font-size: 51px;
            align-items: center;
        }
        .date-filter-box {
            width: 100%;
            background-color: #f0f0f0;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: center;
            justify-content: center;
            direction: rtl;
        }
        .date-filter-box input {
            padding: 8px 10px;
            border: 1px solid #999;
            border-radius: 4px;
            font-size: 14px;
        }
        .date-filter-box button {
            padding: 8px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            font-size: 14px;
        }
        .date-filter-box button:hover {
            background-color: #45a049;
        }
        .date-filter-box .reset-btn {
            background-color: #f44336;
        }
        .date-filter-box .reset-btn:hover {
            background-color: #da190b;
        }
        .page table{
        width: 100%;
        /* border-collapse: collapse; */

        }
        .page table td,th{
        border: 1px solid;
        padding: 2px;
        border-radius: 5px;
        text-align: center;
        box-sizing: border-box;
        }
        .Slect:hover{
        background-color: #00ffffc4;
        transition: all 0.1s;

        }
        a{
        text-decoration: none;
        color: black;
        font-weight: bolder;
        }
        td input{
            border:none;
            outline:none;
        }
    </style>
</head>
<body>
<div class="header">
    <?php
    include ("Confirm.php");
    include ("Config.php");
    
    // =====================================================
    // HELPER FUNCTIONS FOR SECURITY AND DATE HANDLING
    // =====================================================
    
    /**
     * Sanitize user input to prevent XSS
     */
    function sanitizeInput($input) {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        return $input;
    }
    
    /**
     * Validate date format (YYYY-MM-DD)
     */
    function isValidDate($date) {
        $d = DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }
    
    /**
     * Convert Gregorian date to Jalali format (if needed)
     */
    function gregorianToJalali($gDate) {
        // If it's already in Jalali format, convert back to Gregorian for database
        // This function uses the jdf.php library
        return $gDate; // Store in Gregorian format in database
    }
    
    /**
     * Get current date in Gregorian format for database
     */
    function getCurrentDateGregorian() {
        return date('Y-m-d'); // Current date in YYYY-MM-DD format
    }
    
    ?>
    // Handle date filtering with proper date conversion
    $fromDate = isset($_GET["from_date"]) ? sanitizeInput($_GET["from_date"]) : '';
    $toDate = isset($_GET["to_date"]) ? sanitizeInput($_GET["to_date"]) : '';
    $showAllCustomers = isset($_GET["show_all"]) ? sanitizeInput($_GET["show_all"]) : '';
    
    // Validate dates if provided
    if ($fromDate && !isValidDate($fromDate)) $fromDate = '';
    if ($toDate && !isValidDate($toDate)) $toDate = '';
    
    // Ensure from_date <= to_date
    if ($fromDate && $toDate && $fromDate > $toDate) {
        $temp = $fromDate;
        $fromDate = $toDate;
        $toDate = $temp;
    }
    
    if (isset($_GET["ID"])) {
        $IE = intval($_GET["ID"]);
        $stmt = $Conn->prepare("SELECT * FROM `custumer_info` WHERE ID=?");
        $stmt->bind_param("i", $IE);
        $stmt->execute();
        $Cus_data = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$Cus_data) {
            echo "No customer found.";
            exit;
        }
        
        $Cus_ty = htmlspecialchars($Cus_data["Cus_type"]);
        $Cus_Na = htmlspecialchars($Cus_data["Name"]);
        $Cus_Loc = htmlspecialchars($Cus_data["Provice"]);
        $Cur_type = isset($_GET["Cur"]) ? sanitizeInput($_GET["Cur"]) : "AF";
    }else {
        $IE = "1";
        $Cur_type = "AF";
    }
    
    if ($Cur_type === "AF") {
        $Cur_type_txt = "افغانی";
    }elseif ($Cur_type === "K") {
        $Cur_type_txt = "کلدار";
    }elseif ($Cur_type === "USD") {
        $Cur_type_txt = "دالر";
    }else {
        $Cur_type_txt = "نامعلوم";
        $Cur_type = "AF";
    }
    
    // Display customer info with XSS protection
    echo "<p>" . htmlspecialchars($Cus_Na) . " ولایت " . htmlspecialchars($Cus_Loc) . " " . $Cur_type_txt . " کهاته</p>";
    ?>
    
</div>

<!-- Date Filter Section -->
<div class="date-filter-box">
    <form action="" method="GET" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
        <input type="hidden" name="ID" value="<?php echo htmlspecialchars($IE); ?>">
        <input type="hidden" name="Cur" value="<?php echo htmlspecialchars($Cur_type); ?>">
        
        <label style="font-weight: bold;">تاریخ سے:</label>
        <input type="date" name="from_date" value="<?php echo htmlspecialchars($fromDate); ?>" max="<?php echo date('Y-m-d'); ?>">
        
        <label style="font-weight: bold;">تاریخ تک:</label>
        <input type="date" name="to_date" value="<?php echo htmlspecialchars($toDate); ?>" max="<?php echo date('Y-m-d'); ?>">
        
        <button type="submit">فلٹر کریں (Filter)</button>
        <a href="?ID=<?php echo htmlspecialchars($IE); ?>&Cur=<?php echo htmlspecialchars($Cur_type); ?>" style="padding: 8px 15px; background-color: #f44336; color: white; border-radius: 4px; text-decoration: none;">ری سیٹ (Reset)</a>
    </form>
</div>
<div class="page">
<table>
<?php
if ($Cus_ty === "Loan") {
    echo "<title>Arabian D Residence | ",$Cus_Na," ",$Cur_type_txt," کهاته</title>";
    echo "
    <tr style='background-image: url(Img/Green1.png);'>
        <th width='100px'>تاریخ</th>
        <th>تفصیل</th>
        <th>تعداد</th>
        <th>قیمت</th>
        <th>پیسی</th>
        <th>رسید</th>
        <th>الباقی</th>
    </tr>";
    echo "";
    
    // Build WHERE clause with date filtering
    $where = "`Cus_ID`='$IE' AND `Cur_type`='$Cur_type'";
    if ($fromDate && $toDate) {
        $where .= " AND `Date` BETWEEN '$fromDate' AND '$toDate'";
    }
    
    $view_Data = $Conn->query("SELECT * FROM `loan_tbl` WHERE $where ORDER BY Date ");
    $Balance = 0 ;
    $total = 0 ;
    $Pay = 0 ;
    while ($A = $view_Data->fetch_assoc()) {
            $Idrec =  $A["ID"];
            echo "<tr>";
            echo "<td>". $A["Date"] ."</td>";
            echo "<td>". $A["Item"] ."</td>";
            echo "<td>". $A["Qty"] ."</td>";
            echo "<td>". $A["Price"] ."</td>";
            echo "<td>". $A["Plus"] ."</td>";
            $Balance += $A["Plus"] ;

            echo "<td>". $A["Mines"] ."</td>";
            $Balance -= $A["Mines"] ;

            echo "<td>". $Balance ." &nbsp;&nbsp;&nbsp;<a href='?Cur=$Cur_type&ID=$IE&Delid=$Idrec'>x</a></td>";
            echo "</tr>";
        }
        if (isset($_GET["Delid"])) {
            $IE = $_GET["ID"];
            $Cur_type = $_GET["Cur"];
            $Delid = $_GET["Delid"];
            $Conn->query("DELETE FROM `loan_tbl` WHERE `ID`='$Delid'");
            echo "<script>window.location.href='?Cur=$Cur_type&ID=$IE';</script>"; 
        }
        if (isset($_POST["Data_intry"])) {
            $IE = $_GET["ID"];
            $Cur_type = $_GET["Cur"];
            $date = $_POST["Date"];
            $Des = $_POST["Des"];
            $Qty = $_POST["Qty"];
            $Price = $_POST["Price"];
            $Plus = $_POST["Plus"];
            $Mines = $_POST["Mines"];
            $Conn->query("INSERT INTO `loan_tbl`(`Cus_ID`, `Date`, `Item`, `Qty`, `Price`, `Cur_type`, `Plus`, `Mines`) VALUES 
            ('$IE','$date','$Des','$Qty','$Price','$Cur_type','$Plus','$Mines')");
        echo "<script>window.location.href='Loan_Cus.php?Cur=$Cur_type&ID=$IE';</script>"; 

        }
        
        // Calculate totals
        $totalMines = 0;
        $totalPlus = 0;
        $totalPrice = 0;
        $totalBalance = 0;
        $balance = 0;
        $view_Data = $Conn->query("SELECT * FROM `loan_tbl` WHERE $where ORDER BY Date ");
        while ($row = $view_Data->fetch_assoc()) {
            $balance += $row['Plus'] - $row['Mines'];
            $totalMines += $row['Mines'];
            $totalPlus += $row['Plus'];
            $totalPrice += $row['Price'];
        }
        $totalBalance = $balance;
        
        // Add footer row with totals
        echo "<tr style='background-color: #f2f2f2; font-weight: bold;'>
                <td colspan='3'>Total:</td>
                <td>" . $totalPrice . "</td>
                <td>" . $totalPlus . "</td>
                <td>" . $totalMines . "</td>
                <td>" . $balance . "</td>
              </tr>";
        echo "<form action='?Cur=$Cur_type&ID=$IE' method='post'>";
        echo "<tr>";
            echo "<td>". "<input type='text' name='Date' value='$Cur_Date'>" ."</td>";
            echo "<td>". "<input type='text' name='Des' required>" ."</td>";
            echo "<td>". "<input type='number' min='0' name='Qty' id='Qty_I'>" ."</td>";
            echo "<td>". "<input type='number' min='0' name='Price' onchange='total(this.value)' oninput='total(this.value)'>" ."</td>";
            echo "<td>". "<input type='number' min='0' name='Plus' id='TotalP'>" ."</td>";
            echo "<td>". "<input type='number' min='0' name='Mines' id='Mines_I'>" ."</td>";
            echo "<td>". "" ."</td>";
        echo "<input type='submit' name='Data_intry' style='display:none;'>";
        echo "</tr>";
        echo "</form>";

    



    // Calculate totals for footer
    $totalPlusSum = $Conn->query("SELECT SUM(`Plus`) as total_plus, SUM(`Price`) as total_price, SUM(`Mines`) as total_mines FROM `loan_tbl` WHERE $where")->fetch_assoc();
    
    $totalPrice = $totalPlusSum['total_price'] ?? 0;
    $totalPlus = $totalPlusSum['total_plus'] ?? 0;
    $totalMines = $totalPlusSum['total_mines'] ?? 0;
    $totalBalance = $totalPlus - $totalMines;

    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td style='Color:black;Font-weight:900;'>ټوټل حساب:</td>";
    echo "<td></td>";
    echo "<td></td>";
    echo "<td style='Color:Red;Font-weight:900;'>". number_format($totalPrice) ."</td>";
    echo "<td style='Color:Red;Font-weight:900;'>". number_format($totalPlus) ."</td>";
    echo "<td style='Color:blue;Font-weight:900;'>". number_format($totalMines) ."</td>";
    echo "<td style='Color:Red;Font-weight:900;'>". number_format($totalPlus - $totalMines) ."</td>";
    echo "</tr>";

}elseif ($Cus_ty === "Counter") {
    echo "
    <tr class='toprow'>
    <th width='80px'>تاریخ</th>
    <th>تفصیل</th>
    <th>-</th>
    <th>+</th>
    <th>الباقی</th>
</tr>";

    // Build WHERE clause with date filtering for Counter
    $where_counter = "`Cus_ID`='$IE' AND `Cur_type`='$Cur_type'";
    if ($fromDate && $toDate) {
        $where_counter .= " AND `Date` BETWEEN '$fromDate' AND '$toDate'";
    }
    
$view_Data = $Conn->query("SELECT * FROM `loan_tbl` WHERE $where_counter ORDER BY Date ");
$Balance = 0 ;
$total = 0 ;
$Pay = 0 ;
while ($A = $view_Data->fetch_assoc()) {
        $Idrec =  $A["ID"];
        echo "<tr>";
        echo "<td>". $A["Date"] ."</td>";
        echo "<td>". $A["Item"] ."</td>";
        echo "<td  style = 'Color:red;Font-weight:900;'>". $A["Plus"] ."</td>";
        $Balance += $A["Plus"] ;

        echo "<td style = 'Color:blue;Font-weight:900;'>". $A["Mines"] ."</td>";

        $Balance -= $A["Mines"] ;

        echo "<td>". $Balance ." &nbsp;&nbsp;&nbsp;<a href='?Cur=$Cur_type&ID=$IE&Delid=$Idrec'>x</a></td>";
        echo "</tr>";
        $total +=  $A["Plus"];
        $Pay +=  $A["Mines"];

    }
    if (isset($_GET["Delid"])) {
        $IE = $_GET["ID"];
        $Cur_type = $_GET["Cur"];
        $Delid = $_GET["Delid"];
        $Conn->query("DELETE FROM `loan_tbl` WHERE `ID`='$Delid'");
        echo "<script>window.location.href='?Cur=$Cur_type&ID=$IE';</script>"; 
    }
    if (isset($_POST["Data_intry"])) {
        $IE = $_GET["ID"];
        $Cur_type = $_GET["Cur"];
        $date = $_POST["Date"];
        $Des = $_POST["Des"];
        $Qty = $_POST["Qty"];
        $Price = $_POST["Price"];
        $Plus = $_POST["Plus"];
        $Mines = $_POST["Mines"];
        $Conn->query("INSERT INTO `loan_tbl`(`Cus_ID`, `Date`, `Item`, `Qty`, `Price`, `Cur_type`, `Plus`, `Mines`) VALUES 
        ('$IE','$date','$Des','$Qty','$Price','$Cur_type','$Plus','$Mines')");
    echo "<script>window.location.href='Loan_Cus.php?Cur=$Cur_type&ID=$IE';</script>"; 

    }
    echo "<form action='?Cur=$Cur_type&ID=$IE' method='post'>";
    echo "<tr>";
        echo "<td>". "<input type='text' name='Date' value='$Cur_Date'>" ."</td>";
        echo "<td>". "<input type='text' name='Des' required>" ."</td>";
        // echo "<td>". "<input type='number' min='0' name='Qty' id='Qty_I'>" ."</td>";
        // echo "<td>". "<input type='number' min='0' name='Price' onchange='total(this.value)' oninput='total(this.value)'>" ."</td>";
        echo "<td>". "<input type='number' min='0' name='Plus' id='TotalP'>" ."</td>";
        echo "<td>". "<input type='number' min='0' name='Mines' >" ."</td>";
        echo "<td>". "" ."</td>";
    echo "<input type='submit' name='Data_intry' style='display:none;'>";
    echo "</tr>";
    echo "</form>";




echo "<tr style='background-image:url(Img/blue2.png);'>";
echo "<td style = 'Color:black;Font-weight:900;'>". "ټوټل حساب:" ."</td>";
echo "<td>". " " ."</td>";
echo "<td style = 'Color:Red;Font-weight:900;'>". $total ."</td>";
echo "<td style = 'Color:blue;Font-weight:900;'>". $Pay ."</td>";
if ($Balance < 0) {
    echo "<td style = 'Color:blue;Font-weight:900;'>". $Balance ."</td>";
}else {
    echo "<td style = 'Color:Red;Font-weight:900;'>". $Balance ."</td>";
}

echo "</tr>";

}

?>
</table>
</div>
</body>
</html>