<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arabian D Residence | Loan & Customer Management</title>
    
    <style>
        body{
            width: 100%;
            height: 100vh;
            padding: 5px;
            margin: 0px;
            box-sizing: border-box;
            direction: rtl;
        }
        .header{
            width: 100%;
            background-image: url('Img/Green.png');
            height: 100px;
            display: flex;
            justify-content: center;
            font-size: 51px;
            align-items: center;
        }
        .date-filter-box {
            width: 100%;
            background-color: #f0f0f0;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: center;
            justify-content: center;
            direction: rtl;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .date-filter-box input {
            padding: 8px 10px;
            border: 1px solid #999;
            border-radius: 4px;
            font-size: 14px;
        }
        .date-filter-box button {
            padding: 8px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            font-size: 14px;
            transition: background-color 0.3s;
        }
        .date-filter-box button:hover {
            background-color: #45a049;
        }
        .date-filter-box .reset-btn {
            background-color: #f44336;
        }
        .date-filter-box .reset-btn:hover {
            background-color: #da190b;
        }
        .page table{
            width: 100%;
            border-collapse: collapse;
        }
        .page table td, th{
            border: 1px solid #ccc;
            padding: 8px;
            text-align: center;
            box-sizing: border-box;
        }
        .page table th {
            background-color: #f5f5f5;
            font-weight: bold;
        }
        .Slect:hover{
            background-color: #00ffffc4;
            transition: all 0.1s;
        }
        a{
            text-decoration: none;
            color: black;
            font-weight: bolder;
        }
        a.delete-btn {
            color: red;
            font-weight: bold;
            cursor: pointer;
        }
        td input{
            border: 1px solid #ccc;
            padding: 5px;
            border-radius: 3px;
            font-size: 13px;
            width: 90%;
        }
        .message {
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .info {
            padding: 15px;
            background-color: #e7f3ff;
            border-left: 4px solid #2196F3;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        .total-summary {
            background-color: #fff3cd !important;
            font-weight: bold;
            color: #856404;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
<div class="header">
    <?php
    include ("Confirm.php");
    include ("Config.php");
    
    // =====================================================
    // HELPER FUNCTIONS FOR SECURITY AND DATE HANDLING
    // =====================================================
    
    /**
     * Sanitize user input to prevent XSS
     */
    function sanitizeInput($input) {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        return $input;
    }
    
    /**
     * Validate date format (YYYY-MM-DD)
     */
    function isValidDate($date) {
        $d = DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }
    
    /**
     * Get current date in Gregorian format for database
     */
    function getCurrentDateGregorian() {
        return date('Y-m-d'); // Current date in YYYY-MM-DD format
    }
    
    /**
     * Format number with thousands separator
     */
    function formatCurrency($value) {
        return number_format($value, 2, '.', ',');
    }
    
    // Initialize message
    $message = '';
    $messageType = '';
    
    // Handle date filtering with proper date conversion
    $fromDate = isset($_GET["from_date"]) ? sanitizeInput($_GET["from_date"]) : '';
    $toDate = isset($_GET["to_date"]) ? sanitizeInput($_GET["to_date"]) : '';
    
    // Validate dates if provided
    if ($fromDate && !isValidDate($fromDate)) $fromDate = '';
    if ($toDate && !isValidDate($toDate)) $toDate = '';
    
    // Ensure from_date <= to_date
    if ($fromDate && $toDate && $fromDate > $toDate) {
        $temp = $fromDate;
        $fromDate = $toDate;
        $toDate = $temp;
    }
    
    // Get customer information
    if (isset($_GET["ID"]) && is_numeric($_GET["ID"])) {
        $IE = intval($_GET["ID"]);
        $stmt = $Conn->prepare("SELECT * FROM `custumer_info` WHERE ID=?");
        if (!$stmt) {
            echo "Database Error: " . $Conn->error;
            exit;
        }
        $stmt->bind_param("i", $IE);
        $stmt->execute();
        $Cus_data = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$Cus_data) {
            echo "Customer not found.";
            exit;
        }
        
        $Cus_ty = htmlspecialchars($Cus_data["Cus_type"]);
        $Cus_Na = htmlspecialchars($Cus_data["Name"]);
        $Cus_Loc = htmlspecialchars($Cus_data["Provice"]);
        $Cur_type = isset($_GET["Cur"]) ? sanitizeInput($_GET["Cur"]) : "AF";
    }else {
        $IE = 1;
        $Cur_type = "AF";
        $Cus_ty = "Loan";
        $Cus_Na = "Default";
        $Cus_Loc = "Location";
    }
    
    // Get currency display text
    $currencyMap = [
        "AF" => "افغانی",
        "K" => "کلدار",
        "USD" => "دالر"
    ];
    
    $Cur_type_txt = $currencyMap[$Cur_type] ?? "نامعلوم";
    if (!isset($currencyMap[$Cur_type])) {
        $Cur_type = "AF";
        $Cur_type_txt = "افغانی";
    }
    
    // Display customer info
    echo "<h2 style='text-align: center;'>" . $Cus_Na . " - " . $Cus_Loc . " - " . $Cur_type_txt . "</h2>";
    ?>
</div>

<!-- Date Filter Section -->
<div class="date-filter-box">
    <form action="" method="GET" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
        <input type="hidden" name="ID" value="<?php echo htmlspecialchars($IE); ?>">
        <input type="hidden" name="Cur" value="<?php echo htmlspecialchars($Cur_type); ?>">
        
        <label style="font-weight: bold;">تاریخ سے:</label>
        <input type="date" name="from_date" value="<?php echo htmlspecialchars($fromDate); ?>" max="<?php echo date('Y-m-d'); ?>">
        
        <label style="font-weight: bold;">تاریخ تک:</label>
        <input type="date" name="to_date" value="<?php echo htmlspecialchars($toDate); ?>" max="<?php echo date('Y-m-d'); ?>">
        
        <button type="submit">فلٹر کریں (Filter)</button>
        <a href="?ID=<?php echo htmlspecialchars($IE); ?>&Cur=<?php echo htmlspecialchars($Cur_type); ?>" class="reset-btn" style="padding: 8px 15px; background-color: #f44336; color: white; border-radius: 4px; text-decoration: none;">ری سیٹ (Reset)</a>
    </form>
</div>

<?php if ($message): ?>
<div class="message <?php echo $messageType; ?>">
    <?php echo $message; ?>
</div>
<?php endif; ?>

<div class="page">
<table>
<?php

// =====================================================
// LOAN TYPE HANDLING
// =====================================================
if ($Cus_ty === "Loan") {
    echo "<title>Arabian D Residence | " . htmlspecialchars($Cus_Na) . " " . $Cur_type_txt . " کهاته</title>";
    
    echo "<tr style='background-image: url(Img/Green1.png);'>
        <th width='80px'>تاریخ</th>
        <th width='150px'>تفصیل</th>
        <th width='70px'>تعداد</th>
        <th width='80px'>قیمت</th>
        <th width='80px'>پیسی</th>
        <th width='80px'>رسید</th>
        <th width='80px'>الباقی</th>
        <th width='40px'>عمل</th>
    </tr>";
    
    // Build WHERE clause with parameterized query
    $where_conditions = ["`Cus_ID`=?", "`Cur_type`=?"];
    $param_types = 'is';
    $param_values = [$IE, $Cur_type];
    
    if ($fromDate && $toDate) {
        $where_conditions[] = "`Date` BETWEEN ? AND ?";
        $param_types .= 'ss';
        $param_values[] = $fromDate;
        $param_values[] = $toDate;
    }
    
    $where_clause = implode(" AND ", $where_conditions);
    $query = "SELECT * FROM `loan_tbl` WHERE $where_clause ORDER BY `Date` ASC";
    
    $stmt = $Conn->prepare($query);
    if (!$stmt) {
        echo "Query Error: " . $Conn->error;
        exit;
    }
    
    $stmt->bind_param($param_types, ...$param_values);
    $stmt->execute();
    $view_Data = $stmt->get_result();
    
    $Balance = 0;
    $recordCount = 0;
    
    while ($A = $view_Data->fetch_assoc()) {
        $Idrec = intval($A["ID"]);
        $recordCount++;
        
        echo "<tr>";
        echo "<td>" . htmlspecialchars($A["Date"]) . "</td>";
        echo "<td>" . htmlspecialchars($A["Item"]) . "</td>";
        echo "<td>" . intval($A["Qty"]) . "</td>";
        echo "<td>" . formatCurrency($A["Price"]) . "</td>";
        echo "<td style='color: green;'>" . formatCurrency($A["Plus"]) . "</td>";
        $Balance += floatval($A["Plus"]);
        
        echo "<td style='color: red;'>" . formatCurrency($A["Mines"]) . "</td>";
        $Balance -= floatval($A["Mines"]);
        
        $balanceColor = $Balance < 0 ? 'red' : 'blue';
        echo "<td style='color: $balanceColor;'>" . formatCurrency($Balance) . "</td>";
        echo "<td><a href='?Cur=" . htmlspecialchars($Cur_type) . "&ID=" . htmlspecialchars($IE) . "&Delid=" . $Idrec . "' class='delete-btn' onclick=\"return confirm('آیا آپ اس ریکارڈ کو حذف کرنا چاہتے ہیں؟');\">x</a></td>";
        echo "</tr>";
    }
    
    $stmt->close();
    
    // Handle deletion with security
    if (isset($_GET["Delid"])) {
        $Delid = intval($_GET["Delid"]);
        $stmt = $Conn->prepare("DELETE FROM `loan_tbl` WHERE `ID`=? AND `Cus_ID`=? AND `Cur_type`=?");
        if ($stmt) {
            $stmt->bind_param("iis", $Delid, $IE, $Cur_type);
            if ($stmt->execute()) {
                $stmt->close();
                header("Location: ?Cur=" . urlencode($Cur_type) . "&ID=" . urlencode($IE), true, 303);
                exit;
            }
            $stmt->close();
        }
    }
    
    // Calculate totals
    $total_query = "SELECT 
                    SUM(`Plus`) as total_plus, 
                    SUM(`Price`) as total_price, 
                    SUM(`Mines`) as total_mines
                    FROM `loan_tbl` WHERE $where_clause";
    
    $stmt = $Conn->prepare($total_query);
    if ($stmt) {
        $stmt->bind_param($param_types, ...$param_values);
        $stmt->execute();
        $totalRow = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        $totalPrice = floatval($totalRow['total_price'] ?? 0);
        $totalPlus = floatval($totalRow['total_plus'] ?? 0);
        $totalMines = floatval($totalRow['total_mines'] ?? 0);
        $totalBalance = $totalPlus - $totalMines;
    }
    
    // Display totals row
    $totalBalanceColor = $totalBalance < 0 ? 'red' : 'blue';
    echo "<tr class='total-summary'>
            <td colspan='2'>کل ریکارڈز: " . $recordCount . "</td>
            <td></td>
            <td>" . formatCurrency($totalPrice) . "</td>
            <td style='color: green;'>" . formatCurrency($totalPlus) . "</td>
            <td style='color: red;'>" . formatCurrency($totalMines) . "</td>
            <td style='color: $totalBalanceColor;'>" . formatCurrency($totalBalance) . "</td>
            <td></td>
          </tr>";
    
    // Handle form submission with security
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["Data_intry"])) {
        $date = isset($_POST["Date"]) ? sanitizeInput($_POST["Date"]) : '';
        $Des = isset($_POST["Des"]) ? sanitizeInput($_POST["Des"]) : '';
        $Qty = isset($_POST["Qty"]) ? intval($_POST["Qty"]) : 0;
        $Price = isset($_POST["Price"]) ? floatval($_POST["Price"]) : 0;
        $Plus = isset($_POST["Plus"]) ? floatval($_POST["Plus"]) : 0;
        $Mines = isset($_POST["Mines"]) ? floatval($_POST["Mines"]) : 0;
        
        // Validate date
        if (!isValidDate($date)) {
            $date = getCurrentDateGregorian();
        }
        
        // Validate required fields
        if (!$Des) {
            $message = "براہ کرم تفصیل درج کریں";
            $messageType = "error";
        } elseif (!$date) {
            $message = "براہ کرم تاریخ منتخب کریں";
            $messageType = "error";
        } else {
            $stmt = $Conn->prepare("INSERT INTO `loan_tbl`(`Cus_ID`, `Date`, `Item`, `Qty`, `Price`, `Cur_type`, `Plus`, `Mines`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("issidsis", $IE, $date, $Des, $Qty, $Price, $Cur_type, $Plus, $Mines);
                
                if ($stmt->execute()) {
                    $stmt->close();
                    header("Location: ?Cur=" . urlencode($Cur_type) . "&ID=" . urlencode($IE), true, 303);
                    exit;
                } else {
                    $message = "Database Error: " . $stmt->error;
                    $messageType = "error";
                }
                $stmt->close();
            }
        }
    }
    
    // Display input form for new entry
    echo "<form action='' method='post' onsubmit='return validateLoanForm();'>";
    echo "<tr>";
    echo "<td><input type='date' name='Date' value='" . getCurrentDateGregorian() . "' max='" . getCurrentDateGregorian() . "' required></td>";
    echo "<td><input type='text' name='Des' placeholder='تفصیل' required></td>";
    echo "<td><input type='number' min='0' name='Qty' id='Qty_I' placeholder='تعداد'></td>";
    echo "<td><input type='number' min='0' step='0.01' name='Price' id='Price_I' placeholder='قیمت' onchange='calculateTotal()' oninput='calculateTotal()'></td>";
    echo "<td><input type='number' min='0' step='0.01' name='Plus' id='Plus_I' placeholder='پیسی'></td>";
    echo "<td><input type='number' min='0' step='0.01' name='Mines' id='Mines_I' placeholder='رسید'></td>";
    echo "<td colspan='2'><input type='submit' name='Data_intry' value='محفوظ کریں (Save)'></td>";
    echo "</tr>";
    echo "</form>";

}
// =====================================================
// COUNTER TYPE HANDLING
// =====================================================
elseif ($Cus_ty === "Counter") {
    echo "<title>Arabian D Residence | " . htmlspecialchars($Cus_Na) . " " . $Cur_type_txt . " شمار</title>";
    
    echo "<tr style='background-image: url(Img/Green1.png);'>
        <th width='80px'>تاریخ</th>
        <th width='150px'>تفصیل</th>
        <th width='80px'>خروج (-)</th>
        <th width='80px'>داخل (+)</th>
        <th width='80px'>الباقی</th>
        <th width='40px'>عمل</th>
    </tr>";
    
    // Build WHERE clause for Counter
    $where_conditions = ["`Cus_ID`=?", "`Cur_type`=?"];
    $param_types = 'is';
    $param_values = [$IE, $Cur_type];
    
    if ($fromDate && $toDate) {
        $where_conditions[] = "`Date` BETWEEN ? AND ?";
        $param_types .= 'ss';
        $param_values[] = $fromDate;
        $param_values[] = $toDate;
    }
    
    $where_clause = implode(" AND ", $where_conditions);
    $query = "SELECT * FROM `loan_tbl` WHERE $where_clause ORDER BY `Date` ASC";
    
    $stmt = $Conn->prepare($query);
    if (!$stmt) {
        echo "Query Error: " . $Conn->error;
        exit;
    }
    
    $stmt->bind_param($param_types, ...$param_values);
    $stmt->execute();
    $view_Data = $stmt->get_result();
    
    $Balance = 0;
    $totalPlus = 0;
    $totalMines = 0;
    $recordCount = 0;
    
    while ($A = $view_Data->fetch_assoc()) {
        $recordCount++;
        $Idrec = intval($A["ID"]);
        
        echo "<tr>";
        echo "<td>" . htmlspecialchars($A["Date"]) . "</td>";
        echo "<td>" . htmlspecialchars($A["Item"]) . "</td>";
        echo "<td style='color: red; font-weight: bold;'>" . formatCurrency($A["Plus"]) . "</td>";
        $Balance += floatval($A["Plus"]);
        
        echo "<td style='color: blue; font-weight: bold;'>" . formatCurrency($A["Mines"]) . "</td>";
        $Balance -= floatval($A["Mines"]);
        
        $balanceColor = $Balance < 0 ? 'red' : 'blue';
        echo "<td style='color: $balanceColor;'>" . formatCurrency($Balance) . "</td>";
        echo "<td><a href='?Cur=" . htmlspecialchars($Cur_type) . "&ID=" . htmlspecialchars($IE) . "&Delid=" . $Idrec . "' class='delete-btn' onclick=\"return confirm('آیا آپ اس ریکارڈ کو حذف کرنا چاہتے ہیں؟');\">x</a></td>";
        echo "</tr>";
        
        $totalPlus += floatval($A["Plus"]);
        $totalMines += floatval($A["Mines"]);
    }
    
    $stmt->close();
    
    // Handle deletion for Counter
    if (isset($_GET["Delid"])) {
        $Delid = intval($_GET["Delid"]);
        $stmt = $Conn->prepare("DELETE FROM `loan_tbl` WHERE `ID`=? AND `Cus_ID`=? AND `Cur_type`=?");
        if ($stmt) {
            $stmt->bind_param("iis", $Delid, $IE, $Cur_type);
            if ($stmt->execute()) {
                $stmt->close();
                header("Location: ?Cur=" . urlencode($Cur_type) . "&ID=" . urlencode($IE), true, 303);
                exit;
            }
            $stmt->close();
        }
    }
    
    // Calculate totals for Counter
    $total_query = "SELECT 
                    SUM(`Plus`) as total_plus, 
                    SUM(`Mines`) as total_mines,
                    COUNT(*) as record_count
                    FROM `loan_tbl` WHERE $where_clause";
    
    $stmt = $Conn->prepare($total_query);
    if ($stmt) {
        $stmt->bind_param($param_types, ...$param_values);
        $stmt->execute();
        $totalRow = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        $totalPlus = floatval($totalRow['total_plus'] ?? 0);
        $totalMines = floatval($totalRow['total_mines'] ?? 0);
        $recordCount = intval($totalRow['record_count'] ?? 0);
    }
    
    $counterBalance = $totalPlus - $totalMines;
    $balanceColor = $counterBalance < 0 ? 'red' : 'blue';
    
    // Display totals row
    echo "<tr class='total-summary'>
            <td colspan='2'>کل ریکارڈز: " . $recordCount . "</td>
            <td style='color: red;'>" . formatCurrency($totalPlus) . "</td>
            <td style='color: blue;'>" . formatCurrency($totalMines) . "</td>
            <td style='color: $balanceColor;'>" . formatCurrency($counterBalance) . "</td>
            <td></td>
        </tr>";
    
    // Handle form submission for Counter
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["Data_intry"])) {
        $date = isset($_POST["Date"]) ? sanitizeInput($_POST["Date"]) : '';
        $Des = isset($_POST["Des"]) ? sanitizeInput($_POST["Des"]) : '';
        $Plus = isset($_POST["Plus"]) ? floatval($_POST["Plus"]) : 0;
        $Mines = isset($_POST["Mines"]) ? floatval($_POST["Mines"]) : 0;
        
        // Validate date
        if (!isValidDate($date)) {
            $date = getCurrentDateGregorian();
        }
        
        // Validate required fields
        if (!$Des) {
            $message = "براہ کرم تفصیل درج کریں";
            $messageType = "error";
        } elseif (!$date) {
            $message = "براہ کرم تاریخ منتخب کریں";
            $messageType = "error";
        } else {
            $stmt = $Conn->prepare("INSERT INTO `loan_tbl`(`Cus_ID`, `Date`, `Item`, `Qty`, `Price`, `Cur_type`, `Plus`, `Mines`) VALUES (?, ?, ?, 0, 0, ?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("isssii", $IE, $date, $Des, $Cur_type, $Plus, $Mines);
                
                if ($stmt->execute()) {
                    $stmt->close();
                    header("Location: ?Cur=" . urlencode($Cur_type) . "&ID=" . urlencode($IE), true, 303);
                    exit;
                } else {
                    $message = "Database Error: " . $stmt->error;
                    $messageType = "error";
                }
                $stmt->close();
            }
        }
    }
    
    // Display input form for new Counter entry
    echo "<form action='' method='post' onsubmit='return validateCounterForm();'>";
    echo "<tr>";
    echo "<td><input type='date' name='Date' value='" . getCurrentDateGregorian() . "' max='" . getCurrentDateGregorian() . "' required></td>";
    echo "<td><input type='text' name='Des' placeholder='تفصیل' required></td>";
    echo "<td><input type='number' min='0' step='0.01' name='Plus' id='Plus_I' placeholder='خروج'></td>";
    echo "<td><input type='number' min='0' step='0.01' name='Mines' id='Mines_I' placeholder='داخل'></td>";
    echo "<td colspan='2'><input type='submit' name='Data_intry' value='محفوظ کریں (Save)'></td>";
    echo "</tr>";
    echo "</form>";
}

?>
</table>
</div>

<script>
// Form validation functions
function validateLoanForm() {
    var date = document.querySelector('input[name="Date"]').value;
    var desc = document.querySelector('input[name="Des"]').value;
    
    if (!date) {
        alert('براہ کرم تاریخ منتخب کریں');
        return false;
    }
    if (!desc.trim()) {
        alert('براہ کرم تفصیل درج کریں');
        return false;
    }
    return true;
}

function validateCounterForm() {
    var date = document.querySelector('input[name="Date"]').value;
    var desc = document.querySelector('input[name="Des"]').value;
    
    if (!date) {
        alert('براہ کرم تاریخ منتخب کریں');
        return false;
    }
    if (!desc.trim()) {
        alert('براہ کرم تفصیل درج کریں');
        return false;
    }
    return true;
}

function calculateTotal() {
    var qty = document.getElementById("Qty_I").value || 0;
    var price = document.getElementById("Price_I").value || 0;
    document.getElementById("Plus_I").value = (qty * price).toFixed(2);
}

function OPT(X) {
    if (X === "New_item") {
        document.getElementById("New_I").style.display="Block";
        document.getElementById("New_Input").style.display="Block";
    }else{
        document.getElementById("New_I").style.display="none";
        document.getElementById("New_Input").style.display="none";
    }
}
</script>
</body>
</html>
