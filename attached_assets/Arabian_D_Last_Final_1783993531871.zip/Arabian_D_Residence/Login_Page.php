<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Arabian D Residence | Login Form</title>
<style>
body {
    background: url('Bkimg.PNG');
    height: 100vh;
    margin:0px;
    box-sizing: border-box;
    padding:50px;    
    font-family: sans-serif;
    width: 100%;
    background-position: center center;
    background-size: cover;
    display: flex;
    background-repeat: no-repeat;
    justify-content: center;
    flex-direction: column;
    direction:rtl;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    }
    form{

        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(4px);
        padding: 30px;
        border-radius: 10px;
        width: 300px;
        color: white;
        text-align: center;
    }
    form h2{
        margin-bottom: 0px;
    }
    img{
        height: 200px;
    }
    .inputbox input[type="text"],
    .inputbox input[type="password"]{
        width: 100%;
        padding: 10px;
        margin: 8px 0px;
        background: transparent;
    direction:ltr;
        border: none;
        border-bottom: 1px solid white;
        color: white;
        outline: none;
    }
    .inputbox input::placeholder{
        color: white;
        font-size: 12px;
    }
    .button input {
        width: 100%;
        padding: 10px;
        margin-top: 10px;
        background-color: white;
        color: black;
        border: none;
        outline: none;
        border-radius: 5ox;
        cursor: pointer;
        font-weight: 900;
    }
    .Forgot{
        margin: 10px;
        font-size: 0.9em;
        text-align: right;
        width: 100%;
    }
    form .button input:hover {
        border-radius: 4px;
        box-shadow: rgba(128, 128, 128, 0.63)  1px 10px 10px 2px;
        transition: all 0.9s;
        outline: none;
        border: none;
    }
    .err {
        position: absolute;
    background: rgb(247 0 0 / 34%);
    border: rgb(247 0 0 / 34%);
    backdrop-filter: blur(2px);
    color: white;
    font-weight: 700;
    padding: 14px;
    width: 334px;
    font-size: 20px;
    text-align: center;
    margin-top: -52px;    }
    
</style>
<?php
include ("Config.php");
if (isset($_POST["Btn_login"])) {
    $Uname = Save_Input($_POST["UName"]);
    $Upass = Save_Input($_POST["Pass"]);
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $Sign_Info = $Conn->query("SELECT * FROM `user_info` WHERE `User_Name`='$Uname' AND `Password`='$Upass'")->fetch_assoc();
            if ($Sign_Info !== null){
                $_SESSION["Sign_in_User"] = $Sign_Info["User_Name"];
                echo "<script>window.location.href='Dashboard.php';</script>";
            }else {
                echo "<script>window.location.href='Login_Page.php?log=HSWH';</script>";

            }

        }
    }

?>
</head>
<body>
    <div class="login" style='display:flex; flex-direction:column;'>
    <?php
    if (@$_GET["log"] === "HSWH") {
        echo "<div class='err'>Incorrect! Password And User Name.</div>";
    }elseif (@$_GET["change"] === "PCSUCESS") {
        echo "<div class='err' style='background-color: chartreuse;'>Password Change Sucessfully.</div>";
    }elseif (@$_GET["Aut"] === "No") {
        echo "<div class='err'>Alart! First login</div>";
    }
    ?>    
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
        <img src="bbb.png" alt="Logo">
        <h2>ARABIAN D RESIDENCE</h2>
            <div class="inputbox">
                
                <input type="text" name="UName" placeholder="Enter User Name">
            </div>
            <div class="inputbox">
                <input type="Password" name="Pass" placeholder="Enter Password">
                <a href="Change_pass.php" class="Forgot"> For Change Password. <u>Click Here</u></a>
            </div>
            <div class="button">
                <input type="submit" value="Login" name="Btn_login">
            </div>
        </form>
    </div>
</body>
</html>
