<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Arabian D Residence | Pay Form</title>
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    }
    .header{
    width: 100%;
    height: 137px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 40%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    flex-direction: row-reverse;
    
    }
    .body_page div{
    height: auto;
    width: 100%;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 70%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:78%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    form .inputbox {
        width: 100%;
        padding: 5px;
        margin: 0px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        box-sizing:border-box;
        position: relative;
        direction:rtl;
    }
    form .inputbox input,select {
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;
        
    }
    form .inputbox i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }
    form .button input {
        width: 170px;
        padding: 18px;
        margin-top: 13px;
        border: none;
        background-color: rgb(51 158 77);
        margin-bottom: 14px;
        border-radius: 20px;   
        font-size:15px;
        font-weight:900;
        }
    form .button input:hover {
        border-radius: 4px;
        box-shadow: rgba(128, 128, 128, 0.63)  1px 10px 10px 2px;
        transition: ease-in-out  0.9s;
        outline: none;
        border: none;
    }
    .inputboxtwo{
        display: flex;
        width: 100%;
        flex-direction: row;
        direction:rtl;
    }
    .inputboxtwo div{
        width: 49%;
        box-sizing: border-box;
        justify-content: space-between;    
    }
    .inputboxtwo div input,select{
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;

    }
    .inputboxtwo div i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }

    </style>
</head>
<body>
<?php
include ("Confirm.php");
include ("Config.php");
$Emp_Name = $Slect = $Des = $Date = $Money = $Emp_Name_txt ="" ;
$Href = "";
$Date = $Cur_Date;
if (isset($_GET["IDE"])) {
    $IE = $_GET["IDE"];
    $Href = "?IDE=$IE";
    $Account_Emp = $Conn->query("SELECT * FROM `emp_accountv2` WHERE ID = '$IE'")->fetch_assoc();
    @$Emp_Name = $Account_Emp["Emp_ID"];
    @$EMP_NAME = $Conn->query("SELECT * FROM emp_tbl WHERE ID ='$Emp_Name'")->fetch_assoc();
    @$Emp_Name_txt = $EMP_NAME["Name"]." - ".$EMP_NAME["F_Name"]." / ". $EMP_NAME["JOB"];
    @$Des = $Account_Emp["Description"];
    @$Date = $Account_Emp["Date"];
    @$Money = $Account_Emp["Amount"];


}

if (isset($_POST["Btn_Save"])) {
    $Emp_Name = $_POST["Emp_Name"];
    $Slect = $_POST["Slect"];
    $Des = $_POST["Des"];
    $Date = $_POST["Date"];
    $Money = $_POST["Money"];
    $Y = substr("$Date",0,4);
    $M = substr("$Date",5,2);
    $Day = jdate('l', strtotime($Cur_Date));
    $YM = $Y.'-'. $M;


        $Conn->query("INSERT INTO emp_accountv2(Emp_ID, Count_ID, Y_M ,Year_, Month_, Date, Day_Count, Type,Description, Amount)
        VALUES ('$Emp_Name','-','$YM','$Y','$M','$Date','0','$Slect','$Des','$Money')");
    

        $Lastid = $Conn->query("SELECT ID FROM `emp_accountv2` ORDER BY ID DESC")->fetch_assoc();
        $Lastid_Fo_exp = "ESE-".$Lastid["ID"];

        $chk = $Conn->query("SELECT Cur_type FROM `emp_tbl` WHERE ID='$Emp_Name'")->fetch_assoc();
        $Cur = $chk["Cur_type"];

        $Conn->query("INSERT INTO `expence`(`Resource`,`Type`, `Des`, `Date_`, `Cur_type`, `Money`) VALUES ('$Lastid_Fo_exp','گاریگر','$Des','$Date','$Cur','$Money')");
        
    echo "<script>window.location.href='Pay_Emp.php';</script>"; 
}elseif (isset($_POST["Btn_Edit"])) {
    $IED = $_GET["IDE"];
    $Emp_Name = $_POST["Emp_Name"];
    $Slect = $_POST["Slect"];
    $Des = $_POST["Des"];
    $Date = $_POST["Date"];
    $Money = $_POST["Money"];
    $Conn->query("UPDATE `emp_accountv2` SET `Emp_ID`='$Emp_Name',`Date`='$Date',`Type`='$Slect',`Description`='$Des',`Amount`='$Money' WHERE ID='$IED'");
    
    $chk = $Conn->query("SELECT Cur_type FROM `emp_tbl` WHERE ID='$Emp_Name'")->fetch_assoc();
    $Cur = $chk["Cur_type"];

    $Conn->query("UPDATE `expence` SET `Des`='$Des',`Date_`='$Date',`Cur_type`='$Cur',`Money`='$Money' WHERE `Resource` = 'ESE-$IED'");
    
    echo "<script>window.location.href='View_Emp.php?ID=$Emp_Name';</script>"; 

}
?>
    <div class="header">
        <div></div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="90px" height="90px" alt="Logo"><p style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo "$Cur_Date"; ?> </p></div>
        <div class="logount">
        <a href="Labor_Index.php" style="position: absolute;right: 0px;top:0px;margin: 15px;width: 50px;font-size:25px;font-weight: 900;color: black;text-decoration: none;font-family: sans-serif;cursor: pointer;">X</a>
        </div>
    </div>
    <form action="" method="post" class="body_page">

            <div class="inputbox">
                <i>گاریگر نوم</i>
                <select name='Emp_Name' required>
                    <?php
                    echo "<option value='$Emp_Name'>$Emp_Name_txt</option>";
                    
                    $Counter_data = $Conn->query("SELECT * FROM emp_tbl WHERE End_Date='فعال' ORDER BY ID");
                    while ($Cname = $Counter_data->fetch_assoc()) {
                        $idC = $Cname["ID"];
                        $name = $Cname["Name"];
                        $Job = $Cname["JOB"];
                        $F_Name = $Cname["F_Name"];
                        echo "<option value='$idC'>$name - $F_Name / $Job</option>";
                    }
                    ?>
                </select>
            </div>
            <div class='inputbox'>
                <i>عمل</i>
                <select name='Slect'>
                    <option value="Pay">رسید گاریگر ته</option>
                    <option value="P">رسید شرگت ته</option>
                </select>

            </div>

            <div class='inputbox'>
                <i>تفصیل</i>
                <textarea name='Des' style='width:100%;max-width:100%;min-width:100%;height:90px;max-height:90px;min-height:90px;'><?php echo $Des; ?></textarea>
            </div>

            <div class="inputbox">
                <i>تاریخ</i>
                <input type="text" name="Date"  value='<?php echo $Date; ?>' required>
            </div>
            <div class="inputbox">
                <i>پیسی</i>
            <div style='display: flex;justify-content: space-between;width: 100%;direction:rtl'>
                <input type='number' min='0' step='0.1' name='Money' id='PricePP' value='<?php echo $Money; ?>' style='width:70%;'>
            </div>
            </div>

            <div class="button">
            <?php
            if (isset($_GET["IDE"])) {
                echo "<input type='submit' value='تغییر' name='Btn_Edit'>";
            }else {
                echo "<input type='submit' value='ثبتول' name='Btn_Save'>";
            }
            ?>
            </div>
    </form>
    
</body>
</html>