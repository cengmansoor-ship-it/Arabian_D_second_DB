<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Arabian D Residence | Sell Prject</title>
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    direction:rtl;
    }
    .header{
    width: 100%;
    height: 137px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 40%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    flex-direction: row-reverse;
    
    }
    .body_page div{
    height: auto;
    width: 100%;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 70%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:78%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    form .inputbox {
        width: 100%;
        padding: 5px;
        margin: 0px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        box-sizing:border-box;
        margin-top:10px;
        position: relative;
    }
    form .inputbox input,select {
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;
        
    }
    form .inputbox i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }
    form .button input {
        width: 170px;
        padding: 18px;
        margin-top: 13px;
        border: none;
        background-color: rgb(51 158 77);
        margin-bottom: 14px;
        border-radius: 20px;   
        font-size:15px;
        font-weight:900;
        }
    form .button input:hover {
        border-radius: 4px;
        box-shadow: rgba(128, 128, 128, 0.63)  1px 10px 10px 2px;
        transition: ease-in-out  0.9s;
        outline: none;
        border: none;
    }

    </style>
</head>
<body>
<?php
include ("Confirm.php");
include ("Config.php");
$Project_Name = $CUsFullName =  $F_NAme = $GandpaNAme = $ContactNO = $NICCard =  $RoomQty = $Floor = "";
$CusName = $APTNum = $Curtype =  $Money = $Payment = "";

if (isset($_GET["IE"])) {
    $IE = $_GET["IE"];
    $Info = $Conn->query("SELECT * FROM `sell_project` WHERE ID = '$IE'")->fetch_assoc();
    $Project_Name = $Info["Project_Name"];
    @$Item = $Conn->query("SELECT `Pro_ID`,`Project_Name`,`Pro_Owner` FROM `project_info` WHERE Pro_ID='$Project_Name'")->fetch_assoc();
    @$CUsFullName = $Item["Project_Name"]." / ".$Item["Pro_Owner"];
    $F_NAme = $Info["F_NAme"];
    $GandpaNAme = $Info["GandpaNAme"];
    $ContactNO = $Info["ContactNO"];
    $NICCard = $Info["NICCard"];  
    $RoomQty =  $Info["RoomQty"];
    $Floor = $Info["Floor"];
    $CusName =  $Info["CusName"];
    $APTNum = $Info["APTNum"];
    $Curtype = $Info["Curtype"];
    $Money = $Info["Money"];
    $Payment = $Info["Payment"];
    
    $href = "?IE=".$IE;
}else {
    $href = "";
}
if (isset($_POST["Btn_Save"])) {
    $Project_Name = $_POST["Project_Name"];
    $F_NAme = $_POST["F_NAme"];
    $GandpaNAme = $_POST["GandpaNAme"];
    $ContactNO = $_POST["ContactNO"];
    $NICCard =  $_POST["NICCard"];
    $RoomQty = $_POST["RoomQty"];
    $Floor = $_POST["Floor"];
    $CusName = $_POST["CusName"];
    $APTNum = $_POST["APTNum"];
    $Curtype =  $_POST["Curtype"];
    $Money = $_POST["Money"];
    $Cur_Date = $_POST["Cur_Date"];
    $Conn->query("INSERT INTO `sell_project`(`Project_Name`, `CusName`, `F_NAme`, `GandpaNAme`, `ContactNO`, `NICCard`, `RoomQty`, 
    `Floor`, `APTNum`, `Money`, `Curtype`, `Date`) 
    VALUES ('$Project_Name','$CusName','$F_NAme','$GandpaNAme','$ContactNO','$NICCard','$RoomQty','$Floor','$APTNum','$Money','$Curtype','$Cur_Date')");
    
    echo "<script>window.location.href='Sell_index.php';</script>"; 
}
if (isset($_POST["Btn_Edit"])) {
    $IE = $_GET["IE"];
    $Project_Name = $_POST["Project_Name"];
    $F_NAme = $_POST["F_NAme"];
    $GandpaNAme = $_POST["GandpaNAme"];
    $ContactNO = $_POST["ContactNO"];
    $NICCard =  $_POST["NICCard"];
    $RoomQty = $_POST["RoomQty"];
    $Floor = $_POST["Floor"];
    $CusName = $_POST["CusName"];
    $APTNum = $_POST["APTNum"];
    $Curtype =  $_POST["Curtype"];
    $Money = $_POST["Money"];
    $Payment = $_POST["Payment"];
    $Cur_Date = $_POST["Cur_Date"];
$Conn->query("UPDATE `sell_project` SET `Project_Name`='$Project_Name',`CusName`='$CusName',`F_NAme`='$F_NAme',`GandpaNAme`='$GandpaNAme',
`ContactNO`='$ContactNO',`NICCard`='$NICCard',`RoomQty`='$RoomQty',`Floor`='$Floor',`APTNum`='$APTNum',`Money`='$Money',
`Curtype`='$Curtype',`Date`='$Cur_Date' WHERE ID='$IE'");

    echo "<script>window.location.href='Sell_index.php';</script>"; 

}

?>
    <div class="header">
        <div></div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="110px" height="110px" alt="Logo"><p style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo "$Cur_Date"; ?> </p></div>
        <div class="logount">
        <a href="Sell_index.php" style="position: absolute;right: 0px;top:0px;margin: 15px;width: 50px;font-size:25px;font-weight: 900;color: black;text-decoration: none;font-family: sans-serif;cursor: pointer;">X</a>
        </div>
    </div>
    <form action="<?php echo $href; ?>" method="post" class="body_page" autocomplete='off'>
    <div class="inputboxtwo">
        <div>
            <i>بلاک :</i>
            <select name='Project_Name' required>
                <?php
                $Item = $Conn->query("SELECT `Pro_ID`,`Project_Name`,`Pro_Owner` FROM `project_info` WHERE Sell='NO' ORDER by Pro_ID");
                echo "<option value='$Project_Name'>$CUsFullName</option>";

                while ($B = $Item->fetch_assoc()) {
                    $idC = $B["Pro_ID"];
                    $CName = $B["Project_Name"];
                    $Pro_Owner = $B["Pro_Owner"];
                    echo "<option value='$idC'>$CName / $Pro_Owner</option>";
                }
                ?>
            </select>
        </div>
        <diV>
        <i>مشتری نوم:</i>
        <input type="text" name="CusName"  value='<?php echo $CusName; ?>' >
        </div>
        </div>

        <div class="inputboxtwo">
                <div>
                <i>پلار نوم:</i>
                <input type="text" name="F_NAme" value='<?php echo $F_NAme; ?>' >
                </div>

                <div>
                <i>نیکه نوم:</i>
                <input type="text" name="GandpaNAme" value='<?php echo $GandpaNAme; ?>' >
                </div>
        </div>

        <div class="inputboxtwo">
            <div>
            <i>موبایل شمیره:</i>
            <input type="text" name="ContactNO" value='<?php echo $ContactNO; ?>' >
            </div>

            <div>
            <i>تذکره نمبر:</i>
            <input type="text" name="NICCard" value='<?php echo $NICCard; ?>' >
            </div>
        </div>
        <div class="inputbox">
            <i>کور نمبر:</i>
            <input type="text" name="APTNum"  value='<?php echo $APTNum; ?>' required>
        </div>
        <div class="inputboxtwo">
            <div>
            <i>اطاق تعداد:</i>
            <input type="text" name="RoomQty" value='<?php echo $RoomQty; ?>' required>
            </div>

            <div>
            <i>منزل:</i>
            <input type="text" name="Floor" value='<?php echo $Floor; ?>' required>
            </div>
        </div>

        <div class="inputbox">
                <i>تاریخ</i>
                <input type="text" name="Cur_Date"  value='<?php echo $Cur_Date; ?>' required>
        </div>
        <div class="inputbox">
                <i>قیمت</i>
            <div style='display: flex;justify-content: space-between;width: 100%;direction:rtl'>
                <input type='number' min='0' step='0.1' name='Money' value='<?php echo $Money; ?>' style='width:70%;'>
                    <select name='Curtype' id='' style='width:30%;'>
                        <option value='<?php echo $Curtype; ?>'><?php echo Find_cur($Curtype); ?></option>
                        <option value='AF'>افغانی</option>
                        <option value='K'>کالدار</option>
                        <option value='USD'>دالر</option>
                    </select>
            </div>
        </div>

        <div class="button">
        <?php
        if (isset($_GET["IE"])) {
            echo "<input type='submit' value='تغییر' name='Btn_Edit'>";
        }else {
            echo "<input type='submit' value='ثبتول' name='Btn_Save'>";
        }
        ?>
        </div>
    </form>
    
</body>
</html>