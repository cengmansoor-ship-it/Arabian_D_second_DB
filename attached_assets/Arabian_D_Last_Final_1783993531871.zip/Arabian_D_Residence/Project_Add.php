<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Arabian D Residence | Add Prject</title>
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    direction:rtl;
    }
    .header{
    width: 100%;
    height: 137px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 40%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    flex-direction: row-reverse;
    
    }
    .body_page div{
    height: auto;
    width: 100%;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 70%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:78%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    form .inputbox {
        width: 100%;
        padding: 5px;
        margin: 0px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        box-sizing:border-box;
        position: relative;
    }
    form .inputbox input,select {
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;
        
    }
    form .inputbox i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }
    form .button input {
        width: 170px;
        padding: 18px;
        margin-top: 13px;
        border: none;
        background-color: rgb(51 158 77);
        margin-bottom: 14px;
        border-radius: 20px;   
        font-size:15px;
        font-weight:900;
        }
    form .button input:hover {
        border-radius: 4px;
        box-shadow: rgba(128, 128, 128, 0.63)  1px 10px 10px 2px;
        transition: ease-in-out  0.9s;
        outline: none;
        border: none;
    }

    </style>
</head>
<body>
<?php
include ("Confirm.php");
include ("Config.php");
$ProName = $ProOwner =  $Location = $Phone = "" ;
if (isset($_GET["IE"])) {
    $IE = $_GET["IE"];
    $Info = $Conn->query("SELECT * FROM `project_info` WHERE Pro_ID = '$IE'")->fetch_assoc();
    $ProName = $Info["Project_Name"];
    $ProOwner =  $Info["Pro_Owner"];
    $Location = $Info["Location"];
    $Phone = $Info["Contact_No"];

    $href = "?IE=".$IE;
}else {
    $href = "";
}
if (isset($_POST["Btn_Save"])) {
    $ProName = $_POST["ProName"];
    $ProOwner = $_POST["ProOwner"];
    $Location = $_POST["Location"];
    $Phone = $_POST["Phone"];

    $Conn->query("INSERT INTO `project_info`(`Project_Name`, `Pro_Owner`, `Location`, `Contact_No`, `SDate`, `Edate`,`Sell`) VALUES 
    ('$ProName','$ProOwner','$Location','$Phone','$Cur_Date','ختم ندی','NO')");

    echo "<script>window.location.href='Project_index.php';</script>"; 


}
if (isset($_POST["Btn_Edit"])) {
    $IE = $_GET["IE"];

    $ProName = $_POST["ProName"];
    $ProOwner = $_POST["ProOwner"];
    $Location = $_POST["Location"];
    $Phone = $_POST["Phone"];

    $Conn->query("UPDATE `project_info` SET `Project_Name`='$ProName',`Pro_Owner`='$ProOwner',`Location`='$Location',`Contact_No`='$Phone' WHERE Pro_ID = '$IE'");

    echo "<script>window.location.href='Project_index.php';</script>"; 

}

?>
    <div class="header">
        <div></div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="110px" height="110px" alt="Logo"><p style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo "$Cur_Date"; ?> </p></div>
        <div class="logount">
        <a href="Project_index.php" style="position: absolute;right: 0px;top:0px;margin: 15px;width: 50px;font-size:25px;font-weight: 900;color: black;text-decoration: none;font-family: sans-serif;cursor: pointer;">X</a>
        </div>
    </div>
    <form action="<?php echo $href; ?>" method="post" class="body_page" autocomplete='off'>
    <div class="inputbox">
        <i>پروژه نوم:</i>
        <input type="text" name="ProName"  value='<?php echo $ProName; ?>' required>
    </div>

    <div class="inputbox">
        <i>پروژه مسؤل:</i>
        <input type="text" name="ProOwner"  value='<?php echo $ProOwner; ?>' required>
    </div>

    <div class="inputbox">
        <i>آدرس:</i>
        <textarea name='Location' style='width:100%;max-width:100%;min-width:100%;height:90px;max-height:90px;min-height:90px;'><?php echo $Location; ?></textarea>
    </div>

    <div class="inputbox">
        <i>شميره:</i>
        <input type="text" name="Phone"  value='<?php echo $Phone; ?>' required>
    </div>
        <div class="button">
        <?php
        if (isset($_GET["IE"])) {
            echo "<input type='submit' value='تغییر' name='Btn_Edit'>";
        }else {
            echo "<input type='submit' value='ثبتول' name='Btn_Save'>";
        }
        ?>
        </div>
    </form>
    
</body>
</html>