<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
body{
    width: 100%;
    padding: 0px;
    margin: 0px;
    display: flex;
    align-items: center;
    direction:rtl;
    flex-direction:column;
}
img{
    width: 100%;
}
table{
    width: 100%;
    border: 1px solid;
    border-collapse: collapse;
}
th,td{
    padding: 6px;
    border: 1px solid;
    font-weight: 900;
}
th,td input{
    width: 100%;
    background: transparent;
    border: none;
    padding: 0px;
    outline: none;
    text-align:center;
    font-weight: 900;
}
caption{
    font-size: 30px;
    font-weight: 900;
    text-align: inherit;
    padding: 5px;
}
    
</style>

</head>
<body>
<?php 
include ("Confirm.php");
include ("Config.php");

if (isset($_GET["ID"])) {
    $IDPro = $_GET["ID"];
}elseif (isset($_POST["SRCH"])) {
    $IDPro = $_POST["IDSrch"];
}else {
    $lastID = $Conn->query("SELECT Pro_ID FROM `project_info` ORDER BY Pro_ID DESC")->fetch_assoc();
    $IDPro = $lastID["Pro_ID"];
}


@$ProInfo = $Conn->query("SELECT * FROM `project_info` WHERE Pro_ID='$IDPro'")->fetch_assoc();
@$Pro_Name = $ProInfo["Project_Name"];
@$Pro_Owner_Name = $ProInfo["Pro_Owner"];
@$Add = $ProInfo["Location"];
@$SDate = $ProInfo["SDate"];
@$Edate = $ProInfo["Edate"];
echo "<title>Arabian D Residence | ", @$Pro_Name ," پروژه</title>";
?>

    <img src="Img/A1.jpg" alt="" srcset="">
    <br>
    <table>
    <caption>پروژی معلومات</caption>
        <tr>
            <td width='290px'>پروژی نوم</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $Pro_Name;  ?></td>
        </tr>
        <tr>
        <td width='290px'>پروژی ای دی</td>
            <td  style='background-image:url(Img/blue2.png);'><form action="" method="POST"><input type="number" min='1' name="IDSrch" value="<?php echo $IDPro;?>"><input type="submit" name='SRCH' style='display:none;'> </form></td>
        </tr>
        <tr>
        <td width='290px'>پروژی صاحب نوم</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $Pro_Owner_Name;  ?></td>
        </tr>
        <tr>
        <td width='290px'>پروژی آدرس</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $Add;  ?></td>
        </tr>

        <td width='290px'>شروع کار</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $SDate;  ?></td>
        </tr>
        <td width='290px'>ختم کار</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $Edate;  ?></td>
        </tr>
    </table>
    <h1>پروژی مصارفات</h1>
    <?php
    $Floors = $Conn->query("SELECT DISTINCT `Floor` FROM `project_exp` WHERE `Project_ID`='$IDPro'");
    $AFT = 0;
    $KT = 0;
    $USDT = 0;

    while ($A = $Floors->fetch_assoc()) {
        echo "<table>";
        $Num = $A["Floor"];
        echo "<caption>مصارف منزل « $Num »</caption>";
        echo "<tr>";
        echo "<td>". "جنس نوم" ."</td>";
        echo "<td>". "مقدار" ."</td>";
        echo "<td>". "پیسی" ."</td>";
        echo "</tr>";
        $Name_exp =  $Conn->query("SELECT DISTINCT `Item_Name`,Cur_type FROM `project_exp` WHERE `Floor`='$Num'");
        $AF = 0;
        $K = 0;
        $USD = 0;
        while ($B = $Name_exp->fetch_assoc()) {
        $disNAme = $B["Item_Name"];
        $Cur = $B["Cur_type"];
        echo "<tr>";
            echo "<td>". $disNAme ."</td>";
            $Info =  $Conn->query("SELECT SUM(`Qty`) as Q,SUM(`total`) as T FROM `project_exp` WHERE `Project_ID`='$IDPro' AND `Item_Name`='$disNAme' AND `Floor`='$Num' AND Cur_type = '$Cur'")->fetch_assoc();
            echo "<td>". $Info["Q"] ."</td>";
            echo "<td>". $Info["T"] , " " ,Find_cur($Cur) ."</td>";
            if ($Cur === "AF") {
                $AF += $Info["T"];
        
            }elseif ($Cur === "K") {
                $K += $Info["T"];
                
            }elseif ($Cur === "USD") {
                $USD += $Info["T"];
            }
        echo "</tr>";
        $AFT += $AF;
        $KT += $K;
        $USDT += $USD;

        }
        echo "<tr>";
        echo "<td>". "توتل افعانی" ."</td>";
        echo "<td>". "$AF" ."</td>";
        echo "</tr>";

        echo "<tr>";
        echo "<td>". "توتل کلدار" ."</td>";
        echo "<td>". "$K" ."</td>";
        echo "</tr>";

        echo "<tr>";
        echo "<td>". "توتل دالر" ."</td>";
        echo "<td>". "$USD" ."</td>";
        echo "</tr>";
        
        echo "</table>";
        echo "<br>";

    }
    ?>
    <br>
    <h1>ټوټل مصارفات</h1>
    <table>
    <tr>
            <td width='290px'>توتل افعانی</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $AFT; ?></td>
        </tr>
        <tr>
            <td width='290px'>توتل کلدار</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $KT; ?></td>
        </tr>
        <tr>
            <td width='290px'>توتل دالر</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $USDT; ?></td>
        </tr>

    </table>
</body>
</html>