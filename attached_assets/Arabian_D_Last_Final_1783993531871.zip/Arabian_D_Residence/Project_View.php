<?php
include ("Confirm.php");
include ("Config.php");
    
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    }
    .body_page{
    background: white;
    /* box-shadow: 2px 4px 11px -2px; */
    width: 98%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-direction:column;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    }
    .body_page .btn{
    height: 80px;
    border: 0.5px solid darkgray;
    width: 290px;
    margin: 5px;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 40%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:50%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    form input,Select{
        width: 230px;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;
    }
    label{
        font-weight: 900;

    }
    .body_page table{
    width: 100%;
    /* border-collapse: collapse; */

    }
    .body_page table td,th{
        border: 1px solid;
    padding: 4px;
    border-radius: 5px;
    text-align: center;
    font-weight:600;
    }
    caption{
    font-size: 30px;
    font-weight: 900;
    text-align: inherit;
    padding: 5px;
}
    </style>
</head>
<body>
<?php
$SDate = $Cur_Date;
$EDate = $Cur_Date;
if (isset($_POST["SrchDate"])) {
    $SDate = $_POST["SDate"];
    $EDate = $_POST["EDate"];
    
}
if (isset($_GET["ID"])) {
    @$ID = $_GET["ID"];
    $href = "?ID=$ID";
    
}else {
    $href = "";
    @$ID = "1";

}

if (isset($_GET["Delid"])) {
    @$DelID = $_GET["Delid"];
    @$ID = $_GET["ID"];
    $Conn->query("DELETE FROM `project_exp` WHERE ID='$DelID'");
    echo "<script>window.location.href='?ID=$ID';</script>"; 
    
}
$ShowItem = $Conn->query("SELECT * FROM `project_info` WHERE Pro_ID='$ID'")->fetch_assoc();
$Pro_Name = $ShowItem["Project_Name"];
$Pro_Owner_Name = $ShowItem["Pro_Owner"];
$Add = $ShowItem["Location"];
$SDate = $ShowItem["SDate"];
$Edate = $ShowItem["Edate"];
$Contact_No = $ShowItem["Contact_No"];
echo "<title>Arabian D Residence | استمال شوی شیان په ", $ShowItem["Project_Name"] ," پروزه که</title>";
?>

<div class="body_page" style='direction:rtl'>
    <br>
    <table>
    <caption>پروژه معلومات</caption>
        <tr>
            <td width='290px'>پروژه نوم</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $Pro_Name;  ?></td>
        </tr>
        <tr>
        <td width='290px'>پروژه ای دی</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $ID;?></td>
        </tr>
        <tr>
        <td width='290px'>پروژه صاحب نوم</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $Pro_Owner_Name;  ?></td>
        </tr>
        <tr>
        <td width='290px'>موبایل نمبر</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $Contact_No;  ?></td>
        </tr>

        <tr>
        <td width='290px'>پروژه آدرس</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $Add;  ?></td>
        </tr>

        <td width='290px'>شروع کار</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $SDate;  ?></td>
        </tr>
        <td width='290px'>ختم کار</td>
            <td  style='background-image:url(Img/blue2.png);'><?php echo $Edate;  ?></td>
        </tr>
    </table>

    <br>
    <table>
        <tr style="background-image:url(Img/Green.png);">
            <th width='90px'>شماره</th>
            <th>تاریخ</th>
            <th>جنس نوم</th>
            <th>مقدار</th>
            <th>قیمت</th>
            <th>توتل</th>
            <th>منزل</th>
            <th>...</th>
        </tr>
        <?php
        $ShowItem = $Conn->query("SELECT * FROM `project_exp` WHERE `Project_ID`='$ID' ORDER BY `Floor`");
        $x = 1;
        $MOneyhAF = 0;
        $MOneyhK = 0;
        $MOneyhUSD = 0;
        while ($A = $ShowItem->fetch_assoc()) {
            echo "<tr>";
            $idRec = $A["ID"];
            echo "<td>". $x++ ."</td>";
            echo "<td>". $A["Date"] ."</td>";
            echo "<td>". $A["Item_Name"] ."</td>";
            echo "<td>". $A["Qty"], " ",  $A["QTYtype"] ."</td>";
            echo "<td>". $A["Price"] ."</td>";
            $Cur = $A["Cur_type"];
            echo "<td>". $A["total"]."&nbsp;&nbsp;&nbsp;" ;
            echo Find_cur($Cur);
            echo "</td>";
            echo "<td>". $A["Floor"] ."</td>";
            echo "<td><a href='?ID=$ID&Delid=$idRec'>". "X" ."</a></td>";

            if ($A["Cur_type"] === "AF") {
                $MOneyhAF += $A["total"];
            }elseif ($A["Cur_type"] === "K") {
                $MOneyhK += $A["total"];
            }elseif ($A["Cur_type"] === "USD") {
                $MOneyhUSD += $A["total"];
            }
            echo "</tr>";
        }
        echo "<tr style='background-image:url(Img/blue2.png);'>";
        echo "<td>". "افغانی:" ."</td>";
        echo "<td>". "$MOneyhAF" ."</td>";
        echo "</tr>";
        echo "<tr style='background-image:url(Img/blue2.png);'>";
        echo "<td>". "کلدار:" ."</td>";
        echo "<td>". "$MOneyhK" ."</td>";
        echo "</tr>";
        echo "<tr style='background-image:url(Img/blue2.png);'>";
        echo "<td>". "دالر:" ."</td>";
        echo "<td>". "$MOneyhUSD" ."</td>";
        echo "</tr>";

        ?>
    </table>


</div>
</body>
</html>