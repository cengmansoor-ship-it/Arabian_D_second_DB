<?php
include ("Confirm.php");
include ("Config.php");
    
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 95%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-direction:column;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    }
    .body_page .btn{
    height: 80px;
    border: 0.5px solid darkgray;
    width: 290px;
    margin: 5px;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 40%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:50%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    form input,Select{
        width: 230px;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;
    }
    label{
        font-weight: 900;

    }
    .body_page table{
    width: 100%;
    /* border-collapse: collapse; */

    }
    .body_page table td,th{
        border: 1px solid;
    padding: 4px;
    border-radius: 5px;
    text-align: center;
    font-weight:600;
    }
    .btnE{
        position: absolute;
    right: 39px;
    padding: 13px;
    top: 20px;
    background: chartreuse;
    text-decoration: none;
    width: auto;
    font-weight: 900;
    }
    .btnR{
        position: absolute;
    left: 39px;
    padding: 13px;
    top: 20px;
    width: auto;
    background: gray;
    text-decoration: none;
    font-weight: 900;
    }
    .btnS{
        position: absolute;
    right: 129px;
    padding: 13px;
    top: 20px;
    background: chartreuse;
    text-decoration: none;
    font-weight: 900;
    } 
    </style>
</head>
<body>
<?php
$SDate = $Cur_Date;
$EDate = $Cur_Date;
@$Item_NameGet = $_GET["Item"];

if (isset($_GET["Item"])) {
    $href = "?Item=$Item_NameGet";
}else {
    $href = "";
}
if (isset($_GET["Delid"])) {
    @$Item_NameGet = $_GET["Item"];
    @$DelID = $_GET["Delid"];
    $Conn->query("");
    echo "<script>window.location.href='';</script>"; 

}
echo "<title>Arabian D Residence | Project List</title>";
if (isset($_POST["SrchDate"])) {
    $SDate = $_POST["SDate"];
    $EDate = $_POST["EDate"];
    $ShowItem = $Conn->query("SELECT * FROM `project_info` WHERE SDate BETWEEN '$SDate' and '$EDate' ORDER BY `Pro_ID`");
}elseif (isset($_GET["Filter"])) {
    if ($_GET["Filter"] === "Complate") {
        $ShowItem = $Conn->query("SELECT * FROM `project_info` WHERE EDate != 'ختم ندی' ORDER BY `Pro_ID`");
    }elseif ($_GET["Filter"] === "INComplate") {
        $ShowItem = $Conn->query("SELECT * FROM `project_info` WHERE EDate = 'ختم ندی' ORDER BY `Pro_ID`");
    }
}else {
    $ShowItem = $Conn->query("SELECT * FROM `project_info` WHERE SDate BETWEEN '$SDate' and '$EDate' ORDER BY `Pro_ID`");
}

if (isset($_GET["ProidFineshed"])) {
    $Change = $_GET["ProidFineshed"];
    $data = $Conn->query("SELECT `Edate` FROM `project_info` WHERE `Pro_ID` = '$Change'")->fetch_assoc();
    if ($data["Edate"] === "ختم ندی") {
        $Conn->query("UPDATE `project_info` SET `Edate`='$Cur_Date' WHERE Pro_ID='$Change'");
    }else {
        $Conn->query("UPDATE `project_info` SET `Edate`='ختم ندی' WHERE Pro_ID='$Change'");
    }
    echo "<script>window.location.href='Project_index.php';</script>"; 
}
if (isset($_GET["SellPro"])) {
    $Change = $_GET["SellPro"];
    $data = $Conn->query("SELECT `Sell` FROM `project_info` WHERE `Pro_ID` = '$Change'")->fetch_assoc();
    if ($data["Sell"] === "NO") {
        $Conn->query("UPDATE `project_info` SET `Sell`='Yes' WHERE Pro_ID='$Change'");
    }else {
        $Conn->query("UPDATE `project_info` SET `Sell`='NO' WHERE Pro_ID='$Change'");
    }
    echo "<script>window.location.href='Project_index.php';</script>"; 

}
?>

<div class="body_page" style='direction:rtl'>
    <a href='Project_Add.php' target='_Blank' class='btnE'>اضافه کول</a>
    <!-- <a href='Prject_Sell.php' target='_Blank' class='btnS'>پروژه خرڅول</a> -->
    <?php
    if (@$_GET["Filter"] === "Complate") {
        echo "<a href='?Filter=INComplate' class='btnR'>نا تکمیل</a>";
    }elseif (@$_GET["Filter"] === "INComplate") {
        echo "<a href='?Filter=Complate' class='btnR'>تکمیل</a>";
    }else {
        echo "<a href='?Filter=INComplate' class='btnR'>نا تکمیل</a>";
    }
    ?>
    <form action="<?php echo $href; ?>" method="post">
        <label for="">شروع تاریخ:</label><input type="text" name="SDate" value='<?php echo $SDate; ?>'>
        <label for="">ختم تاریخ:</label><input type="text" name="EDate" value='<?php echo $EDate; ?>'>
        <input type="submit" name='SrchDate' style="display:none">
    </form>
    <br><br>
    <table>
        <tr style="background-image:url(Img/Green.png);">
            <th>ای دی</th>
            <th>پروژه نوم</th>
            <th>صاحب</th>
            <th>آدرس</th>
            <th>شمیره</th>
            <th>شروع کار</th>
            <th>ختم کار</th>
            <th>فروش</th>
            <th>...</th>
        </tr>
        <?php
        
        $x = 1;
        $MOneyhAF = 0;
        $MOneyhK = 0;
        $MOneyhUSD = 0;
        while ($A = $ShowItem->fetch_assoc()) {
            echo "<tr>";
            $idRec = $A["Pro_ID"];
            echo "<td>". $idRec ."</td>";
            echo "<td>". $A["Project_Name"] ."</td>";
            echo "<td>". $A["Pro_Owner"] ."</td>";
            echo "<td>". $A["Location"] ."</td>";
            echo "<td>". $A["Contact_No"] ."</td>";
            echo "<td>". $A["SDate"] ."</td>";
            echo "<td><a href='?ProidFineshed=$idRec'>". $A["Edate"] ."</a></td>";
            echo "<td><a href='?SellPro=$idRec'>". $A["Sell"] ."</a></td>";
            echo "<td>". "<a href='Project_View.php?ID=$idRec'>لیدل</a>&nbsp;&nbsp;&nbsp;<a href='Project_Add.php?IE=$idRec'>تغییر</a>" ."</td>";
            echo "</tr>";
        }
        // echo "<tr style='background-image:url(Img/blue2.png);''>";
        // echo "<td>". "ټوټل حساب: " ."</td>";
        // echo "<td>". "" ."</td>";
        // echo "<td>". "" ."</td>";
        // echo "<td>". "" ."</td>";
        // echo "<td>". "" ."</td>";
        // echo "<td>". "" ."</td>";
        // echo "<td>". "" ."</td>";
        // echo "<td style='Color:Blue;Font-weight:900;'>". "
        // افغانی: $MOneyhAF <br>
        // کلدار: $MOneyhK <br>
        // دالر: $MOneyhUSD
        // " ."</td>";
        // echo "<td>". "" ."</td>";

        // echo "</tr>";

        ?>
    </table>


</div>
</body>
</html>