# Remaining Fixes - Implementation Checklist

## Priority Order for Remaining Fixes

### PHASE 1: Transaction Files (HIGH PRIORITY)
These files handle critical transaction data - fix within 1 week

- [ ] **All_report.php** - Complex reporting (HIGH)
  - Issue: Multiple complex SELECT queries with string concatenation
  - Queries to fix: ~45 SQL statements
  - Pattern: DISTINCT, SUM, complex WHERE clauses
  - Time estimate: 30-45 minutes
  - Lines with issues: 77-491

- [ ] **Buy_Return.php** - Purchase return handling
  - Issue: Similar pattern to Buy_frm.php
  - Queries to fix: ~6 SQL statements
  - Time estimate: 10 minutes
  - Pattern: Follow Buy_frm.php implementation

- [ ] **Buy_pay.php** - Purchase payments
  - Issue: SELECT with concatenation, UPDATE without parameterization
  - Queries to fix: ~6 SQL statements
  - Time estimate: 10 minutes

- [ ] **Loan_Cus.php** - Main loan management (HIGH)
  - Issue: Multiple transaction queries
  - Queries to fix: ~15 SQL statements
  - Time estimate: 20 minutes

- [ ] **Daily_Activity.php** - Daily activity tracking
  - Issue: Multiple queries for different activity types
  - Queries to fix: ~20 SQL statements
  - Time estimate: 25 minutes

### PHASE 2: Employee/Attendance Files (MEDIUM PRIORITY)
Fix within 2 weeks

- [ ] **Attendance.php** - Attendance tracking
  - Issue: Multiple conditional queries
  - Queries to fix: ~15 SQL statements
  - Time estimate: 20 minutes

- [ ] **AttendM.php** - Attendance management
  - Issue: UPDATE/SELECT with string concatenation
  - Queries to fix: ~8 SQL statements
  - Time estimate: 12 minutes

- [ ] **View_Emp.php** - Employee view (Similar to View_Cus.php)
  - Issue: Multiple queries, pattern available from View_Cus.php
  - Queries to fix: ~10 SQL statements
  - Time estimate: 15 minutes

- [ ] **Pay_Emp.php** - Employee payment
  - Issue: Multiple complex INSERT/UPDATE
  - Queries to fix: ~8 SQL statements
  - Time estimate: 12 minutes

- [ ] **Emp_Rep.php** - Employee reports
  - Issue: Complex SUM/aggregate queries
  - Queries to fix: ~6 SQL statements
  - Time estimate: 10 minutes

- [ ] **Labor_Index.php** - Labor management
  - Issue: UPDATE queries
  - Queries to fix: ~5 SQL statements
  - Time estimate: 8 minutes

### PHASE 3: Project/Sales Files (LOW-MEDIUM PRIORITY)
Fix within 3 weeks

- [ ] **Project_Add.php** - Project addition/editing
  - Queries to fix: ~4 SQL statements
  - Time estimate: 8 minutes

- [ ] **Project_View.php** - Project view
  - Queries to fix: ~5 SQL statements
  - Time estimate: 10 minutes

- [ ] **Project_index.php** - Project listing
  - Queries to fix: ~3 SQL statements
  - Time estimate: 5 minutes

- [ ] **Prject_Sell.php** - Project sales (note typo in filename)
  - Queries to fix: ~4 SQL statements
  - Time estimate: 8 minutes

- [ ] **Sell_index.php** - Sales management
  - Queries to fix: ~8 SQL statements
  - Time estimate: 12 minutes

- [ ] **Loan.php** - Loan management
  - Issue: Complex loan queries
  - Queries to fix: ~10 SQL statements
  - Time estimate: 15 minutes

### PHASE 4: Remaining/Support Files (LOW PRIORITY)
Fix within 4 weeks

- [ ] **Daily_Tran.php** - Daily transactions
  - Queries to fix: ~3 SQL statements
  - Time estimate: 5 minutes

- [ ] **Bill_return.php** - Bill returns
  - Queries to fix: ~3 SQL statements
  - Time estimate: 5 minutes

- [ ] **j** (unnamed file) - Appears to be utility/helper
  - Queries to fix: ~6 SQL statements
  - Time estimate: 8 minutes

- [ ] **Loan_Cus_backup.php** - Backup of main loan file
  - Note: May not need fixing if not in production
  - Queries to fix: ~12 SQL statements (if needed)

- [ ] **Loan_Cus_improved.php** - Development version
  - Note: May not need fixing if not in production
  - Queries to fix: ~12 SQL statements (if needed)

## Pattern Reference for Fixes

### Pattern 1: Simple SELECT (Most Common)
**Before:**
```php
$result = $Conn->query("SELECT * FROM `table` WHERE id='$id'");
$data = $result->fetch_assoc();
```

**After:**
```php
$stmt = $Conn->prepare("SELECT * FROM `table` WHERE id = ?");
$stmt->bind_param("s", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();
$stmt->close();
```

### Pattern 2: SELECT with Multiple WHERE Conditions
**Before:**
```php
$result = $Conn->query("SELECT * FROM `table` WHERE col1='$var1' AND col2='$var2' AND date BETWEEN '$date1' AND '$date2'");
```

**After:**
```php
$stmt = $Conn->prepare("SELECT * FROM `table` WHERE col1=? AND col2=? AND date BETWEEN ? AND ?");
$stmt->bind_param("ssss", $var1, $var2, $date1, $date2);
$stmt->execute();
$result = $stmt->get_result();
```

### Pattern 3: SUM/Aggregate Queries
**Before:**
```php
$result = $Conn->query("SELECT SUM(`amount`) as total FROM `table` WHERE id='$id'")->fetch_assoc();
```

**After:**
```php
$stmt = $Conn->prepare("SELECT SUM(`amount`) as total FROM `table` WHERE id = ?");
$stmt->bind_param("s", $id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$stmt->close();
```

### Pattern 4: DISTINCT with WHERE
**Before:**
```php
@$result = $Conn->query("SELECT DISTINCT `type` FROM `table` WHERE date='$date'");
while ($row = $result->fetch_assoc()) { ... }
```

**After:**
```php
$stmt = $Conn->prepare("SELECT DISTINCT `type` FROM `table` WHERE date = ?");
$stmt->bind_param("s", $date);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) { ... }
$stmt->close();
```

### Pattern 5: INSERT Multiple Values
**Before:**
```php
$Conn->query("INSERT INTO `table` VALUES ('$val1','$val2','$val3','$val4')");
```

**After:**
```php
$stmt = $Conn->prepare("INSERT INTO `table` (col1, col2, col3, col4) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $val1, $val2, $val3, $val4);
$stmt->execute();
$stmt->close();
```

### Pattern 6: UPDATE Multiple Columns
**Before:**
```php
$Conn->query("UPDATE `table` SET col1='$val1', col2='$val2', col3='$val3' WHERE id='$id'");
```

**After:**
```php
$stmt = $Conn->prepare("UPDATE `table` SET col1=?, col2=?, col3=? WHERE id=?");
$stmt->bind_param("sssi", $val1, $val2, $val3, $id);
$stmt->execute();
$stmt->close();
```

### Pattern 7: DELETE with ID
**Before:**
```php
$Conn->query("DELETE FROM `table` WHERE id='$id'");
```

**After:**
```php
$stmt = $Conn->prepare("DELETE FROM `table` WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->close();
```

## Type Binding Reference

| Type | Code | PHP Example |
|------|------|-------------|
| String | s | "hello", "2024-01-01" |
| Integer | i | 123, $_GET['id'] (numeric) |
| Float/Double | d | 123.45, 99.99 |
| Blob | b | binary data |

## Common Issues to Watch For

1. **Missing isset() checks:**
   ```php
   // ❌ Wrong
   $value = $_POST["field"];
   
   // ✅ Correct
   $value = isset($_POST["field"]) ? Save_Input($_POST["field"]) : '';
   if (empty($value)) { echo "error"; exit; }
   ```

2. **Mixed type variables:**
   ```php
   // ❌ Wrong
   $id = $_GET["id"]; // Could be string or number
   
   // ✅ Correct
   $id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;
   if ($id <= 0) { die("Invalid ID"); }
   ```

3. **Forgetting htmlspecialchars() on output:**
   ```php
   // ❌ Wrong
   echo "<td>" . $data["name"] . "</td>";
   
   // ✅ Correct
   echo "<td>" . htmlspecialchars($data["name"]) . "</td>";
   ```

4. **Not checking query results:**
   ```php
   // ❌ Wrong
   $stmt->execute();
   $result = $stmt->get_result();
   $data = $result->fetch_assoc(); // Could fail
   
   // ✅ Correct
   if (!$stmt->execute()) {
       error_log("Query failed: " . $stmt->error);
       die("Database error occurred");
   }
   $result = $stmt->get_result();
   if (!$result) {
       error_log("Result fetch failed");
       die("Data retrieval failed");
   }
   $data = $result->fetch_assoc();
   ```

## Time Estimate Summary

| Phase | Files | Total Estimated Time |
|-------|-------|----------------------|
| Phase 1 | 5 | 1.5 - 2 hours |
| Phase 2 | 6 | 1.5 - 2 hours |
| Phase 3 | 6 | 1 - 1.5 hours |
| Phase 4 | 3 | 15 - 20 minutes |
| **Total** | **20** | **4.5 - 6 hours** |

## Verification Checklist for Each Fix

After fixing each file, verify:

- [ ] All SQL queries use prepared statements
- [ ] All @ error suppression operators removed
- [ ] All user inputs have isset() checks
- [ ] All output uses htmlspecialchars()
- [ ] All numeric values type-cast (intval, floatval)
- [ ] Error handling on prepare() calls
- [ ] Error handling on execute() calls
- [ ] No SQL string concatenation
- [ ] Proper type binding (s, i, d)
- [ ] $stmt->close() called after use

## Quick Win Opportunities

Files that can be fixed in < 5 minutes:
- [ ] Daily_Tran.php (3 queries)
- [ ] Bill_return.php (3 queries)
- [ ] Project_index.php (3 queries)

Files that can be fixed in 5-10 minutes:
- [ ] Labor_Index.php (5 queries)
- [ ] Buy_Return.php (6 queries)
- [ ] Buy_pay.php (6 queries)
- [ ] Emp_Rep.php (6 queries)

## Notes

1. **Backup files:** Loan_Cus_backup.php and Loan_Cus_improved.php may not need fixing if not in production
2. **Test after each fix:** Verify functionality before moving to next file
3. **Use defined patterns:** Don't try to invent new patterns, stick to proven solutions
4. **Document changes:** Keep a log of what was changed in each file
5. **Performance:** Prepared statements are actually faster than string concatenation
6. **Security:** These changes will significantly improve security posture

---

Generated: 2026-05-16
