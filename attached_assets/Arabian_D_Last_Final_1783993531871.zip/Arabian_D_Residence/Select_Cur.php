<?php
include ("Confirm.php");
include ("Config.php");
    
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Arabian D Residence | Select Currency</title>
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    }
    .header{
    width: 100%;
    height: 257px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 95%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    }
    .body_page .btn{
    height: 80px;
    border: 0.5px solid darkgray;
    width: 290px;
    margin: 5px;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 70%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:78%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    </style>
</head>
<body>
    <div class="header">
        <?php
        if (@$_GET["COF"] === 'روزنامچه') {
            $SrcHrefAF = "Daily_Tran.php?Cur=AF";
            $SrcHrefpkr = "Daily_Tran.php?Cur=K";
            $SrcHrefusd = "Daily_Tran.php?Cur=USD";
        }elseif (@$_GET["COF"] === 'مشتری') {
            $ID = $_GET["ID"];
            $SrcHrefAF = "View_Cus.php?Cur=AF&ID=$ID";
            $SrcHrefpkr = "View_Cus.php?Cur=K&ID=$ID";
            $SrcHrefusd = "View_Cus.php?Cur=USD&ID=$ID";
        }elseif (@$_GET["COF"] === 'بازار') {
            $ID = $_GET["ID"];
            $SrcHrefAF = "Loan_Cus.php?Cur=AF&ID=$ID";
            $SrcHrefpkr = "Loan_Cus.php?Cur=K&ID=$ID";
            $SrcHrefusd = "Loan_Cus.php?Cur=USD&ID=$ID";
        }
        ?>
        <div>
            <a href="Dashboard.php" style="position: absolute;left: 0px;top:0px;"><img src="Img/Back.png" alt="Back" width='30px'></a>
        </div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="210px" height="210px" alt="Logo"><p style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo "$Cur_Date"; ?> </p></div>
        <div class="logount">
        </div>
    </div>
    <div class="body_page">
    <div class="btn">
        <a href="<?php echo @$SrcHrefAF; ?>" class="img"><img src="Img/AFN.jpg" width="100%"></a>
        <p class="contente">افغانی</p>
    </div>
    <div class="btn">
        <a href="<?php echo @$SrcHrefpkr ; ?>" class="img"><img src="Img/PKr.png" width="100%"></a>
        <p class="contente">کلداره</p>
    </div>
    <div class="btn">
        <a href="<?php echo @$SrcHrefusd; ?>" class="img"><img src="Img/USD.jpg" width="100%"></a>
        <p class="contente">ډالر</p>
    </div>


    </div>
    <div class="fotter">

    </div>
</body>
</html>