<?php
include ("Confirm.php");
include ("Config.php");
    
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 98%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-direction:column;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    }
    .body_page .btn{
    height: 80px;
    border: 0.5px solid darkgray;
    width: 290px;
    margin: 5px;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 40%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:50%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    form input,Select{
        width: 230px;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;
    }
    label{
        font-weight: 900;

    }
    .body_page table{
    width: 100%;
    /* border-collapse: collapse; */

    }
    .body_page table td,th{
        border: 1px solid;
    padding: 4px;
    border-radius: 5px;
    text-align: center;
    font-weight:600;
    }
    .btnE{
        position: absolute;
    right: 39px;
    padding: 13px;
    top: 20px;
    background: chartreuse;
    text-decoration: none;
    width: auto;
    font-weight: 900;
    }
    .btnR{
        position: absolute;
    left: 39px;
    padding: 13px;
    top: 20px;
    width: auto;
    background: gray;
    text-decoration: none;
    font-weight: 900;
    }
    .btnS{
        position: absolute;
    right: 39px;
    width: auto;
    padding: 13px;
    top: 20px;
    background: chartreuse;
    text-decoration: none;
    font-weight: 900;
    } 
    </style>
</head>
<body>
<?php
$SDate = $Cur_Date;
$EDate = $Cur_Date;
@$Item_NameGet = $_GET["Item"];

if (isset($_GET["Item"])) {
    $href = "?Item=$Item_NameGet";
}else {
    $href = "";
}
if (isset($_GET["DelPayrec"])) {
    @$DelPayrec = $_GET["DelPayrec"];
    $Conn->query("DELETE FROM `sell_project` WHERE `ID`='$DelPayrec'");
    echo "<script>window.location.href='Sell_index.php';</script>"; 
}
if (isset($_GET["DellFullrec"])) {
    @$DellFullrec = $_GET["DellFullrec"];
    $Conn->query("DELETE FROM `sell_project` WHERE `ID`='$DellFullrec' OR Project_Name='$DellFullrec'");
    echo "<script>window.location.href='Sell_index.php';</script>"; 
}
echo "<title>Arabian D Residence | Project List</title>";
if (isset($_POST["SrchDate"])) {
    $SDate = $_POST["SDate"];
    $EDate = $_POST["EDate"];
    $ShowItem = $Conn->query("SELECT * FROM `sell_project` WHERE type='' AND `Date` BETWEEN '$SDate' and '$EDate' ORDER BY `ID`");
}elseif (isset($_POST["SrchName"])) {
    $EDate = $_POST["Project_Name"];
    $ShowItem = $Conn->query("SELECT * FROM `sell_project` WHERE Project_Name='$EDate'");
    
}
else {
    $ShowItem = $Conn->query("SELECT * FROM `sell_project` WHERE type='' AND `Date` BETWEEN '$SDate' and '$EDate' ORDER BY `ID`");
}
if (isset($_POST["Sumpay"])) {
    $IDpay = $_GET["IDrec"];
    $DateP = $_POST["DateP"];
    $MoneyP = $_POST["MoneyP"];
    $Conn->query("INSERT INTO `sell_project`(`type`, `Project_Name`,`Payment`, `Date`) VALUES ('Pay','$IDpay','$MoneyP','$DateP')");
    echo "<script>window.location.href='';</script>"; 
}

?>

<div class="body_page" style='direction:rtl'>
    <a href='Prject_Sell.php' target='_Blank' class='btnS'>خرڅول</a>
    <?php
    ?>
    <form action="<?php echo $href; ?>" method="post">
        <label for="">شروع تاریخ:</label><input type="text" name="SDate" value='<?php echo $SDate; ?>'>
        <label for="">ختم تاریخ:</label><input type="text" name="EDate" value='<?php echo $EDate; ?>'>
        <input type="submit" name='SrchDate' style="display:none">
    </form>
    <form action="<?php echo $href; ?>" method="post">
        <label for="">پروژه نوم:</label>
        <select name='Project_Name' required>
                <?php
                $Item = $Conn->query("SELECT `Pro_ID`,`Project_Name`,`Pro_Owner` FROM `project_info` WHERE Sell='NO' ORDER by Pro_ID");
                echo "<option value=''>.</option>";
                
                while ($B = $Item->fetch_assoc()) {
                    $Pro_ID = $B["Pro_ID"];
                    $CName = $B["Project_Name"];
                    $Pro_Owner = $B["Pro_Owner"];
                    echo "<option value='$Pro_ID'>$CName / $Pro_Owner</option>";
                }
                ?>
        </select>
        <input type="submit" name='SrchName' value='پیدا کول'>
    </form>

    <br><br>
    <table>
        
        <?php
        
        $x = 1;
        $MOneyhAF = 0;
        $MOneyhK = 0;
        $MOneyhUSD = 0;
        
        while ($A = $ShowItem->fetch_assoc()) {
            echo "<tr style='background-image:url(Img/Green.png);'>
            <th>بلاک ای دی</th>
            <th>تاریخ</th>
            <th>بلاک نوم</th>
            <th>نوم / پلار نوم / نیکه نوم</th>
            <th>آدرس</th>
            <th>شمیره</th>
            <th>تذکره</th>
            <th>منزل</th>
            <th>کور نمبر</th>
            <th>اطاقونه تعداد</th>
            <th>اصلی قیمت </th>
            <th>وصول</th>
            <th>الباقی </th>
            <th>...</th>

        </tr>";
            $idRec = $A["Project_Name"];
            $IDpay = $A["ID"];
            echo "<tr>";
            echo "<td>". $idRec ."</td>";$x++;
            echo "<td><a href='?DellFullrec=$IDpay'> x <a>". $A["Date"]."</td>";

            $Item = $Conn->query("SELECT `Location`,`Project_Name`,`Pro_Owner` FROM `project_info` WHERE Pro_ID='$idRec' ORDER by Pro_ID")->fetch_assoc();
            $CName = $Item["Project_Name"];
            $Location = $Item["Location"];
            $Pro_Owner = $Item["Pro_Owner"];
            echo "<td>".$CName ." / ". $Pro_Owner."</td>";
            echo "<td>". $A["CusName"]. " / ".$A["F_NAme"]." / ".$A["GandpaNAme"] ."</td>";
            echo "<td>". $Location."</td>";
            echo "<td>". $A["ContactNO"]."</td>";
            echo "<td>". $A["NICCard"]."</td>";
            echo "<td>". $A["Floor"]."</td>";
            echo "<td>". $A["APTNum"]."</td>";
            echo "<td>". $A["RoomQty"]."</td>";
            echo "<td>". $A["Money"]." ";
            echo Find_cur($A["Curtype"]);
            echo "</td>";
            $pay = $Conn->query("SELECT SUM(`Payment`) as Pay FROM `sell_project` WHERE `Project_Name`='$IDpay' AND `type`='Pay'")->fetch_assoc();
            echo "<td style='Color:blue;'>". $pay["Pay"] ."</td>";
            echo "<td style='Color:red;'>". $A["Money"]-$pay["Pay"] ."</td>";

            echo "<td>". "<a href='Prject_Sell.php?IE=$IDpay' target='_blank'>تغییر</a>" ."</td>";
            echo "</tr>";
            echo "<tr  style='background-image:url(Img/Green.png);''>";
            echo "<th>". "  د اصولی تاریخ:" ."</th>";
            echo "<th>". "پیسی" ."</th>";

            echo "</tr>";
            $Payment = $Conn->query("SELECT * FROM `sell_project` WHERE Project_Name='$IDpay' AND Payment > 0 and type='Pay' ORDER BY `ID`");
            while ($B = $Payment->fetch_assoc()) {
            echo "</tr>";
            $idpayrec = $B["ID"];
            echo "<td><a href='?DelPayrec=$idpayrec'> x <a>". $B["Date"]."</td>";
            echo "<td>". $B["Payment"]."</td>";
            echo "</tr>";
            }
            echo "<tr><form action='?IDrec=$IDpay' method='post'>
            <td><input type='text' name='DateP' value='$Cur_Date' required></td>
            <td><input type='number' min='0' name='MoneyP' required><input type='submit' name='Sumpay' style='display:none;'></td>
        </form></tr>";
        echo "<tr height='19px'></tr>";
        }
        // echo "<tr style='background-image:url(Img/blue2.png);''>";
        // echo "<td>". "ټوټل حساب: " ."</td>";
        // echo "<td>". "" ."</td>";
        // echo "<td>". "" ."</td>";
        // echo "<td>". "" ."</td>";
        // echo "<td>". "" ."</td>";
        // echo "<td>". "" ."</td>";
        // echo "<td>". "" ."</td>";
        // echo "<td style='Color:Blue;Font-weight:900;'>". "
        // افغانی: $MOneyhAF <br>
        // کلدار: $MOneyhK <br>
        // دالر: $MOneyhUSD
        // " ."</td>";
        // echo "<td>". "" ."</td>";

        // echo "</tr>";

        ?>
    </table>


</div>
</body>
</html>