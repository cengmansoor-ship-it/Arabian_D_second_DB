<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Arabian D Residence | Buy Form</title>
    <style>
    body{
    width: 100%;
    height: 100vh;
    margin: 0px;
    padding: 0px;
    display: flex;
    align-items: center;
    flex-direction: column;
    direction:rtl;
    }
    .header{
    width: 100%;
    height: 137px;
    display: flex;
    flex-direction: row; 
    padding: 10px;
    box-sizing: border-box;  
    }
    .header div{
    width: 33% ;
    margin: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    .body_page{
    background: white;
    box-shadow: 2px 4px 11px -2px;
    width: 40%;
    min-height: auto;
    box-sizing: border-box;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    flex-direction: row-reverse;
    
    }
    .body_page div{
    height: auto;
    width: 100%;
    display: flex;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    transition: all 0.5s;
    }
    .img, .contente
    {
    width: 40%;
    height: 70%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 20px;
    }
    .img
    {
    height:78%;
    }
.btn:hover
    {
    cursor: pointer;
    box-shadow: 6px 5px 25px -3px grey;
    }
    form .inputbox {
        width: 100%;
        padding: 5px;
        margin: 0px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        box-sizing:border-box;
        position: relative;
    }
    form .inputbox input,select {
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;
        
    }
    form .inputbox i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }
    form .button input {
        width: 170px;
        padding: 18px;
        margin-top: 13px;
        border: none;
        background-color: rgb(51 158 77);
        margin-bottom: 14px;
        border-radius: 20px;   
        font-size:15px;
        font-weight:900;
        }
    form .button input:hover {
        border-radius: 4px;
        box-shadow: rgba(128, 128, 128, 0.63)  1px 10px 10px 2px;
        transition: ease-in-out  0.9s;
        outline: none;
        border: none;
    }
    .inputboxtwo{
        display: flex;
        width: 100%;
        flex-direction: row;
        direction:rtl;
    }
    .inputboxtwo div{
        width: 49%;
        box-sizing: border-box;
        justify-content: space-between;    
    }
    .inputboxtwo div input,select{
        width: 100%;
        box-sizing:border-box;
        padding: 6px 6px 6px;
        color: black;
        font-weight: 600;
        text-align: right;

    }
    .inputboxtwo div i ,a {
        color: black;
        font-weight: 900;
        font-style: normal;
        text-align: right;
        width: 98%;
        text-decoration: none;
    }

    </style>
</head>
<body>
<?php
include ("Confirm.php");
include ("Config.php");
$Item_Name = $Project_Name = $Floor =  $QTY = $PricePer = $Cur_type = $Total = $Href = $QTYtype = $CUsFullName = $Qty =  "" ;

if (isset($_GET["IE"])) {
    $IE = $_GET["IE"];
    $Href = "?IE=$IE";

}

if (isset($_POST["Btn_Save"])) {
    $Item_Name = $_POST["Item_Name"];
    $Project_Name = $_POST["Project_Name"];
    $Floor =  $_POST["Floor"];
    $QTY = $_POST["QTY"];$QTYtype = $_POST["QTYtype"];
    $PricePer = $_POST["PricePer"];
    $Cur_type = $_POST["Cur_type"];
    $Total = $_POST["Total"];
    $Conn->query("INSERT INTO `project_exp`( `Item_Name`,`QTYtype`, `Qty`, `Price`, `total`, `Cur_type`, `Project_ID`, `Floor`, `Date`) VALUES
     ('$Item_Name','$QTYtype','$QTY','$PricePer','$Total','$Cur_type','$Project_Name','$Floor','$Cur_Date')");
    
    echo "<script>window.location.href='Trans_Item.php';</script>"; 


}elseif (isset($_POST["Btn_Edit"])) {
    $IE = $_GET["IE"];

}
    
?>
    <div class="header">
        <div></div>
        <div style="flex-direction: column;"><img src="iwjmjalglke.jpg" width="90px" height="90px" alt="Logo"><p style="margin: 5px;font-weight: 900;font-family: sans-serif;"> <?php echo "$Cur_Date"; ?> </p></div>
        <div class="logount">
        <a href="Dashboard.php" style="position: absolute;right: 0px;top:0px;margin: 15px;width: 50px;font-size:25px;font-weight: 900;color: black;text-decoration: none;font-family: sans-serif;cursor: pointer;">X</a>
        </div>
    </div>
    <form action="<?php echo $Href; ?>" method="post" class="body_page" autocomplete='off'>

            <div class="inputbox">
                <i>جنس نوم</i>
                <select name='Item_Name' required>
                    <?php
                    $Item = $Conn->query("SELECT DISTINCT `Item_Name` FROM `buy_info` WHERE Item_Name != '' ");
                    echo "<option value='$Item_Name'>$Item_Name</option>";

                    while ($A = $Item->fetch_assoc()) {
                        $name = $A["Item_Name"];
                        echo "<option value='$name'>$name</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="inputbox">
                <i>پروژی نوم</i>
                <select name='Project_Name' required>
                    <?php
                    $Item = $Conn->query("SELECT `Pro_ID`,`Project_Name`,`Pro_Owner` FROM `project_info` WHERE Edate = 'ختم ندی' ORDER by Pro_ID");
                    echo "<option value='$Project_Name'>$CUsFullName</option>";

                    while ($B = $Item->fetch_assoc()) {
                        $idC = $B["Pro_ID"];
                        $CName = $B["Project_Name"];
                        $Pro_Owner = $B["Pro_Owner"];
                        echo "<option value='$idC'>$CName / $Pro_Owner</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="inputbox">
                <i>مصرف په کوم منزل</i>
                <select name='Floor' required>
                <option value="<?php echo $Floor; ?>"><?php echo "منزل $Floor"; ?> </option>
                <option value="1">منزل 1</option>
                <option value="2">منزل 2</option>
                <option value="3">منزل 3</option>
                <option value="4">منزل 4</option>
                <option value="5">منزل 5</option>
                <option value="6">منزل 6</option>
                <option value="7">منزل 7</option>
                <option value="8">منزل 8</option>
                <option value="9">منزل 9</option>
                <option value="10">منزل 10</option>
                <option value="11">منزل 11</option>
                <option value="12">منزل 12</option>
                <option value="13">منزل 13</option>
                <option value="14">منزل 14</option>
                <option value="15">منزل 15</option>
                <option value="16">منزل 16</option>
                <option value="17">منزل 17</option>
                <option value="18">منزل 18</option>
                <option value="19">منزل 19</option>
                <option value="20">منزل 20</option>
                <option value="21">منزل 21</option>
                <option value="22">منزل 22</option>
                <option value="23">منزل 23</option>
                <option value="24">منزل 24</option>
                <option value="25">منزل 25</option>
                </select>
            </div>
            <div class="inputbox">
                <i>مقدار</i>
                <div style='display: flex;justify-content: space-between;width: 100%;direction:rtl'>
                <input type='number' min='0' step='0.00001' name='QTY' id='Qty_I' value='<?php echo $Qty; ?>' style='width:70%;'>
                <input type='text' name='QTYtype' list='QTYL' style='width:30%;'>
                <datalist id='QTYL'>
                <option><?php echo $QTYtype; ?></option>
                <?php
                    $Qty = $Conn->query("SELECT DISTINCT `QTYtype` FROM `project_exp`");
                    while ($a = $Qty->fetch_assoc()) {
                        echo "<option>".$a["QTYtype"]."</option>";
                    }

                ?>
                </datalist>    
                </div>
                </div>

            <div class="inputbox">
                <i>قیمت</i>
            <div style='display: flex;justify-content: space-between;width: 100%;direction:rtl'>
                <input type='number' min='0' step='0.00001' name='PricePer' onchange='total(this.value)' oninput='total(this.value)' id='PricePP' value='<?php echo $PricePer; ?>' style='width:70%;'>
                    <select name='Cur_type' id='' style='width:30%;'>
                        <option value='<?php echo $Cur_type; ?>'><?php echo Find_cur($Cur_type); ?></option>
                        <option value='AF'>افغانی</option>
                        <option value='K'>کالدار</option>
                        <option value='USD'>دالر</option>
                    </select>
            </div>
            </div>

            <div class="inputbox">
                    <i>ټوټل حساب</i>
                    <input type="text" name="Total" Id='TotalP' value='<?php echo $Total ; ?>' required>
                </div>

            <div class="button">
            <?php
            if (isset($_GET["IE"])) {
                echo "<input type='submit' value='تغییر' name='Btn_Edit'>";
            }else {
                echo "<input type='submit' value='ثبتول' name='Btn_Save'>";
            }
            ?>
            </div>
    </form>
    
</body>
</html>