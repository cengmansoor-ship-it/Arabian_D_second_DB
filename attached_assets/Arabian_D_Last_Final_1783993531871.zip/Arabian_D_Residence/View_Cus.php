<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <style>
        body{
            width: 100%;
            height: 100vh;
            padding: 5px;
            margin: 0px;
            box-sizing: border-box;
            /* display: flex; */
            justify-content: center;
            /* flex-direction:column; */
            direction: rtl;
            
        }
        .header{
            width: 100%;
            background-image: url('Img/Green.png');
            height: 100px;
            display: flex;
            justify-content: center;
            font-size: 51px;
            align-items: center;
        }
        .page table{
        width: 100%;
        /* border-collapse: collapse; */

        }
        .page table td,th{
        border: 1px solid;
        padding: 2px;
        border-radius: 5px;
        text-align: center;
        box-sizing: border-box;
        }
        .Slect:hover{
        background-color: #00ffffc4;
        transition: all 0.1s;

        }
        a{
        text-decoration: none;
        color: black;
        font-weight: bolder;
        }
    </style>
</head>
<body>
<div class="header">
    <?php
    include ("Confirm.php");
    include ("Config.php");
    if (isset($_GET["ID"])) {
        $IE = $_GET["ID"];
        $Cus_data = $Conn->query("SELECT * FROM `custumer_info` WHERE ID=$IE")->fetch_assoc();
        $Cus_ty = $Cus_data["Cus_type"];
        $Cus_Na = $Cus_data["Name"];
        $Cus_Loc = $Cus_data["Provice"];
        $Cur_type = $_GET["Cur"];
    }else {
        $IE = "1";
        $Cur_type = "AF";
        $Cus_ty = "";
        $Cus_Na = "";
        $Cus_Loc = "";

    }
    if ($Cur_type === "AF") {
        $Cur_type_txt = "افغانی";
    }elseif ($Cur_type === "K") {
        $Cur_type_txt = "کلدار";
    }elseif ($Cur_type === "USD") {
        $Cur_type_txt = "دالر";
    }
    echo "<p>",$Cus_Na," ولایت ",$Cus_Loc," ",$Cur_type_txt," کهاته</p>";
    ?>
    
</div>
<div class="page">
<table>
<?php
if ($Cus_ty === "Reciver") {
    echo "<title>Arabian D Residence | ",$Cus_Na," ",$Cur_type_txt," کهاته</title>";
    echo "
    <tr style='background-image: url(Img/Green1.png);'>
        <th width='100px'>تاریخ</th>
        <th>تفصیل</th>
        <th>فاکتور</th>
        <th>تعداد</th>
        <th>قیمت</th>
        <th>مجموع</th>
        <th>رسید</th>
        <th>الباقی</th>
    </tr>";
    echo "";
    $view_Data = $Conn->query("SELECT * FROM `buy_info` WHERE `Cus_Name`='$IE' AND `Cur_type`='$Cur_type' ORDER BY Date ");
    $Balance = 0 ;
    $total = 0 ;
    $Pay = 0 ;
    while ($A = $view_Data->fetch_assoc()) {
        if ( $A["Bill_Num"] < 0 || $A["Bill_Num"] == 0) {
            $Idrec =  $A["ID"];
            echo "<tr style = 'Color:blue;Font-weight:900;'>";
            echo "<td>". $A["Date"]."</td>";
            if ($A["Bill_Num"] < 0) {
                echo "<td> واپس شول ". $A["Item_Name"]."</td>";
                echo "<td><a target='_blank' href='Buy_Return.php?IE=$Idrec'>". $A["Bill_Num"]."<a></td>";

            }else {
                echo "<td>". $A["Description"]."</td>";
                echo "<td><a target='_blank' href='Buy_pay.php?IDRec=$Idrec'>". $A["Bill_Num"]."<a></td>";
            }
           
            echo "<td>". $A["Item_qty"] . " ", $A["QTYtype"] ."</td>";
            echo "<td>". $A["Item_price"]."</td>";
            echo "<td>". ""."</td>";
            echo "<td>". $A["Total_price"]."</td>";
            $Pay += $A["Total_price"] ;
            $Balance -= $A["Total_price"] ;
            if ($A["Total_price"] <= 0) {
                $Conn->query("DELETE FROM `buy_info` WHERE `ID`='$Idrec'");
            }
            echo "<td>". $Balance."</td>";
            
            echo "</tr>";
        }else {
            echo "<tr>";
            $Idrec =  $A["ID"];
            echo "<td>". $A["Date"]."</td>";
            if ($A["Bill_Num"] === '0') {
                echo "<td>". $A["Description"]."</td>";
            }else {
                echo "<td>". $A["Item_Name"]."</td>";
            }

            echo "<td>". $A["Bill_Num"]."</td>";
            echo "<td>". $A["Item_qty"] . " ", $A["QTYtype"] ."</td>";
            echo "<td>". $A["Item_price"]."</td>";
            echo "<td>". $A["Total_price"]."</td>";
            echo "<td>". " " ."</td>";
            $total += $A["Total_price"] ;
            $Balance += $A["Total_price"] ;
            
            echo "<td>". $Balance."</td>";
            echo "</tr>";
        }
    }
    echo "<tr style='background-image:url(Img/blue2.png);'>";
    echo "<td style = 'Color:black;Font-weight:900;'>". "مجموع:" ."</td>";
    echo "<td>". " " ."</td>";
    echo "<td>". " " ."</td>";
    echo "<td>";
    $V_Qty = $Conn->query("SELECT DISTINCT `QTYtype` FROM `buy_info` WHERE `Cus_Name`='$IE' AND `Cur_type`='$Cur_type' ORDER BY ID ");
    while ($AB = $V_Qty->fetch_assoc()) {
    $qtytxtname = $AB["QTYtype"];
        $V_Qty_qty = $Conn->query("SELECT SUM(`Item_qty`) as q FROM `buy_info` WHERE `Cus_Name`='$IE' AND `Cur_type`='$Cur_type' and `QTYtype`='$qtytxtname' ORDER BY ID ")->fetch_assoc();
    echo $AB["QTYtype"]." ". $V_Qty_qty["q"] ."<br>";
    }
    echo "</td>";
    echo "<td>". " " ."</td>";
    echo "<td style = 'Color:Red;Font-weight:900;'>". $total ."</td>";
    echo "<td style = 'Color:blue;Font-weight:900;'>". $Pay ."</td>";
    echo "<td style = 'Color:Red;Font-weight:900;'>". $Balance ."</td>";

    echo "</tr>";

}

?>
</table>
</div>
</body>
</html>