<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
body{
    display: flex;
    align-items: center;
    flex-direction: column;
}
.msg {
    padding: 5px;
    width: 46%;
    background-color: #ff0000cc;
    bottom: 10px;
    display: none;
    font-size: 21px;
    font-weight: 900;
    color: white;
    text-align: center;
    line-height: 0px;
}
.Cont p{
    height: 30px;
    line-height: 0px;
    margin-bottom: 0px;
}
.Cont{
    width: 100%;
    height: 30px;
    padding: 0px;
    margin-top: 3px;
    background: rgba(201, 198, 198, 0.904);    
    border-radius: 5px;
    cursor: pointer;
    overflow: hidden;
    transition: all 0.5s;
    transition-delay: 0.3s;
    border: 1px solid gray;
}
.Contopen{
    padding: 0px;
    height: auto;
    background: rgba(224, 221, 221, 0.904);    
    position: relative;
    cursor: pointer;
    overflow: hidden;
    transition: all 0.5s;

}
td, th {
    border: 1px solid black;
    border-radius: 3px;
}
a{
    text-decoration: none;
}
</style>
<?php
include ("Confirm.php");
include ("Config.php");
    if (isset($_GET["ID"])) {
        $ID = $_GET["ID"];
    }else {
        $ID = 1;
    }
    $Emp_Data = $Conn->query("SELECT * FROM emp_tbl Where ID='$ID' ")->fetch_assoc();
    $Name = $Emp_Data["Name"];
    $Job = $Emp_Data["JOB"];
    $Start_Date = $Emp_Data["Join_date"];

    $x = 0;
    $Emp_Balance = 0;
    $TMoney = 0;
    $TPay = 0;
    $TOver = 0;

    if (isset($_GET["Delid"])) {
        $ID = $_GET["ID"];
        $Delid = $_GET["Delid"];
        $exp_id = "ESE-".$Delid;
        $Conn->query("DELETE FROM emp_accountv2 WHERE ID='$Delid'");
        $Conn->query("DELETE FROM expence WHERE Resource='$exp_id'");
        echo "<script>window.location.href='View_Emp.php?ID=$ID';</script>"; 
    }
    echo "<title>MOGW | ", "د $Name - $Job کهاته  </title>";
    ?>
</head>
<body>

<div class="page" style="width=610px;'" dir='rtl'>
<div class="pageheaderatt">
<img src="../../Logo.png" alt="" width="120px;" style="margin-bottom:15px;">
<img src="Title.png" alt="" width="450px;" style="margin-bottom:15px;">
<!-- <p>مقدس عثمانیه د گازی پنبی تولیدی شرکت</p>     class='Normalrow'-->
<img src="../../Logo.png" alt="" width="120px;" style="margin-bottom:15px;">
</div>
<?php

echo "<p style='    font-size: 33px;
text-align: center;
color:#08ef08;'>د $Name - $Job کهاته  </p>";
echo "<div class='msg'><p>نوموړی شخص د شرکت باقی دی </p></div>";
?>
<table width='330px'>
<tr>
    <th>دکارنیټه</th>
    <td>
    <?php
    echo $Start_Date;
    $Account_Emp = $Conn->query("SELECT SUM(Day_Count) as TDay FROM emp_accountv2 WHERE type='P' AND Emp_ID = '$ID' AND Date>= '$Start_Date'  ORDER BY Date ASC")->fetch_assoc();
    ?>
    </td>
    </tr>
    <tr>
    <th>دحاضر ورځی تعداد</th>
    <td><?php echo $Account_Emp["TDay"]; ?></td>
    </tr>

</table>
<?php

$Emp_Data = $Conn->query("SELECT DISTINCT Y_M FROM `emp_accountv2` WHERE Emp_ID='$ID' ORDER BY Y_M");
while ($A = $Emp_Data->fetch_assoc()) {
    $Month = $A["Y_M"]  ;
    echo "<div class='Cont' id='Cont$x' Onclick='closeandopen(this.id)'>";
    echo "<p style='font-size: 20px;color: green;font-weight: 900;'>د $Month میاشتی حاضری - مخکی حساب $Emp_Balance</p>";
    echo " <div class='table'>";  
    echo "<table width='100%'>";
    echo "
        <tr class='toprow'>
            <th>تاریخ</th>
            <th>تفصیل</th>
            <th>حاضری پیسی</th>
            <th>اضافه کاری پیسی</th>
            <th>غیر حاضری پیسی</th>
            <th>رسیدی پیسی</th>
            <th>الباقی</th>
        </tr>";
    $Account_Emp = $Conn->query("SELECT * FROM emp_accountv2 WHERE Emp_ID = '$ID' AND Y_M ='$Month' ORDER BY Date ASC");
    $P=0;
    $A=0;
    while ($B = $Account_Emp->fetch_assoc()) {
    $tid = $B["ID"];
    if ($B["Type"] === "A") {echo "<tr style='Background-color:red;black:white;'>";}elseif ($B["Date"] === $Start_Date) {echo "<tr style='Background-color:orange;'>";}else { echo "<tr>";}
    echo "<td width='151px'><a href='?Delid=$tid&ID=$ID'>X</a>&nbsp;&nbsp;&nbsp;&nbsp;", $B["Date"] ,"</td>";
    
    if ($B["Type"] === "P") {
    echo "<td>", "حاضر روز ", $B["Description"] ,"" ,"</td>";
    echo "<td width='73px' style='Color:green;font-weight:800;'>", $B["Amount"] ,"</td>";
    echo "<td width='94px'>", "" ,"</td>";
    echo "<td width='97px'>", "" ,"</td>";
    echo "<td width='75px'>", "" ,"</td>";
    $Emp_Balance += $B["Amount"];
    $TMoney += $B["Amount"];
    $P += $B["Day_Count"];
    }elseif ($B["Type"] === "A") {
    echo "<td>", "غیر حاضر روز ", $B["Description"] ,"" ,"</td>";
    echo "<td width='94px'>", "" ,"</td>";
    echo "<td width='97px'>", "" ,"</td>";
    echo "<td width='73px' style='Color:green;font-weight:800;'>", $B["Amount"] ,"</td>";
    echo "<td width='75px'>", "" ,"</td>";

    }elseif ($B["Type"] === "Over") {
    echo "<td>", "اضافه کاری ", $B["Day_Count"] ," ساعت" ,"</td>";
    echo "<td width='94px'>", "" ,"</td>";
    echo "<td width='73px' style='Color:green;font-weight:800;'>", $B["Amount"] ,"</td>";
    echo "<td width='97px'>", "" ,"</td>";
    echo "<td width='75px'>", "" ,"</td>";
    $Emp_Balance += $B["Amount"];
    $TOver += $B["Amount"];
    }elseif ($B["Type"] === "Pay") {
    echo "<td>", $B["Description"] ,"</td>";
    echo "<td width='94px'>", "" ,"</td>";
    echo "<td width='97px'>", "" ,"</td>";
    echo "<td width='97px'>", "" ,"</td>";
    echo "<td width='75px' style='Color:Blue;font-weight:800;'><a href='Pay_Emp.php?IDE=$tid&Emp=$ID'>", $B["Amount"] ,"</a></td>";
    $Emp_Balance -= $B["Amount"];
    $TPay += $B["Amount"];
}

    
    echo "<td>", $Emp_Balance ,"</td>";
    echo "</tr>";

    }
    echo "<tr style='background:lightgreen;font-weight:800;'>";
    echo "<td>", "جمله:" ,"</td>";
    echo "<td>", "حاضر $P و غیرحاضر $A" ,"</td>";
    echo "<td>", $TMoney ,"</td>";
    echo "<td>", $TOver ,"</td>";
    echo "<td>", "" ,"</td>";
    echo "<td>", $TPay ,"</td>";
    echo "<td>", $Emp_Balance ,"</td>";
    echo "</tr></b>";
    
    echo "</table>";
    
    
    
    
    echo "</div>";
    echo "</div>";
    echo "<br>";


    
    $x++;
}

?>
<script>
    function closeandopen(X) {
        var y = document.getElementById(X);
        y.classList.toggle("Contopen");
    }
</script>
</body>
</html>