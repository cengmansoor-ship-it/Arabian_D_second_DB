<?php
/**
 * MySQL Connection Diagnostic Script
 * 
 * This script helps diagnose MySQL connection issues.
 * Access it at: http://localhost/Arabian_D_Residence/diagnose_mysql.php
 */

echo "<!DOCTYPE html>";
echo "<html>";
echo "<head>";
echo "<title>MySQL Diagnostic Tool</title>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }";
echo ".container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }";
echo "h1 { color: #333; border-bottom: 3px solid #007bff; padding-bottom: 10px; }";
echo ".test { margin: 20px 0; padding: 15px; border-left: 4px solid #ddd; background: #fafafa; }";
echo ".success { border-left-color: #28a745; background: #f0fff4; }";
echo ".error { border-left-color: #dc3545; background: #fff5f5; }";
echo ".warning { border-left-color: #ffc107; background: #fffbf0; }";
echo ".info { border-left-color: #17a2b8; background: #f0f8ff; }";
echo ".label { font-weight: bold; color: #555; }";
echo ".value { color: #333; font-family: monospace; margin: 5px 0; }";
echo "code { background: #f0f0f0; padding: 2px 5px; border-radius: 3px; }";
echo ".status-ok { color: #28a745; font-weight: bold; }";
echo ".status-bad { color: #dc3545; font-weight: bold; }";
echo ".status-warn { color: #ffc107; font-weight: bold; }";
echo "</style>";
echo "</head>";
echo "<body>";

echo "<div class='container'>";
echo "<h1>🔍 MySQL Connection Diagnostic Tool</h1>";
echo "<p>This tool helps identify why MySQL connection is failing.</p>";

// Test 1: Check if mysqli extension is loaded
echo "<div class='test info'>";
echo "<div class='label'>✓ Test 1: PHP mysqli Extension</div>";
if (extension_loaded('mysqli')) {
    echo "<div class='value'><span class='status-ok'>✓ LOADED</span> - mysqli extension is available</div>";
} else {
    echo "<div class='value'><span class='status-bad'>✗ NOT LOADED</span> - mysqli extension is not available. Enable it in php.ini</div>";
}
echo "</div>";

// Test 2: Test connection to each port
echo "<div class='test info'>";
echo "<div class='label'>✓ Test 2: MySQL Connection Test (Multiple Ports)</div>";

$ports = [3306, 3307, 3308];
$successful_port = null;

foreach ($ports as $port) {
    echo "<div style='margin: 10px 0;'>";
    echo "Testing <code>localhost:$port</code> ... ";
    
    $conn = @new mysqli("localhost", "root", "", "arabian_d", $port);
    
    if (!$conn->connect_error) {
        echo "<span class='status-ok'>✓ SUCCESS</span>";
        echo "<div class='value' style='margin-top: 5px;'>Connected successfully! MySQL is running on port <strong>$port</strong></div>";
        $successful_port = $port;
        $conn->close();
    } else {
        echo "<span class='status-bad'>✗ FAILED</span>";
        echo "<div class='value' style='margin-top: 5px;'>Error: " . htmlspecialchars($conn->connect_error) . "</div>";
    }
    echo "</div>";
}

echo "</div>";

// Test 3: Test raw port connectivity (using fsockopen)
echo "<div class='test info'>";
echo "<div class='label'>✓ Test 3: Network Port Connectivity</div>";

foreach ($ports as $port) {
    echo "<div style='margin: 10px 0;'>";
    echo "Port $port network check ... ";
    
    $fp = @fsockopen("localhost", $port, $errno, $errstr, 2);
    if ($fp) {
        echo "<span class='status-ok'>✓ OPEN</span>";
        echo "<div class='value' style='margin-top: 5px;'>Port is accessible (MySQL might be listening)</div>";
        fclose($fp);
    } else {
        echo "<span class='status-bad'>✗ CLOSED</span>";
        echo "<div class='value' style='margin-top: 5px;'>Port is closed or blocked (Error: $errstr)</div>";
    }
    echo "</div>";
}

echo "</div>";

// Test 4: Check if MySQL service exists and its status
echo "<div class='test info'>";
echo "<div class='label'>✓ Test 4: MySQL Service Status (Windows)</div>";
echo "<div class='value'>";
echo "To check MySQL service status, run in Command Prompt:<br>";
echo "<code>sc query MySQL80</code> or <code>sc query MySQL</code><br><br>";
echo "To start MySQL service (if Windows service):<br>";
echo "<code>net start MySQL80</code>";
echo "</div>";
echo "</div>";

// Test 5: Test without port (uses default 3306)
echo "<div class='test info'>";
echo "<div class='label'>✓ Test 5: Connection Without Explicit Port</div>";
echo "<div style='margin: 10px 0;'>";
echo "Testing <code>localhost</code> (default port) ... ";

$conn = @new mysqli("localhost", "root", "", "arabian_d");

if (!$conn->connect_error) {
    echo "<span class='status-ok'>✓ SUCCESS</span>";
    echo "<div class='value' style='margin-top: 5px;'>Connected on default port</div>";
    $conn->close();
} else {
    echo "<span class='status-bad'>✗ FAILED</span>";
    echo "<div class='value' style='margin-top: 5px;'>Error: " . htmlspecialchars($conn->connect_error) . "</div>";
}
echo "</div>";
echo "</div>";

// Test 6: Database existence check
if ($successful_port) {
    echo "<div class='test success'>";
    echo "<div class='label'>✓ Test 6: Database Check</div>";
    
    $conn = new mysqli("localhost", "root", "", "", $successful_port);
    
    if (!$conn->connect_error) {
        $result = $conn->query("SHOW DATABASES LIKE 'arabian_d'");
        
        if ($result && $result->num_rows > 0) {
            echo "<div class='value'><span class='status-ok'>✓ DATABASE EXISTS</span> - arabian_d database found</div>";
        } else {
            echo "<div class='value'><span class='status-warn'>⚠ DATABASE NOT FOUND</span> - arabian_d database does not exist.</div>";
            echo "<div class='value'>Create it with:<br>";
            echo "<code>CREATE DATABASE arabian_d CHARACTER SET utf8 COLLATE utf8_general_ci;</code>";
            echo "</div>";
        }
    }
    $conn->close();
    echo "</div>";
}

// Summary and recommendations
echo "<div class='test warning'>";
echo "<div class='label'>📋 Summary & Next Steps</div>";

if ($successful_port) {
    echo "<div class='value'>";
    echo "<span class='status-ok'>✓ Connection successful on port $successful_port</span><br>";
    echo "Your system should now work. If still having issues:<br>";
    echo "1. Refresh your browser<br>";
    echo "2. Clear browser cache (Ctrl+Shift+Delete)<br>";
    echo "3. Try accessing the login page again";
    echo "</div>";
} else {
    echo "<div class='value'>";
    echo "<span class='status-bad'>✗ Cannot connect to MySQL</span><br><br>";
    echo "<strong>Action Items:</strong><br>";
    echo "1. ✓ <strong>Start MySQL</strong> - Open XAMPP Control Panel, click 'Start' next to MySQL<br>";
    echo "2. ✓ <strong>Wait</strong> - Give MySQL 5-10 seconds to fully start<br>";
    echo "3. ✓ <strong>Verify</strong> - Check that 'MySQL' shows 'Running' in XAMPP Control Panel<br>";
    echo "4. ✓ <strong>Create Database</strong> - Open phpMyAdmin at <code>http://localhost/phpmyadmin</code><br>";
    echo "5. ✓ <strong>Test Again</strong> - Refresh this page to re-test";
    echo "</div>";
}

echo "</div>";

echo "</div>"; // container
echo "</body>";
echo "</html>";
?>
