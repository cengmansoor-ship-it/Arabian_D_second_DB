<?php
$files = glob(__DIR__ . '/*.php');
foreach ($files as $f) {
    $bn = basename($f);
    $cmd = sprintf('php -l %s 2>&1', escapeshellarg($f));
    $out = shell_exec($cmd);
    if (strpos($out, 'No syntax errors') === false) {
        echo "ISSUE: $bn" . PHP_EOL;
        echo trim($out) . PHP_EOL . PHP_EOL;
    }
}
echo "=== Syntax check complete ===" . PHP_EOL;
