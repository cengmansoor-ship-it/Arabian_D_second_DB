<?php
$m = new mysqli('localhost', 'root', 'root123', 'arabian_d');
if ($m->connect_error) {
    echo "FAIL: " . $m->connect_error . "\n";
} else {
    echo "Connected OK! Server info: " . $m->server_info . "\n";
    echo "Charset: " . $m->character_set_name() . "\n";
    $m->close();
}
